from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import time

RUNS = Path(__file__).resolve().parent
ROOT = RUNS.parents[2]
label = sys.argv[1]
case = RUNS / label
if not case.is_dir():
    raise SystemExit('Missing independent case folder')
query = sys.argv[2]
command = [shutil.which('claude'), '-p', query, '--output-format', 'stream-json',
           '--verbose', '--no-session-persistence', '--permission-mode', 'dontAsk',
           '--tools', 'Read,Glob,Grep,Skill', '--strict-mcp-config',
           '--setting-sources', 'project']
if len(sys.argv) > 3:
    command.extend(['--plugin-dir', sys.argv[3]])
start = time.monotonic()
with (RUNS / (label + '.jsonl')).open('w', encoding='utf-8') as output:
    with (RUNS / (label + '.stderr.txt')).open('w', encoding='utf-8') as error:
        try:
            result = subprocess.run(command, cwd=case, stdout=output, stderr=error,
                                    text=True, timeout=180)
            status = {'exit_code': result.returncode}
        except subprocess.TimeoutExpired:
            status = {'timeout': True}
status.update(elapsed_seconds=round(time.monotonic() - start, 2), query=query,
              command=command, case=label)
(RUNS / (label + '.status.json')).write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(status, ensure_ascii=False))
