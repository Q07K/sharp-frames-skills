"""Capture submissions after generation, without fixing or grading them."""

from pathlib import Path
import hashlib
import json
import shutil

repo = Path.cwd()
artifacts = Path(__file__).resolve().parent
manifest = json.loads((artifacts / 'workspaces.json').read_text())
target = repo / 'examples/fastapi-board-independent'
target.mkdir(exist_ok=False)
frozen = json.loads((repo / 'evals/board-independent/pre-generation-sha256.json').read_text())
for name, expected in frozen['files'].items():
    assert hashlib.sha256((repo / name).read_bytes()).hexdigest() == expected, name
records = []
for item in manifest['workspaces']:
    condition = item['condition']
    workspace = Path(item['path'])
    status = json.loads((artifacts / (condition + '.status.json')).read_text())
    rows = [json.loads(line) for line in (artifacts / (condition + '.jsonl')).read_text(encoding='utf-8').splitlines()]
    init = next(r for r in rows if r.get('type') == 'system' and r.get('subtype') == 'init')
    final = next((r for r in rows if r.get('type') == 'result'), None)
    assert final is not None, condition + ': missing result event'
    source_dir = target / condition.replace('_', '-')
    hashes = {}
    for path in workspace.rglob('*'):
        relative = path.relative_to(workspace)
        if not path.is_file() or any(p in ('.venv', '.git', '.claude', '__pycache__', '.pytest_cache') for p in relative.parts):
            continue
        if path.suffix in ('.pyc', '.db', '.sqlite', '.sqlite3') or '.sqlite3-' in path.name or path.name in ('.coverage',):
            continue
        destination = source_dir / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, destination)
        hashes[relative.as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
    input_integrity = {name: hashlib.sha256((workspace / name).read_bytes()).hexdigest() == digest for name, digest in manifest['inputs'].items()}
    calls = [c for row in rows if row.get('type') == 'assistant' for c in row.get('message', {}).get('content', []) if c.get('type') == 'tool_use']
    native_paths = [{'tool': c['name'], 'path': c.get('input', {}).get('file_path', c.get('input', {}).get('path'))}
                    for c in calls if c['name'] in ('Read', 'Write', 'Edit', 'Glob', 'Grep')]
    record = {'condition': condition, 'model': init.get('model'), 'exposed_skills': init.get('skills'),
              'plugins': init.get('plugins'), 'status': status, 'is_error': final.get('is_error'),
              'input_integrity': input_integrity, 'files_sha256': hashes,
              'tool_calls': [{'name': c['name'], 'input': c.get('input')} for c in calls],
              'native_paths': native_paths, 'final_response': final.get('result'),
              'usage': final.get('usage'), 'reported_api_equivalent_cost_usd': final.get('total_cost_usd')}
    records.append(record)
(artifacts / 'captured.json').write_text(json.dumps(records, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps([{'condition': r['condition'], 'model': r['model'], 'files': len(r['files_sha256']), 'input_integrity': r['input_integrity'], 'is_error': r['is_error']} for r in records], ensure_ascii=False, indent=2))
