from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json
import shutil
import subprocess
import sys
import time

artifacts = Path(__file__).resolve().parent
manifest = json.loads((artifacts / 'workspaces.json').read_text())
preflight = '--preflight' in sys.argv

common = '''REQUIREMENTS.md에 적힌 FastAPI 게시글 API를 이 새 프로젝트에서 구현해 주세요.
실제로 파일을 만들고 실행 가능한 상태로 완성하고 필요한 검사를 작성·실행해 주세요.
내부 구조는 자유롭게 선택하고, README에 실행법·실행한 검사·남은 한계를 설명해 주세요.
이미 준비된 Python 환경은 .venv/Scripts/python.exe이고 requirements.txt의 패키지가 설치돼 있습니다.
셸에서 Python을 실행할 때는 .venv/Scripts/python.exe를 사용하세요.
REQUIREMENTS.md, requirements.txt, .claude 설정·스킬 파일은 변경하지 마세요.
프로젝트 자료는 이 작업 폴더 안의 것만 사용하세요. 다른 프로젝트·이전 예제·상위/상대 작업 폴더·평가 자료를 찾아보지 마세요.
일반 런타임과 설치된 라이브러리는 사용할 수 있습니다. 불명확한 내부 구현 선택은 합리적으로 결정하고 계속 진행하세요.'''

def run(item):
    workspace = Path(item['path'])
    condition = item['condition']
    if preflight:
        prompt = '새 환경 점검입니다. 파일을 수정하지 말고 Bash 도구로 .venv/Scripts/python.exe -c "import fastapi; print(fastapi.__version__)" 명령을 실행한 뒤, 사용 가능한 스킬의 이름을 알려 주세요. 그 외 작업은 하지 마세요.'
    else:
        prompt = ('/sharp-frames-development\n' if condition == 'with_skill' else '') + common
    label = ('preflight-' if preflight else '') + condition
    command = [shutil.which('claude'), '-p', prompt, '--output-format', 'stream-json',
               '--verbose', '--no-session-persistence',
               '--tools', 'Read,Write,Edit,Glob,Grep,Bash,Skill',
               '--allowedTools', 'Read,Write,Edit,Glob,Grep,Bash,Skill',
               '--permission-mode', 'acceptEdits', '--permission-prompts', 'none',
               '--strict-mcp-config', '--setting-sources', 'project', '--no-chrome',
               '--settings', str(workspace / '.claude/settings.json')]
    start = time.monotonic()
    with (artifacts / (label + '.jsonl')).open('w', encoding='utf-8') as output:
        with (artifacts / (label + '.stderr.txt')).open('w', encoding='utf-8') as error:
            try:
                result = subprocess.run(command, cwd=workspace, stdout=output, stderr=error,
                                        text=True, timeout=120 if preflight else 1200,
                                        creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
                status = {'exit_code': result.returncode}
            except subprocess.TimeoutExpired:
                status = {'timeout': True}
    status.update(condition=condition, elapsed_seconds=round(time.monotonic() - start, 2),
                  prompt=prompt, command=command, workspace=str(workspace))
    (artifacts / (label + '.status.json')).write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({key: status.get(key) for key in ('condition', 'exit_code', 'timeout', 'elapsed_seconds')}, ensure_ascii=False), flush=True)

with ThreadPoolExecutor(max_workers=2) as executor:
    list(executor.map(run, manifest['workspaces']))
