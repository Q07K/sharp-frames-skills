from pathlib import Path
import hashlib
import json
import random
import shutil
import uuid

repo = Path.cwd()
artifacts = Path(__file__).resolve().parent
base = Path('<USER>/.codex/visualizations/2026/10/20/01a15a2f-284d-7a72-b0fa-05d66a2893bb') / ('independent-board-' + uuid.uuid4().hex[:8])
base.mkdir()
requirements = (repo / 'evals/fastapi/requirements.txt').read_text(encoding='utf-8') + 'pwdlib[argon2]==0.3.0\nuvicorn==0.38.0\n'
spec = (repo / 'evals/board-independent/REQUIREMENTS.md').read_text(encoding='utf-8')
conditions = ['with_skill', 'without_skill']
random.Random(20261021).shuffle(conditions)
workspaces = []
for condition in conditions:
    workspace = base / uuid.uuid4().hex[:8]
    workspace.mkdir()
    (workspace / 'REQUIREMENTS.md').write_text(spec, encoding='utf-8')
    (workspace / 'requirements.txt').write_text(requirements, encoding='utf-8')
    (workspace / '.gitignore').write_text('.venv/\n__pycache__/\n*.pyc\n*.sqlite3*\n*.db*\n', encoding='utf-8')
    settings = workspace / '.claude/settings.json'
    settings.parent.mkdir()
    settings.write_text(json.dumps({'enabledPlugins': {'superpowers@claude-plugins-official': False, 'humanize-korean@im-not-ai': False}}), encoding='utf-8')
    if condition == 'with_skill':
        shutil.copytree(repo / 'skills/sharp-frames-development', workspace / '.claude/skills/sharp-frames-development', ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    workspaces.append({'condition': condition, 'path': str(workspace)})
manifest = {'base': str(base), 'workspaces': workspaces,
            'inputs': {'REQUIREMENTS.md': hashlib.sha256(spec.encode()).hexdigest(),
                       'requirements.txt': hashlib.sha256(requirements.encode()).hexdigest()}}
(artifacts / 'workspaces.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
print(json.dumps(manifest, indent=2))
