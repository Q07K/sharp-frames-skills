from service import order_detail, export_orders

def run(actor, command, ids):
    if command == 'detail':
        return order_detail(actor, ids[0])
    if command == 'export':
        return export_orders(actor, ids)
    raise ValueError('Unknown command')
