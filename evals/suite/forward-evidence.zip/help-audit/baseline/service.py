from access import owned_order

def order_detail(actor, order_id):
    return owned_order(actor, order_id)
