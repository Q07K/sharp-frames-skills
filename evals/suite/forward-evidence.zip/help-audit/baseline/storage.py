ORDERS = {1: {'id': 1, 'owner_id': 'alice', 'total_won': 1000}, 2: {'id': 2, 'owner_id': 'bob', 'total_won': 2000}}

def fetch_order(order_id):
    return dict(ORDERS[order_id])
