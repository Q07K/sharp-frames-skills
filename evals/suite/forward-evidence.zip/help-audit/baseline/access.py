from storage import fetch_order

def owned_order(actor, order_id):
    order = fetch_order(order_id)
    if order['owner_id'] != actor:
        raise PermissionError('Order not visible')
    return order
