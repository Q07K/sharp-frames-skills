import unittest
from cli import run

class OrderTests(unittest.TestCase):
    def test_owned_detail(self):
        self.assertEqual(run('alice', 'detail', [1])['total_won'], 1000)
    def test_other_user_detail_denied(self):
        with self.assertRaises(PermissionError):
            run('alice', 'detail', [2])
