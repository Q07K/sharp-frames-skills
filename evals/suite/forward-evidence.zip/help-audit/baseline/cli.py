from service import order_detail

def run(actor, command, ids):
    if command == 'detail':
        return order_detail(actor, ids[0])
    raise ValueError('Unknown command')
