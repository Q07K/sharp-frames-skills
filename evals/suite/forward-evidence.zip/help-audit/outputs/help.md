Sharp Frames는 목적에 맞는 스킬을 선택해 사용합니다. 아래는 패키지 명령 목록이며, 현재 호스트에 모두 설치되어 있다는 뜻은 아닙니다.

| 명령 | 용도 | 소스 수정 |
|---|---|---|
| `$maintainable-development` | 기능 구현·버그 수정·일반 리팩터링 | 함 |
| `$sharp-frames-review` | diff·커밋·브랜치·PR 리뷰 | 안 함 |
| `$sharp-frames-audit` | 프로젝트 전체·하위 시스템 진단, 위험과 우선순위 정리 | 안 함 |
| `$sharp-frames-debt` | 신규·기존·해소·미확인 기술 부채 정리 | 안 함 |
| `$sharp-frames-gain` | 개선 전후 효과·근거·비용·남은 위험 비교 | 안 함 |
| `$sharp-frames-map` | 처리 흐름·정책 소유자·재사용 후보 파악 | 안 함 |
| `$sharp-frames-improve` | 선택한 지적·개선 항목 적용, 검증과 효과 정리 | 함 |
| `$sharp-frames-help` | 명령 목록·선택 기준·사용 예시 | 안 함 |

리뷰는 특정 변경을 기준으로 그 변경에서 생긴 문제를 찾습니다. 전체 진단은 현재 프로젝트나 하위 시스템을 조사해 기존 위험까지 근거·조사 범위·우선순위로 정리합니다. 둘 다 구현을 바꾸지 않습니다. 실제 수정은 별도 요청으로 `sharp-frames-improve`를 선택하거나, 일반 구현 요청에 `maintainable-development`를 사용합니다.

예를 들어 `$sharp-frames-review 현재 커밋하지 않은 변경을 검토해줘.`, `$sharp-frames-audit 이 프로젝트 전체를 검토하고 조사 범위와 먼저 고칠 항목을 알려줘.`, `$sharp-frames-improve 리뷰 1번과 3번을 수정하고 검증해줘.`처럼 요청할 수 있습니다. 자연어 선택은 호스트 지원에 따라 다르며, 명령 목록 조회만으로 다른 스킬이 실행되지는 않습니다.
