CACHE = {}

def get_price(key, load):
    if key not in CACHE:
        CACHE[key] = load(key)
    return CACHE[key]

# TODO: retry failed query later
def query_rows(query):
    try:
        return query()
    except Exception:
        return []

EXAMPLE = 'TODO: this is sample text, not a deferral'
