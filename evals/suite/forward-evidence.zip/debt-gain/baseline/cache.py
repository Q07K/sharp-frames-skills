# shortcut: per-process cache; revisit when deployed with multiple workers
CACHE = {}

def get_price(key, load):
    if key not in CACHE:
        CACHE[key] = load(key)
    return CACHE[key]
