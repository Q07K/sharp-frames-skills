# Local price cache
Single-process default. Public query failures must be surfaced, not converted into valid empty results.
