# 주문 조회·내보내기 코드 지도

이 저장소는 사용자의 주문을 조회하는 작은 Python 서비스입니다. [README.md:2](<EVAL_ROOT>/forward-tests/review-map/repo/README.md:2)는 배치·내보내기를 포함하여 자기 주문만 볼 수 있다고 규정합니다. 분석 기준은 `master`, HEAD `542f8f56ea42a5f7fed76862b5539a09692bf487`에 미커밋 변경 `cli.py`, `service.py`가 적용된 작업 트리입니다. 별도 AGENTS.md, 패키지 매니페스트, 워크스페이스 패키지 구성은 이 체크아웃의 추적 파일·숨김 포함 파일 목록에서 발견되지 않았습니다.

## 진입점에서 결과까지

| 경계 | 상세 조회 | 내보내기 |
|---|---|---|
| 공개 호출 | [cli.py:3](<EVAL_ROOT>/forward-tests/review-map/repo/cli.py:3) `run(actor, command, ids)`가 `detail`을 분기하고 `ids[0]`을 전달 | 같은 함수가 `export`를 분기하고 `ids` 전체를 전달 |
| 서비스 | [service.py:4](<EVAL_ROOT>/forward-tests/review-map/repo/service.py:4) `order_detail` → `owned_order(actor, order_id)` | [service.py:7](<EVAL_ROOT>/forward-tests/review-map/repo/service.py:7) `export_orders` → ID마다 `fetch_order(order_id)` |
| 권한 정책 | [access.py:3](<EVAL_ROOT>/forward-tests/review-map/repo/access.py:3)에서 주문을 읽고 `owner_id != actor`면 `PermissionError` | 현재 호출 경로에 `owned_order`가 없고 `actor`는 사용되지 않음 |
| 저장 경계 | [storage.py:3](<EVAL_ROOT>/forward-tests/review-map/repo/storage.py:3) `fetch_order`가 메모리 사전에서 주문의 얕은 복사본을 반환 | 동일 함수 사용 |
| 출력 | 주문 사전 한 개 | 입력 순서대로 주문 사전을 담은 목록. 파일·CSV 생성이나 외부 전송은 없음 |

저장 데이터는 [storage.py:1](<EVAL_ROOT>/forward-tests/review-map/repo/storage.py:1)의 `ORDERS` 두 건입니다. `id`, `owner_id`, `total_won` 필드가 있고 예시 금액은 원 단위를 나타내는 필드 이름으로 저장됩니다. 금액 계산·통화 변환 함수는 이 읽은 구현에 없습니다.

권한 정책의 소유 지점은 `access.owned_order`입니다. 현재 상세 조회는 이 정책에 의존하며, 내보내기는 저장소를 직접 읽습니다. 계약과 현재 경로의 차이는 별도 [리뷰 보고서](<EVAL_ROOT>/forward-tests/review-map/outputs/review.md)에 정리했습니다.

## 재사용 가능한 기존 모듈

| 기능 | 위치·심볼 | 실제 책임과 입출력·오류 | 현재 호출자·테스트 | 재사용 적합성·주의점 |
|---|---|---|---|---|
| 사용자에게 보이는 주문 한 건 읽기 | [access.py:3](<EVAL_ROOT>/forward-tests/review-map/repo/access.py:3) `owned_order(actor, order_id)` | 저장소 조회 후 소유자 비교. 성공 시 주문 사전, 타인 주문이면 `PermissionError`, 없는 ID면 저장소의 `KeyError` 전파 | `service.order_detail`; 상세 조회 성공·거부 테스트가 `cli.run`을 통해 간접 검증 | 내보내기에서도 사용자별 접근 정책을 적용할 수 있는 가장 직접적인 재사용 지점. 인증 자체나 배치 처리는 담당하지 않음 |
| 상세 조회 서비스 | [service.py:4](<EVAL_ROOT>/forward-tests/review-map/repo/service.py:4) `order_detail(actor, order_id)` | `owned_order`에 위임하는 서비스 인터페이스. 같은 결과·오류를 전달 | `cli.run`의 `detail`; 기존 테스트 2개 | 서비스 계층을 통하는 단일 주문 호출에 적합. 별도 도메인 계산은 없음 |
| 저수준 주문 조회 | [storage.py:3](<EVAL_ROOT>/forward-tests/review-map/repo/storage.py:3) `fetch_order(order_id)` | 키 조회 후 `dict(...)` 반환. 원본 사전을 직접 반환하지 않음. 없는 ID는 `KeyError` | `access.owned_order`, `service.export_orders`; 상세 테스트에서 간접 사용 | 데이터 접근 재사용에 적합하지만 소유권을 보장하지 않으므로 사용자 조회의 권한 경계로 대체할 수 없음. 얕은 복사이며 현재 값은 스칼라 |
| 명령 분기 | [cli.py:3](<EVAL_ROOT>/forward-tests/review-map/repo/cli.py:3) `run` | `detail`·`export` 선택, 알 수 없는 명령은 `ValueError` | [tests/test_orders.py:2](<EVAL_ROOT>/forward-tests/review-map/repo/tests/test_orders.py:2) | 새 호출자도 기존 공개 진입점을 사용할 수 있음. 실제 프로세스 인수 파싱이나 사용자 인증은 구현되어 있지 않음 |
| 복수 주문 결과 조립 | [service.py:7](<EVAL_ROOT>/forward-tests/review-map/repo/service.py:7) `export_orders(actor, ids)` | ID별 저장소 조회 결과를 목록으로 만듦. 저장소 오류를 포착하지 않음 | `cli.run`의 `export`; 현재 자동 테스트 없음 | 순서·중복을 유지하는 배치 출력 지점. 사용자별 접근 정책을 적용하려면 위 `owned_order`의 계약과 연결해야 함 |

위 후보는 모두 실제 구현을 읽어 확인했습니다. 소유권 정책은 `access`, 자료 조회는 `storage`, 결과 조립은 `service`가 각각 담당하므로, 저장소 함수에 사용자 정책까지 묶는 범용 함수를 새로 만들 필요는 없습니다. 정책을 유지한 배치 확장을 시작한다면 `export_orders`의 원소 조회 지점과 기존 `owned_order`가 서로 호환됩니다.

## 호출자가 알아야 할 계약

- `actor`, `command`, `ids`는 호출자가 직접 전달합니다. 타입 변환, ID 목록 검증, 인증 주체 확인을 수행하는 외부 어댑터는 이 체크아웃에서 확인되지 않았습니다. `actor`가 신뢰할 수 있는 사용자 식별자인지는 호출 환경의 미확인 사항입니다.
- 상세 조회는 첫 ID만 사용합니다. 빈 목록은 `IndexError`, 없는 ID는 `KeyError`가 그대로 전달됩니다. 상세에서 타인 주문은 `PermissionError`입니다.
- 내보내기의 빈 목록은 `[]`이며, 중복 ID는 중복 결과를 만듭니다. 없는 ID가 있으면 `KeyError`로 호출 전체가 종료되고 부분 목록은 반환되지 않습니다. 저장소 읽기에 쓰기 부작용은 없습니다.
- 별도 설정 주입은 보이지 않습니다. fixture 데이터는 코드의 `ORDERS` 상수에 있고, DB·네트워크·파일 출력 경계는 읽은 코드에 없습니다.

빈 목록·중복·없는 ID·알 수 없는 명령의 결과는 로컬에서 `cli.run`을 직접 실행해 확인했습니다. 권한 경로는 코드 추적과 본인·타인·혼합 내보내기 실행으로 확인했습니다.

## 시작 파일과 확인 범위

흐름을 따라 읽으려면 [cli.py:3](<EVAL_ROOT>/forward-tests/review-map/repo/cli.py:3) → [service.py:4](<EVAL_ROOT>/forward-tests/review-map/repo/service.py:4) → [access.py:3](<EVAL_ROOT>/forward-tests/review-map/repo/access.py:3) → [storage.py:3](<EVAL_ROOT>/forward-tests/review-map/repo/storage.py:3) 순서가 적합합니다. 동작 계약의 출발점은 [README.md:2](<EVAL_ROOT>/forward-tests/review-map/repo/README.md:2), 현재 보장 범위는 [tests/test_orders.py:4](<EVAL_ROOT>/forward-tests/review-map/repo/tests/test_orders.py:4)입니다.

주문 관련 용어와 호출자(`order/detail/export/batch/owner/actor/fetch/query/lookup/list`)를 코드·문서에서 검색하고, 추적된 Python 파일 전체, README와 .gitignore를 읽었습니다. 기존 unittest 2개는 모두 통과했으며 내보내기 자동 테스트는 없습니다. 외부 호출 환경, 실제 인증, 운영 데이터·배포 설정은 이 저장소 자료만으로 알 수 없습니다. 입력 소스·인덱스·브랜치를 수정하지 않았습니다.

