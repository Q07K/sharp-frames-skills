# 미커밋 변경 리뷰

검토 대상은 `master`, HEAD `542f8f56ea42a5f7fed76862b5539a09692bf487` 이후의 미커밋 변경인 `cli.py`, `service.py`입니다. 스테이징 변경과 미추적 파일은 없었습니다. 저장소 내부에 별도 AGENTS.md는 없었습니다. 변경 diff와 README, 호출부, 접근 제어, 저장소, 기존 테스트를 모두 읽었습니다.

**결론: 내보내기 경로에서 다른 사용자의 주문을 반환하는 P1 결함 1건이 확인되어 수정이 필요합니다.**

## 차단 결함

### R-001 · P1 · 내보내기에서도 주문 소유권을 검사해야 함

위치: [service.py:8](<EVAL_ROOT>/forward-tests/review-map/repo/service.py:8)

- **발생 조건:** `run('alice', 'export', [2])`처럼 다른 사용자 소유 주문 ID를 내보내기 인수로 전달합니다. [cli.py:6](<EVAL_ROOT>/forward-tests/review-map/repo/cli.py:6)에서 새 경로로 진입할 수 있습니다.
- **현재 동작과 영향:** `export_orders`는 `actor`를 사용하지 않고 `fetch_order`를 직접 호출합니다. 이 저장 함수에는 접근 검사가 없어 Bob의 주문 ID, 소유자, 금액이 Alice에게 반환됩니다. 소유 주문과 다른 사용자 주문을 섞은 `[1, 2]`도 모두 반환됩니다. 이는 [README.md:2](<EVAL_ROOT>/forward-tests/review-map/repo/README.md:2)의 배치·내보내기를 포함한 자기 주문만 조회한다는 계약을 위반합니다.
- **근거 종류:** 정적 호출 추적과 로컬 실행 재현. 실제 출력은 `foreign_export= [{'id': 2, 'owner_id': 'bob', 'total_won': 2000}]`였습니다. [access.py:3](<EVAL_ROOT>/forward-tests/review-map/repo/access.py:3)의 기존 `owned_order`는 소유자가 다르면 `PermissionError`를 발생시키지만 새 경로에서 호출되지 않습니다.
- **최소 수정:** 각 ID에 대해 기존 `owned_order(actor, order_id)`를 호출하여 동일한 소유권 정책을 재사용합니다. 사용하지 않게 되는 직접 저장소 import도 제거할 수 있습니다.
- **필요한 회귀 검증:** 본인 주문 내보내기는 성공하고, 다른 사용자 주문만 요청하거나 본인·타인 주문을 섞으면 `PermissionError`가 발생하는지 공개 진입점 `cli.run`에서 검증합니다.

## 테스트 범위의 공백

[tests/test_orders.py:5](<EVAL_ROOT>/forward-tests/review-map/repo/tests/test_orders.py:5)의 기존 두 테스트는 상세 조회만 검증합니다. 따라서 두 테스트가 모두 통과해도 새 내보내기의 소유권 계약이 잘못될 수 있습니다. R-001의 회귀 테스트로 보완할 수 있으며 별도 결함으로 중복 집계하지 않았습니다.

## 실행한 확인과 한계

- 번들 Python에 `-B`를 지정하여 `-m unittest discover -s tests -v` 실행: 기존 테스트 2개 모두 통과.
- `cli.run`에서 본인 주문 `[1]`, 타인 주문 `[2]`, 혼합 주문 `[1, 2]` 내보내기 직접 실행: 세 경우 모두 목록을 반환했고, 뒤의 두 경우에서 소유권 우회가 재현됨.
- `git diff --check`: 공백 오류 없음. Git의 LF/CRLF 안내는 있었음.
- 완료 후 상태도 `cli.py`, `service.py`만 수정된 상태였고 HEAD 및 빈 스테이징 상태가 유지됨. 코드·인덱스·브랜치를 수정하지 않았음.

확인은 메모리 저장소 fixture와 로컬 실행 범위입니다. 외부 서비스나 배포를 확인하지 않았고 프로젝트 전체의 안전성을 인증하는 리뷰는 아닙니다. 별도로 남긴 미확인 의문이나 선행 결함은 없습니다.

