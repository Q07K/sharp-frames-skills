import unittest
from cli import run
from service import export_orders

class OrderTests(unittest.TestCase):
    def test_owned_detail(self):
        self.assertEqual(run('alice', 'detail', [1])['total_won'], 1000)
    def test_other_user_detail_denied(self):
        with self.assertRaises(PermissionError):
            run('alice', 'detail', [2])

    def test_owned_export(self):
        for actor, order_id, total in [('alice', 1, 1000), ('bob', 2, 2000)]:
            with self.subTest(actor=actor):
                self.assertEqual(run(actor, 'export', [order_id]), [
                    {'id': order_id, 'owner_id': actor, 'total_won': total},
                ])

    def test_foreign_and_mixed_exports_denied(self):
        for actor, ids in [
            ('alice', [2]), ('alice', [1, 2]), ('alice', [2, 1]),
            ('bob', [1]), ('bob', [2, 1]),
        ]:
            for entry in ['cli', 'service']:
                with self.subTest(actor=actor, ids=ids, entry=entry):
                    with self.assertRaisesRegex(PermissionError, 'Order not visible'):
                        if entry == 'cli':
                            run(actor, 'export', ids)
                        else:
                            export_orders(actor, ids)

    def test_empty_export(self):
        self.assertEqual(run('alice', 'export', []), [])

    def test_duplicate_export_preserves_duplicates(self):
        order = {'id': 1, 'owner_id': 'alice', 'total_won': 1000}
        self.assertEqual(run('alice', 'export', [1, 1]), [order, order])

    def test_unknown_command(self):
        with self.assertRaisesRegex(ValueError, 'Unknown command'):
            run('alice', 'unknown', [1])
