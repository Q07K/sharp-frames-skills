from access import owned_order

def order_detail(actor, order_id):
    return owned_order(actor, order_id)

def export_orders(actor, ids):
    return [owned_order(actor, order_id) for order_id in ids]
