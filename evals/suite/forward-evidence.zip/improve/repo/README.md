# Order query service
Users may see only their own orders, including through batch and export tools.
Entry point: `cli.run(actor, command, ids)`. Existing single-order reads enforce
ownership in `access.owned_order`. Storage is an in-memory fixture, no real data.
Exports use the same ownership check: if any requested order belongs to another
user, the whole call raises `PermissionError` and returns no partial result.
Run `python -m unittest discover -s tests -v`.
