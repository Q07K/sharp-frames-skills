import unittest
from shop.cart import Product, quote_items

class QuoteTests(unittest.TestCase):
    def test_current_price_and_availability(self):
        result = quote_items([("tea", 2), ("cake", 1)],
                             {"tea": Product(350, True), "cake": Product(800, False)})
        self.assertEqual(result["total_cents"], 700)
        self.assertEqual(result["unavailable"], ["cake"])
