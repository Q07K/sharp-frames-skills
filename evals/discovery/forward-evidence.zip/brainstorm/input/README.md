# Synthetic shop fixture
This is evaluation input, not a running production service.
Python 3.12; unittest: python -m unittest discover -s tests -v.
Checkout totals always use current catalog prices. Order history is immutable.
An unavailable item must not silently disappear from a customer's selection.
