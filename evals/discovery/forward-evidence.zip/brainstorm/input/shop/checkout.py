from .cart import quote_items

def preview(items, catalog):
    return quote_items(items, catalog)
