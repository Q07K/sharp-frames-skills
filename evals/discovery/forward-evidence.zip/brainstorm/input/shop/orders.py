def owned_order(order_id, user_id, orders):
    order = orders.get(order_id)
    if order is None or order["owner_id"] != user_id:
        raise LookupError("order not found")
    return order
