from dataclasses import dataclass

@dataclass(frozen=True)
class Product:
    price_cents: int
    available: bool

def quote_items(items, catalog):
    lines, unavailable = [], []
    for sku, quantity in items:
        if quantity <= 0:
            raise ValueError("quantity must be positive")
        product = catalog.get(sku)
        if product is None or not product.available:
            unavailable.append(sku)
        else:
            lines.append((sku, quantity, product.price_cents * quantity))
    return {"lines": lines, "unavailable": unavailable,
            "total_cents": sum(line[2] for line in lines)}
