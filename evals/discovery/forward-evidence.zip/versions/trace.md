# Versions functional forward test trace

- Checked host date: 2026-10-20, Asia/Seoul. Browsing results used only as returned; source publication/release dates are distinguished below.
- This is a functional forward test using an explicitly supplied skill. No baseline condition, no actual host automatic-trigger test, and no causal quality-uplift claim.
- Skill read: `$EVAL_ROOT/work/skills/sharp-frames-versions/SKILL.md` and `references/assessment.md`.
- No other agents used. No package install/download/resolve commands, code execution, dependency changes, service changes or input writes performed. Only response.md and trace.md created beside input.

## Local inspection

Input root: `$EVAL_ROOT/forward-tests/versions/input`.

Executed `rg --files -g '!node_modules' -g '!.git'`, read all four results with PowerShell Get-Content, and inventoried hidden entries with Get-ChildItem -Force. There are only app.py, Dockerfile, README.md and requirements.txt; no local lockfile, CI, tests, deployment config, installed environment or explicit architecture. No host-global Python was assumed to belong to this service.

| Inspected path | Observation | SHA256 after read-only research |
| --- | --- | --- |
| input/requirements.txt | fastapi==0.115.12, pydantic==1.10.15; manifest pins only | 302C05FD84EB7EF5BCA2143A1262EC63C47883128E28DDFF8BD733AE801A8A3B |
| input/README.md | Synthetic fixture; not observed production installs | 861D861C24EAA9C5CD3CF99410ECA4205AF46D1A2914D99B4B0F065FD014B789 |
| input/Dockerfile | python:3.12-slim, pip install requirements; mutable image tag | D0511107CF1D9CB192BAF150115CE18B821931B23207439859C519BA9819EA30 |
| input/app.py | BaseModel, @validator, positive quantity, POST /quotes returns payload.dict(); no persistence | D0A69BDCD0E59FB2458BDFB48D01C970B1E511A58A120613A2C8571979FFFB45 |

## Actual internet research

All entries checked 2026-10-20 via web search/open/find; no packages fetched. Searches used public package/API names, no private source or credentials. Core queries included official Pydantic migration/Python support, FastAPI migration, PyPI release identity, number-to-string coercion issues, Korean `Pydantic V2 마이그레이션 숫자 문자열 FastAPI 경험`, exact `1.10.15 3.12.4`, and Pydantic advisories.

| URL inspected | Check/evidence and applicability |
| --- | --- |
| https://pypi.org/project/pydantic/ | Returned latest 2.14.1 released 2026-10-11, Python >=3.10; not inferred from numbering |
| https://github.com/pydantic/pydantic/releases/tag/v2.14.1 | Confirms release identity/date, allocation optimizations and fixes; not a local performance benchmark |
| https://raw.githubusercontent.com/pydantic/pydantic/v2.14.1/pyproject.toml | Exact Python, pydantic-core 2.50.1 and other transitive requirements |
| https://pypi.org/project/pydantic/1.10.26/ | Candidate dated 2025-12-18. V1 changelog confirms 1.10.16 recursive_guard fix, 1.10.17 Python 3.12 metadata work, 1.10.25 minimal Python 3.14 support. No yanked marker seen on inspected candidate page |
| https://pypi.org/project/pydantic/1.10.15/ | Current manifest version release/upload 2024-04-03; no proof this is installed |
| https://raw.githubusercontent.com/fastapi/fastapi/0.115.12/pyproject.toml | Pydantic >=1.7.4,<3 with exclusions; Starlette >=0.40.0,<0.47.0; metadata acceptance not runtime guarantee |
| https://fastapi.tiangolo.com/how-to/migrate-from-pydantic-v1-to-pydantic-v2/ | Native V2 support 0.100.0; mixed v1 namespace bridge 0.119.0; V1 removal 0.126.0, namespace removal 0.128.0; Python 3.14 warning conflicts with newer V1 minimal-support changelog |
| https://pypi.org/project/fastapi/ | Returned release date 2026-10-20 and Python >=3.10, but extracted page did not establish latest exact version; report intentionally does not invent a current FastAPI version or recommend wholesale upgrade |
| https://docs.pydantic.dev/latest/migration/ | Redirects to https://pydantic.dev/docs/validation/latest/get-started/migration/ ; API renames/deprecations, numeric-string and float-int conversion, validator TypeError behavior |
| https://docs.pydantic.dev/latest/version-policy/ | Redirects to https://pydantic.dev/docs/validation/latest/get-started/version-policy/ ; V1 critical/security support until V3, V2 errors/schema change allowances |
| https://github.com/pydantic/pydantic/issues/9607 | Firsthand 2024-06-07 report, Pydantic 1.10.15/Python 3.12.4/Linux, reproducible ForwardRef error and FastAPI import failure; closed issue, changelog independently supplies fix. No claim of local reproduction |
| https://github.com/pydantic/pydantic/issues/9622 | 2024-06-10 developer discussion of 3.12 support and 1.10.15; corroborates distinction between range and actual support; not separately generalized as current failure |
| https://github.com/pydantic/pydantic/issues/6045 | Firsthand 2023-06-08 migration data-coercion complaint; concrete code, JS/YAML client context, maintainer response; precise V2 patch/runtime absent. Current docs supersede old workaround suggestions |
| https://github.com/pydantic/pydantic/issues/5606 | Maintainer relaying migration user's numeric-string coercion issue, 2023-04-26; found by search; #6045 selected for report as more direct experience |
| https://github.com/pydantic/pydantic/security/advisories | Public list inspected, not exhaustive transitive security audit |
| https://github.com/pydantic/pydantic/security/advisories/GHSA-5jqp-qgf6-3pvh | Historical 2021 date/infinity issue; patched version evidence; absent datetime/date fields in fixture. Not used to imply current vulnerability |
| https://github.com/advisories/GHSA-mr82-8j83-vxmv | CVE-2024-3772, published 2024-04-15, updated 2025-02-13; affected V1 <1.10.13 / V2 >=2,<2.4.0. Manifest and candidates outside ranges; no email field. Not general safety conclusion |
| https://pydantic.dev/docs/validation/latest/concepts/strict_mode/ | Optional feature, extra contract change, not required for basic migration |
| https://pydantic.dev/docs/validation/latest/concepts/serialization/ | Optional serializers; no invented service need |

Search result discovery also surfaced unrelated Python/WebSocket/SecretStr/Decimal and Korean training PDFs; these were not treated as directly applicable service evidence. No pertinent Korean firsthand reproducible migration case was secured in the bounded search. Community reports are anecdotes with reported environments, not migration failure-rate statistics.

## Limits and recommendation checks

Recommendation ties actual model/route usage to V2 API cleanup and real input compatibility changes, offers exact V1 patch fallback, and separates FastAPI/Python moves. Package metadata permits chosen staging combination but it was not installed or executed. No verified deployed commit, production environment, runtime architecture, user traffic or client contract. No comprehensive issue/advisory sweep across Starlette/FastAPI/transitives; no local measured speed, cost, effort estimate or gain claim. Current official docs contain a Python 3.14 support disagreement; report retains 3.12 and names required isolated test to resolve rather than hiding it.

Validation/rollout/rollback in response are proposed work, not completed checks: import/start and contract corpus, error/schema comparison, core wheels, optional same-workload measurements, canary, preserve immutable known-good image and transitive state. No database migration seen in fixture; real external effects explicitly remain unknown.

After writing both outputs, Get-Item confirmed their existence and Get-FileHash repeated all four input SHA256 values with no changes from the table above.
