2026-10-20 확인 기준으로 **V2 이전을 권합니다. Python 3.12와 FastAPI 0.115.12를 우선 유지해 Pydantic 변경의 영향을 검증하고, FastAPI 갱신은 다음 단계로 분리**하는 편이 좋습니다. 바로 이전하기 어렵다면 V1 패치 갱신을 임시 조치로 선택할 수 있습니다. 현재 1.10.15를 그대로 장기 유지하는 선택은 권하지 않습니다. 패키지와 코드는 변경하지 않았습니다.

확인한 것은 제공된 합성 API의 소스입니다. [requirements.txt]($EVAL_ROOT/forward-tests/versions/input/requirements.txt)는 FastAPI 0.115.12와 Pydantic 1.10.15를 고정하고, [Dockerfile]($EVAL_ROOT/forward-tests/versions/input/Dockerfile)은 `python:3.12-slim`을 사용합니다. 잠금 파일·CI·테스트·배포 설정은 없으며, 실제 설치 버전과 운영 Python 패치 버전·이미지 digest는 알 수 없습니다. `3.12-slim` 태그만으로 동일 환경을 재현할 수도 없습니다.

| 선택 | 효과와 필요한 작업 | 판단 |
| --- | --- | --- |
| 1.10.15 유지 | 즉시 수정은 없지만 Python 패치 변화에 따른 기존 호환성 문제를 남김 | 장기 유지 비권장 |
| V1 1.10.26 후보, FastAPI 0.115.12·Python 3.12 유지 | 기존 API를 유지하면서 V1 수정분 반영. 시작·요청 검증 회귀검사는 필요 | 이전을 미룰 때의 임시 경로 |
| V2 2.14.1 후보, FastAPI 0.115.12·Python 3.12 유지 후 FastAPI 별도 갱신 | 모델 API 정리와 입력 계약 검증. 이후 최신 FastAPI 계열로 이동할 기반 확보 | 권장, 실제 조합 검증 전 배포 확정은 보류 |

후보의 근거는 [PyPI 1.10.26](https://pypi.org/project/pydantic/1.10.26/)(2025-12-18), [PyPI Pydantic](https://pypi.org/project/pydantic/)(조회 결과 최신 정식 2.14.1, 2026-10-11)과 [2.14.1 공식 릴리스](https://github.com/pydantic/pydantic/releases/tag/v2.14.1)입니다. 읽은 후보 페이지에는 철회 표시가 없었지만, 신규 회귀 이슈를 전수 확인한 결과는 아닙니다. V1은 적극 개발이 종료됐고 V3 출시까지 중요 버그·보안 수정을 제공한다는 [정책](https://docs.pydantic.dev/latest/version-policy/)이므로, “이미 모든 지원 종료”로 판단하지 않았습니다.

FastAPI 0.115.12의 [태그별 의존성](https://raw.githubusercontent.com/fastapi/fastapi/0.115.12/pyproject.toml)은 `pydantic>=1.7.4,<3`에 일부 초기 V2 제외 조건을 둡니다. 2.14.1은 선언 범위에 들어가지만 이것만으로 이 오래된 FastAPI와의 실행 호환성이 보증되지는 않습니다. 같은 파일의 Starlette 범위는 `>=0.40.0,<0.47.0`입니다. [Pydantic 2.14.1 메타데이터](https://raw.githubusercontent.com/pydantic/pydantic/v2.14.1/pyproject.toml)는 Python `>=3.10`, `pydantic-core==2.50.1`, `typing-extensions>=4.16.0`, `annotated-types>=0.6.0`, `typing-inspection>=0.4.4`를 요구합니다. Python 3.12는 선언상 적합하며, 배포 CPU·Linux용 core wheel과 실제 전이 의존성 해석은 후속 검증 대상입니다.

현재 고정 버전에는 구체적 주의점이 있습니다. 개발자의 [이슈 #9607](https://github.com/pydantic/pydantic/issues/9607)(2024-06-07)은 **Pydantic 1.10.15·Python 3.12.4·Linux**에서 `ForwardRef._evaluate` 오류와 FastAPI import 실패를 재현했습니다. 이슈는 닫혔고, [V1 변경 기록](https://pypi.org/project/pydantic/1.10.26/)에 1.10.16의 관련 수정이 있습니다. 우리 모델에는 forward reference가 없지만 프레임워크 import까지 포함한 시작 검증이 필요합니다. 현재 서비스가 실제로 실패 중이라고 단정하지는 않습니다.

Python 3.14 계획에는 공식 자료의 불일치도 있습니다. [FastAPI 이전 안내](https://fastapi.tiangolo.com/how-to/migrate-from-pydantic-v1-to-pydantic-v2/)는 V1/`pydantic.v1`의 3.14 이상 지원 중단을 설명하지만, 위 V1 변경 기록은 1.10.25에 **최소한의 3.14 지원**을 추가했다고 적습니다. 따라서 V1의 완전한 3.14 호환성을 전제로 삼지 않겠습니다. 이번에는 3.12를 유지하고 런타임 이전을 별도 검증해야 합니다. FastAPI의 `pydantic.v1` 점진 이전 지원은 0.119.0부터이며 0.128.0에서 제거됐다는 같은 안내도 있어, 현재 0.115.12에 그 혼용 경로를 그대로 적용하면 안 됩니다. 이 작은 API는 V2로 직접 바꾸는 편이 단순합니다.

[app.py]($EVAL_ROOT/forward-tests/versions/input/app.py)의 실제 변경 범위는 `QuoteInput`과 `POST /quotes`입니다. V2 권장 API로 정리하려면 `validator`를 `field_validator`로, `@validator("quantity")`를 `@field_validator("quantity")`와 `@classmethod`로, `payload.dict()`를 `payload.model_dump()`로 바꾸면 됩니다. 기존 API는 V2에서 deprecated 상태로 남으므로 모두 즉시 실행 오류를 만드는 변경은 아닙니다. 양수 검사와 `ValueError`는 유지할 수 있습니다. ORM·설정 클래스·사용자 정의 serializer는 이 입력에 없어 관련 패키지나 코드를 추가할 이유가 없습니다. [공식 이전 문서](https://docs.pydantic.dev/latest/migration/)

더 중요한 것은 입력 계약입니다. V2 기본 동작에서는 숫자를 문자열로 자동 변환하지 않으므로 `{"sku":123,"quantity":1}`을 보내던 클라이언트가 거절될 수 있습니다. 소수 수량의 정수 변환도 확인해야 합니다. 개발자 [이슈 #6045](https://github.com/pydantic/pydantic/issues/6045)(2023-06-08)는 공개 API의 JS/YAML 입력에서 같은 문자열 변환 문제를 재현했고, 관리자는 기본값 변경 의도를 설명했습니다. 초기 V2 보고로 정확한 패치 버전·Python 환경은 명시되지 않았으며, 최신 V2의 장애율을 뜻하지 않습니다. 현재 문서에는 `coerce_numbers_to_str` 설정이 있으므로 구형 임시 validator를 그대로 복사하지 말고, SKU가 숫자여도 되는지 결정한 뒤 호환 설정 여부를 정해야 합니다. 한국어 검색에서는 이 단순 API에 직접 적용할 만한 재현·후속 해결까지 있는 경험담을 확보하지 못했습니다.

선택적으로는 [strict mode](https://pydantic.dev/docs/validation/latest/concepts/strict_mode/)로 `quantity="2"` 같은 묵시적 변환을 거절하거나, [serializer](https://pydantic.dev/docs/validation/latest/concepts/serialization/)로 응답 표현을 명시할 수 있습니다. 두 기능 모두 현재 요구사항에 필수는 아닙니다. 특히 strict mode는 클라이언트 계약을 추가로 바꾸므로 첫 이전에 섞지 않는 편이 좋습니다. 기대 효과는 모델 유지보수와 이후 프레임워크 갱신의 용이성입니다. 이 API는 필드 두 개와 양수 검사뿐이라 성능·비용 절감을 수치로 주장할 근거는 없습니다. 공식 2.14.1의 검증 할당 최적화도 우리 서비스 측정 결과는 아닙니다.

보안도 최신 버전이라는 이유만으로 결론내리지 않았습니다. 확인한 [CVE-2024-3772](https://github.com/advisories/GHSA-mr82-8j83-vxmv)의 영향 범위는 V1 `<1.10.13`, V2 `>=2.0.0,<2.4.0`이므로 현재 선언 1.10.15와 두 후보는 이 범위 밖입니다. 입력 모델에는 이메일 검증도 없습니다. 이는 이 공지에 대한 판단이며 FastAPI·Starlette·전체 전이 의존성의 안전성을 확인한 것은 아닙니다.

실행 전에 할 검증은 다음과 같습니다. 이번 검토에서는 환경 설치나 테스트 실행을 하지 않았습니다.

1. 운영 이미지의 Python 패치·패키지 목록·digest와 실제 클라이언트 요청 샘플을 확보합니다. 기존 환경과 후보 환경을 분리하고 전이 의존성까지 고정해 같은 데이터로 비교합니다.
2. 앱 import/시작, 정상 `/quotes` 응답, `quantity`의 0·음수·누락·null·문자열·소수·bool, `sku`의 숫자·누락·null, 추가 필드를 검사합니다. 허용/거절과 변환 결과를 기존 계약과 대조합니다.
3. 422 오류의 `type/loc/msg/ctx` 및 응답 JSON, `/openapi.json`을 비교하고 이를 읽는 클라이언트를 확인합니다. 양수 검사 실패가 500으로 바뀌지 않아야 합니다. 오류 상세와 schema는 문서상 변화 가능성이 있습니다.
4. 실제 Linux/CPU 이미지에서 core wheel·시작 시간을 확인하고, 필요하면 동일 부하로 지연·CPU·메모리를 측정합니다. 검증 통과 후 소량 트래픽으로 오류율과 422 증가를 관찰합니다. FastAPI 갱신은 이후 별도 후보·보안 검토와 함께 진행합니다.

되돌리기는 검증된 기존 또는 V1 패치 이미지와 설정으로 트래픽을 돌리는 범위입니다. 코드·의존성·전이 의존성·Python 이미지를 함께 보관해야 하며 pin 하나만 되돌려 재빌드하면 같은 결과를 보장할 수 없습니다. 제공된 코드는 저장소나 DB를 쓰지 않아 데이터 마이그레이션은 보이지 않습니다. 실제 서비스에 저장·큐·결제 같은 외부 효과가 있다면 혼합 버전과 재처리 호환성을 추가로 확인해야 합니다. strict mode나 새 응답 형식은 이번 범위에서 제외하면 롤백이 쉬워집니다. V2 검증을 미룬다면 V1 패치 경로를 검토하고, **FastAPI 갱신 또는 Python 3.14 도입 전에는 반드시 이 결정을 다시 검토**하세요.
