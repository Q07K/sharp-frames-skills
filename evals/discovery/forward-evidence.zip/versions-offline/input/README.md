# Synthetic API fixture
Dependency versions are manifest pins, not observed production installs.
