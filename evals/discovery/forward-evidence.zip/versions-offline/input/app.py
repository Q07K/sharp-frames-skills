from fastapi import FastAPI
from pydantic import BaseModel, validator

app = FastAPI()

class QuoteInput(BaseModel):
    sku: str
    quantity: int

    @validator("quantity")
    def positive(cls, value):
        if value <= 0:
            raise ValueError("quantity must be positive")
        return value

@app.post("/quotes")
def quote(payload: QuoteInput):
    return payload.dict()
