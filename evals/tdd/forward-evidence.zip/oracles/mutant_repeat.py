import sqlite3
from contextlib import closing

from fastapi import FastAPI, Header, HTTPException

SESSIONS = {"alice-session": ("alice", "customer"),
            "bob-session": ("bob", "customer"),
            "support-session": ("operator", "support")}

def create_app(database):
    app = FastAPI()
    with closing(sqlite3.connect(database)) as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS inventory (sku TEXT PRIMARY KEY, available INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY, owner TEXT, sku TEXT, quantity INTEGER, status TEXT);
        INSERT OR IGNORE INTO inventory VALUES ('tea', 3);
        INSERT OR IGNORE INTO orders VALUES (1, 'alice', 'tea', 2, 'reserved');
        INSERT OR IGNORE INTO orders VALUES (2, 'bob', 'tea', 1, 'reserved');
        INSERT OR IGNORE INTO orders VALUES (3, 'alice', 'tea', 1, 'shipped');
        """)
        conn.commit()

    def actor(session):
        found = SESSIONS.get(session)
        if found is None:
            raise HTTPException(401, 'authentication required')
        return found

    @app.get('/orders')
    def orders(x_session: str | None = Header(default=None)):
        user, role = actor(x_session)
        with closing(sqlite3.connect(database)) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute('SELECT * FROM orders ORDER BY id').fetchall()
            return [dict(row) for row in rows if role == 'support' or row['owner'] == user]

    @app.get('/orders/{order_id}')
    def order(order_id: int, x_session: str | None = Header(default=None)):
        user, role = actor(x_session)
        with closing(sqlite3.connect(database)) as conn:
            conn.row_factory = sqlite3.Row
            row = conn.execute('SELECT * FROM orders WHERE id=?', (order_id,)).fetchone()
            if row is None or (role != 'support' and row['owner'] != user):
                raise HTTPException(404, 'order not found')
            return dict(row)

    @app.post('/orders/{order_id}/cancel')
    def cancel(order_id: int, x_session: str | None = Header(default=None)):
        user, role = actor(x_session)
        if role != 'customer':
            raise HTTPException(403, 'cancellation forbidden')
        with closing(sqlite3.connect(database)) as conn:
            conn.row_factory = sqlite3.Row
            with conn:
                conn.execute('BEGIN IMMEDIATE')
                row = conn.execute('SELECT * FROM orders WHERE id=?', (order_id,)).fetchone()
                if row is None or row['owner'] != user:
                    raise HTTPException(404, 'order not found')
                if row['status'] == 'cancelled':
                    conn.execute('UPDATE inventory SET available=available+? WHERE sku=?', (row['quantity'], row['sku']))
                    return {'id': order_id, 'status': 'cancelled'}
                if row['status'] != 'reserved':
                    raise HTTPException(409, 'cannot cancel')
                conn.execute("UPDATE orders SET status='cancelled' WHERE id=?", (order_id,))
                conn.execute('UPDATE inventory SET available=available+? WHERE sku=?', (row['quantity'], row['sku']))
        return {'id': order_id, 'status': 'cancelled'}

    return app
