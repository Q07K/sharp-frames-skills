import unittest
from unittest.mock import patch
from test_reads import ExistingReads

class CancelTests(ExistingReads):
    @unittest.skip('unstable while migrating')
    def test_other_customer_cannot_cancel(self):
        result = self.client.post('/orders/1/cancel', headers={'X-Session': 'bob-session'})
        self.assertEqual(result.status_code, 404)

    def test_owner_cancel(self):
        result = self.client.post('/orders/1/cancel', headers={'X-Session': 'alice-session'})
        self.assertIn(result.status_code, (200, 409, 500))
