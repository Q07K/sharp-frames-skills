# 실제 명령과 결과 — 2026-10-20

작업 디렉터리: `$EVAL_ROOT\forward-tests\test-only\input`.
초기 HEAD: `a8490d4990fe91496ef8f3173a0f3e971c1daa4d`, 초기 `git status --short` 출력 없음.
명시된 `sharp-frames-test/SKILL.md`와 `references/cases.md`를 읽고 적용했다. sibling/baseline/grader 파일은 읽지 않았다. 다른 agent를 사용하지 않았다.

## 읽기와 기준선

실제 명령: `Get-Content -Raw`로 지정 스킬과 reference를 읽고, input에서 `Get-Location`, `rg --files -g '!__pycache__/**' -g '!*.pyc'`, `Get-Content -Raw README.md`, `Get-Content -Raw app.py`, `Get-Content -Raw tests\test_reads.py`, `git status --short`, `git rev-parse HEAD`를 실행했다. 입력 파일은 README/app.py/test_reads.py였다. 취소의 소유권 확인 누락을 확인했다.

실제 테스트 환경 명령(이후 동일 명령으로 전체 수집·실행):

```powershell
New-Item -ItemType Directory -Force -Path '..\run-temp' | Out-Null
$env:PYTHONPATH='$USER_HOME\.codex\visualizations\2026\10\20\01a157bf-de90-7ee2-89f8-5c5e9777f3a9\sharp-frames-validation\deps'
$env:TMP=(Resolve-Path '..\run-temp').Path
$env:TEMP=$env:TMP
& '$USER_HOME\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -B -m unittest discover -s tests -v
```

첫 샌드박스 실행은 첫 기존 케이스 `test_other_customer_cannot_read_order`에서 약 15초 이상 출력 없이 정지하여 Ctrl-C로 중단(exit 1). 이것은 assertion 실패 증거가 아니라 제한 환경의 실행 차단이다. 정확한 정지 원인은 확인하지 못했다.

디렉터리 생성 명령을 제외한 동일 환경/테스트 명령을 `require_escalated`로 다시 실행했다. 기존 2개 모두 통과, `Ran 2 tests in 0.087s`, `OK`, exit 0. 승인은 로컬 격리 DB 테스트만을 위한 것이며 실서비스/설치/네트워크를 사용하지 않았다.

## 새 테스트 최초 실행과 정당한 테스트 수정

`tests/test_cancellation.py`를 추가하고 같은 전체 unittest 명령을 `require_escalated`로 실행했다. `Ran 13 tests in 1.119s`, `FAILED (failures=6, errors=1)`, exit 1.

제품 실패 6개 하위 검증:

1. `test_other_customer_cannot_cancel_reserved_order`: response 200 != 404.
2. 같은 케이스: DB가 reserved/재고3에서 cancelled/재고5로 바뀌어 no_writes 실패.
3. 같은 케이스: Alice 목록에 cancelled가 보여 기존 상태 재조회 실패.
4. 같은 케이스: support 목록에 cancelled가 보여 기존 상태 재조회 실패.
5. `test_other_customer_cannot_repeat_owners_cancelled_order`: response 200 != 404.
6. `test_other_customers_shipped_order_is_hidden`: response 409 != 404.

별도 ERROR는 `test_stock_write_failure_rolls_back_order_and_allows_retry`의 cleanup에서 발생한 Windows `PermissionError: [WinError 32]`였다. 테스트가 `with sqlite3.connect(...)`를 연결 종료로 오해해 DB 파일 handle을 남겼다. 테스트의 세 connect 위치를 `contextlib.closing`으로 감싸고 쓰기 위치에는 commit/rollback context도 유지했다. assertion, trigger, 계약, skip/수집 조건은 바꾸지 않았다. 실패를 무시하거나 임시 디렉터리 정리를 생략하지 않았다.

## 최종 실제 실행

동일 전체 테스트 명령을 `require_escalated`로 다시 실행했다.

```text
test_alice_reads_cancels_repeats_and_reads_final_state ... ok
test_bob_reads_cancels_repeats_and_reads_final_state ... ok
test_concurrent_owner_requests_restore_inventory_once ... ok
test_missing_or_unknown_session_cannot_write_then_owner_can_recover ... ok
test_missing_order_cannot_be_cancelled ... ok
test_other_customer_cannot_cancel_reserved_order ... FAIL (4 subtests)
test_other_customer_cannot_repeat_owners_cancelled_order ... FAIL (1 subtest)
test_other_customers_shipped_order_is_hidden ... FAIL (1 subtest)
test_owner_cannot_cancel_shipped_order ... ok
test_stock_write_failure_rolls_back_order_and_allows_retry ... ok
test_support_reads_all_but_cannot_cancel_any_order ... ok
test_other_customer_cannot_read_order ... ok
test_owner_reads_own_orders ... ok
Ran 13 tests in 1.139s
FAILED (failures=6)
```

exit 1。13개 메서드 수집, 10개 통과/3개 실패, 하위 검증 실패 6개, errors 0, skipped 0. 최종 제품 실패는 첫 실행과 동일한 소유권 결함이다. 제품 변경/green 단계는 수행하지 않았으므로 TDD red→green 달성으로 주장하지 않는다. 정상 동시성 테스트가 통과한 한 실행을 모든 타이밍의 증명으로 확대하지 않는다.

모든 실행에 기존 의존성의 `StarletteDeprecationWarning: Using httpx with starlette.testclient is deprecated; install httpx2 instead.`가 있었으나 테스트 차단은 아니었다. 의존성을 설치/교체하지 않았다.

## 범위 확인

실제 명령: 번들 Python `-B --version` → `Python 3.12.14`; `git status --short` → `?? tests/test_cancellation.py`(매트릭스 작성 전); `git diff --exit-code -- app.py README.md tests/test_reads.py` → 출력 없음; `git diff --check` → 출력 없음; `Get-ChildItem -Force tests` → 기존 파일과 새 파일만 확인.

그 뒤 테스트 관리용 `tests/CASE_MATRIX.md`와 이 trace/response를 추가했다. 실제 API와 SQLite를 사용하며 실패 주입은 테스트 DB trigger뿐이다. 제품 코드와 기존 회귀 테스트 변경은 없다. 본 실행은 명시된 스킬 기능 시험이며 자동 트리거 라우팅이나 baseline 대비 uplift 증거를 제공하지 않는다.

최종 정리 명령은 `$taskTempPath=(Resolve-Path '..\run-temp').Path`로 경로를 확인하고 예상 절대 경로 `...\forward-tests\test-only\run-temp`와 정확히 같은지 검사한 뒤 `Remove-Item -LiteralPath $taskTempPath -Recurse -Force`를 실행했다. 작업에서 만든 임시 DB 디렉터리만 삭제했다. 이어 `git status --short`, `git diff --exit-code -- app.py README.md tests/test_reads.py`, `git diff --check`를 실행해 exit 0. 최종 상태는 `?? tests/CASE_MATRIX.md`, `?? tests/test_cancellation.py`뿐이며 나머지 diff 출력은 없다.
