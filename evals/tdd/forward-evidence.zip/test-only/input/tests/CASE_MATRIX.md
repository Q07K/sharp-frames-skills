# 주문 취소 케이스 정의

계약 출처: [README](../README.md)의 주문 취소 계약. 기존 API 경계와 실제 SQLite 저장소를 사용한다. 테스트 식별자는 unittest 메서드 이름이며, 아래는 실행 가능한 의무 목록이다. 날짜별 실행 결과는 저장소 밖의 `../trace.md`(input 기준)에 별도로 기록한다. 이 문서는 과거 통과 배지가 아니다.

| 안정 식별자 | 계약 / 페르소나와 시작 상태 | 연결된 행동 | 예상 응답·최종 상태 | 수준 / 위치 | 위험·범위 |
| --- | --- | --- | --- | --- | --- |
| `test_owner_reads_own_orders` | 기존 목록 보존 / Alice | 목록 조회 | Alice의 1·3번만 표시 | API 통합 / `test_reads.py` | 기존 의무 유지 |
| `test_other_customer_cannot_read_order` | 기존 상세 접근 보존 / Bob | Alice 주문 상세 조회 | 404 | API 통합 / `test_reads.py` | 기존 의무 유지 |
| `test_alice_reads_cancels_repeats_and_reads_final_state` | 자기 reserved만 취소 / Alice, 1번 수량 2 | 목록·상세 → 취소 → 모든 역할 재조회 → 반복 → 재조회 | 동일 200 본문, cancelled, 재고 3→5 한 번, 타 주문 보존 | API 워크플로 / `test_cancellation.py` | 조회·쓰기 연결 및 반복 부작용 |
| `test_bob_reads_cancels_repeats_and_reads_final_state` | 자기 reserved만 취소 / Bob, 2번 수량 1 | 동일 흐름을 Bob으로 수행 | 동일 200 본문, 재고 3→4 한 번, 타 주문 보존 | API 워크플로 / `test_cancellation.py` | 특정 사용자/수량 하드코딩 회귀 |
| `test_other_customer_cannot_cancel_reserved_order` | 타 주문은 404·쓰기 금지 / Bob→Alice reserved | 취소 → 전체 DB 비교 → Alice·Bob·support 조회 | 404, 모든 주문/재고 불변, 조회 가시성 유지 | API 워크플로 / `test_cancellation.py` | 권한 없는 실제 변경 |
| `test_other_customer_cannot_repeat_owners_cancelled_order` | 반복 허용은 같은 고객 / Alice 취소 후 Bob | Alice 취소 → 상태 확인 → Bob 취소 → 재조회 | Alice 200, Bob 404, 두 번째 요청은 무변경 | API 워크플로 / `test_cancellation.py` | 멱등 분기의 소유권 우회 |
| `test_other_customers_shipped_order_is_hidden` | 타 주문 404 / Bob→Alice shipped | 취소 → DB·모든 역할 조회 | 404, 무변경 | API 워크플로 / `test_cancellation.py` | 상태 오류를 통한 타 주문 노출 |
| `test_support_reads_all_but_cannot_cancel_any_order` | support 전체 조회·취소 금지 / reserved·shipped | 각 취소 → DB·목록·상세 조회 | 403, 무변경, support는 모든 주문 조회 가능 | API 워크플로 / `test_cancellation.py` | 역할과 상태 분기 순서 |
| `test_missing_order_cannot_be_cancelled` | 없는 주문 404 / Alice | 없는 ID 취소 → DB·재조회 | 404, 무변경 | API 워크플로 / `test_cancellation.py` | 누락 개체의 부작용 |
| `test_owner_cannot_cancel_shipped_order` | shipped 409 / Alice 본인 주문 | 취소 → DB·재조회 | 409, 무변경 | API 워크플로 / `test_cancellation.py` | 잘못된 상태 전이 |
| `test_missing_or_unknown_session_cannot_write_then_owner_can_recover` | 누락·미등록 세션 401 | 각 세션 취소·목록·상세 → Alice 정상 취소 | 401, 무변경, 정상 세션으로 이후 200·재고 한 번 복구 | API 워크플로 / `test_cancellation.py` | 세션 분리와 거부 뒤 복구 |
| `test_stock_write_failure_rolls_back_order_and_allows_retry` | 주문·재고 한 트랜잭션 / Alice | 재고 UPDATE를 abort하는 SQLite trigger → 취소 실패 → 재조회 → trigger 제거 → 재시도 | 서버 오류, 주문/재고 모두 이전 상태, 복구 후 200·재고 한 번 복구 | 장애·복구 API 워크플로 / `test_cancellation.py` | 실제 주문 UPDATE 뒤 실패 주입; 오류 본문 정책은 발명하지 않음 |
| `test_concurrent_owner_requests_restore_inventory_once` | 정확히 한 번 재고 복구 / Alice | 별도 TestClient 2개를 barrier 뒤 동시 취소 → 재조회 | 둘 다 같은 200 본문, 재고 5, 주문 1만 변경 | 동시 API 통합 / `test_cancellation.py` | 한 번의 동시 실행 관찰이며 모든 스케줄의 증명은 아님 |

## 변경 책임과 남는 범위

기존 `test_reads.py`의 두 케이스·기대값·픽스처는 그대로 유지한다. 제품 코드, README 계약, 수집 설정도 변경하지 않는다. skip/xfail, 재시도에 의한 실패 은폐, 정책 mock은 추가하지 않는다. 새 테스트의 SQLite 연결을 `closing`으로 정리한 것은 Windows 임시 DB 삭제 오류를 고친 테스트 자원 관리 변경이며 계약/기대값을 완화하지 않았다.

X-Session은 README에 명시된 서버 SESSIONS 기반 테스트 신원 경계다. 실제 로그인·세션 만료·브라우저 UI·실제 외부 서비스는 검증하지 않는다. fixture에 UI·결제/환불 연동은 없으며 새 역할이나 환불 정책을 만들지 않았다. 전체 상태 비교는 주문과 재고 모두에 적용한다. 내부 정책/트랜잭션은 실제로 실행하고 재고 실패만 테스트 DB trigger로 주입한다. 서비스 재시작·프로세스 장애 및 모든 동시 스케줄은 이 테스트 범위 밖이다.
