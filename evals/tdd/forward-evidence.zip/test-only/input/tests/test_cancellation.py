import sqlite3
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
from pathlib import Path
from threading import Barrier

from fastapi.testclient import TestClient

from app import create_app


class CancellationWorkflows(unittest.TestCase):
    """Real API/policy/SQLite flows; X-Session is only the fixture's identity boundary."""

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.db = Path(self.temp.name) / 'orders.db'
        self.app = create_app(self.db)
        self.client = TestClient(self.app, raise_server_exceptions=False)
        self.addCleanup(self.client.close)

    def headers(self, session):
        return {} if session is None else {'X-Session': session}

    def snapshot(self):
        with closing(sqlite3.connect(self.db)) as conn:
            return {
                'orders': conn.execute('SELECT * FROM orders ORDER BY id').fetchall(),
                'inventory': conn.execute('SELECT * FROM inventory ORDER BY sku').fetchall(),
            }

    def cancel(self, order_id, session='alice-session'):
        return self.client.post(f'/orders/{order_id}/cancel', headers=self.headers(session))

    def assert_reads(self, session, expected):
        """Check the list, every visible detail, and an invisible/missing detail."""
        response = self.client.get('/orders', headers=self.headers(session))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), expected)
        for row in expected:
            with self.subTest(read_detail=row['id'], session=session):
                detail = self.client.get(f"/orders/{row['id']}", headers=self.headers(session))
                self.assertEqual(detail.status_code, 200)
                self.assertEqual(detail.json(), row)
        denied_id = 2 if session == 'alice-session' else 1 if session == 'bob-session' else 999
        self.assertEqual(self.client.get(f'/orders/{denied_id}', headers=self.headers(session)).status_code, 404)

    def rows(self, state, session):
        columns = ('id', 'owner', 'sku', 'quantity', 'status')
        owner = {'alice-session': 'alice', 'bob-session': 'bob'}.get(session)
        return [dict(zip(columns, row)) for row in state['orders']
                if session == 'support-session' or row[1] == owner]

    def assert_all_reads(self, state):
        for session in ('alice-session', 'bob-session', 'support-session'):
            with self.subTest(reads_as=session):
                self.assert_reads(session, self.rows(state, session))

    def assert_success_state(self, before, order_id):
        expected = {
            'orders': [(*row[:-1], 'cancelled') if row[0] == order_id else row
                       for row in before['orders']],
            'inventory': [('tea', 3 + (2 if order_id == 1 else 1))],
        }
        self.assertEqual(self.snapshot(), expected)
        self.assert_all_reads(expected)
        return expected

    def assert_denied(self, order_id, session, status):
        before = self.snapshot()
        response = self.cancel(order_id, session)
        # Separate subtests retain both response and side-effect evidence on a defect.
        with self.subTest(response=status):
            self.assertEqual(response.status_code, status)
        with self.subTest(no_writes=True):
            self.assertEqual(self.snapshot(), before)
        self.assert_all_reads(before)

    def owner_workflow(self, session, order_id):
        before = self.snapshot()
        self.assert_reads(session, self.rows(before, session))
        response = self.cancel(order_id, session)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {'id': order_id, 'status': 'cancelled'})
        final = self.assert_success_state(before, order_id)
        repeated = self.cancel(order_id, session)
        self.assertEqual(repeated.status_code, 200)
        self.assertEqual(repeated.json(), response.json())
        self.assertEqual(self.snapshot(), final)
        self.assert_all_reads(final)

    def test_alice_reads_cancels_repeats_and_reads_final_state(self):
        self.owner_workflow('alice-session', 1)

    def test_bob_reads_cancels_repeats_and_reads_final_state(self):
        self.owner_workflow('bob-session', 2)

    def test_other_customer_cannot_cancel_reserved_order(self):
        self.assert_denied(1, 'bob-session', 404)

    def test_other_customer_cannot_repeat_owners_cancelled_order(self):
        before = self.snapshot()
        self.assertEqual(self.cancel(1).status_code, 200)
        self.assert_success_state(before, 1)
        self.assert_denied(1, 'bob-session', 404)

    def test_other_customers_shipped_order_is_hidden(self):
        self.assert_denied(3, 'bob-session', 404)

    def test_support_reads_all_but_cannot_cancel_any_order(self):
        for order_id in (1, 3):
            with self.subTest(order_id=order_id):
                self.assert_denied(order_id, 'support-session', 403)

    def test_missing_order_cannot_be_cancelled(self):
        self.assert_denied(999, 'alice-session', 404)

    def test_owner_cannot_cancel_shipped_order(self):
        self.assert_denied(3, 'alice-session', 409)

    def test_missing_or_unknown_session_cannot_write_then_owner_can_recover(self):
        before = self.snapshot()
        for session in (None, 'unknown-session'):
            with self.subTest(session=session):
                self.assert_denied(1, session, 401)
                for path in ('/orders', '/orders/1'):
                    self.assertEqual(self.client.get(path, headers=self.headers(session)).status_code, 401)
        self.assertEqual(self.cancel(1).status_code, 200)
        self.assert_success_state(before, 1)

    def test_stock_write_failure_rolls_back_order_and_allows_retry(self):
        before = self.snapshot()
        # Inject a database failure after the real order UPDATE; do not mock policy.
        with closing(sqlite3.connect(self.db)) as conn, conn:
            conn.executescript("""
                CREATE TRIGGER fail_stock BEFORE UPDATE ON inventory
                BEGIN SELECT RAISE(ABORT, 'simulated stock write failure'); END;
            """)
        response = self.cancel(1)
        self.assertGreaterEqual(response.status_code, 500)
        self.assertLess(response.status_code, 600)
        self.assertEqual(self.snapshot(), before)
        self.assert_all_reads(before)
        with closing(sqlite3.connect(self.db)) as conn, conn:
            conn.execute('DROP TRIGGER fail_stock')
        response = self.cancel(1)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {'id': 1, 'status': 'cancelled'})
        self.assert_success_state(before, 1)

    def test_concurrent_owner_requests_restore_inventory_once(self):
        before = self.snapshot()
        start = Barrier(2)

        def request_cancel():
            with TestClient(self.app, raise_server_exceptions=False) as client:
                start.wait(timeout=5)
                return client.post('/orders/1/cancel', headers=self.headers('alice-session'))

        with ThreadPoolExecutor(max_workers=2) as pool:
            futures = [pool.submit(request_cancel) for _ in range(2)]
            responses = [future.result(timeout=10) for future in futures]
        for response in responses:
            self.assertEqual(response.status_code, 200)
            self.assertEqual(response.json(), {'id': 1, 'status': 'cancelled'})
        self.assert_success_state(before, 1)
