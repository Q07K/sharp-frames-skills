# 주문 취소 사례 목록

계약 원본: [README](../README.md). 아래 이름은 unittest의 안정적인 사례 ID이다.
실행 결과는 이 문서와 분리해 작업의 `../trace.md`와 `../evidence/`에 보관한다.

| 계약 / 위험 | 사용자·사전 상태와 연결된 흐름 | 기대 응답 및 영속 상태 | 테스트 (`test_cancellation.CancellationFlows`) |
| --- | --- | --- | --- |
| 소유 고객 취소·반복 / 이중 재고 복구 | Alice 조회 → 1번 reserved 취소 → 조회 → 반복 → 지원 조회 | 200 동일 본문, cancelled, tea 3→5→5, 다른 주문 보존 | `test_owner_cancels_then_repeats_without_double_restock` |
| 소유권 경계 / 타인 주문 유출·변경 | Bob 조회 → Alice 주문 거부 → Bob 주문 취소 → Alice의 Bob 주문 거부 | 타인 404, 거부 시 전체 DB 동일, 본인 주문 200·재고 +1, 조회 경계 유지 | `test_other_customer_denial_then_own_cancellation` |
| 지원 읽기 전용 | 지원 전체 목록·상세 → reserved/shipped/누락 취소 거부 → 고객 취소 후 지원 재시도 | 항상 403, 거부 시 전체 DB 동일, 지원은 변경 후에도 모든 주문 조회 | `test_support_reads_all_but_cannot_cancel_any_state` |
| 인증 / 클라이언트 이름을 신뢰하지 않음 | 누락·미등록·사용자명 세션으로 목록·상세·취소 요청 → 정상 세션 조회 | 401, 전체 DB 동일, 정상 조회 유지 | `test_missing_and_unknown_sessions_cannot_read_or_write` |
| 누락 주문 | Alice 누락 취소 → 누락 상세 → 기존 목록·상세 | 404, 전체 DB 동일 | `test_missing_order_does_not_change_state_or_reads` |
| 배송 완료 불변 | Alice 조회 → shipped 취소 2회 → 매회 조회 | 409, 전체 DB 동일 | `test_shipped_order_denial_preserves_state_and_reads` |
| 원자성 / 쓰기 도중 실패 | SQLite 트리거로 재고 UPDATE 실패 → 조회 → 원인 제거 → 재시도 | 실패 500, 주문·재고 모두 복구, 재시도 200·정확한 재고 | `test_inventory_failure_rolls_back_order_and_allows_retry` |
| 동시 반복 / 경쟁 상태 | 네 개의 실제 API 클라이언트가 같은 주문 동시 취소 → 두 고객 조회 | 네 요청 200 동일 본문, cancelled, 재고 총 +2 한 번 | `test_simultaneous_owner_retries_restore_stock_once` |
| 기존 조회 회귀 | Alice 소유 목록, Bob 타인 상세 접근 | 기존 기대 200/[1,3], 404 그대로 | `test_reads.ExistingReads.test_owner_reads_own_orders`, `test_other_customer_cannot_read_order` |

범위: 실제 FastAPI TestClient 및 파일 SQLite 통합 검증. 브라우저 UI·운영 인증·외부 결제/환불은 이 fixture 계약에 없다. 동시성 검증은 이 호스트의 네 요청이며 운영 부하/다른 DB 격리 수준을 증명하지 않는다. 별도 설치·skip·기존 테스트 변경은 없다.
