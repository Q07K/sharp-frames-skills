import sqlite3
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
from pathlib import Path
from threading import Barrier

from fastapi.testclient import TestClient

from app import create_app


class CancellationFlows(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.db = Path(self.temp.name) / 'orders.db'
        self.app = create_app(self.db)
        self.client = TestClient(self.app)
        self.addCleanup(self.client.close)

    def headers(self, user):
        return {'X-Session': f'{user}-session'}

    def persisted_state(self):
        with closing(sqlite3.connect(self.db)) as conn:
            return (
                conn.execute('SELECT * FROM orders ORDER BY id').fetchall(),
                conn.execute('SELECT * FROM inventory ORDER BY sku').fetchall(),
            )

    def assert_cancelled(self, response, order_id):
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {'id': order_id, 'status': 'cancelled'})

    def assert_reads(self, user, expected_statuses):
        response = self.client.get('/orders', headers=self.headers(user))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            {order['id']: order['status'] for order in response.json()},
            expected_statuses,
        )
        for order in response.json():
            detail = self.client.get(f"/orders/{order['id']}", headers=self.headers(user))
            self.assertEqual(detail.status_code, 200)
            self.assertEqual(detail.json(), order)

    def test_owner_cancels_then_repeats_without_double_restock(self):
        self.assert_reads('alice', {1: 'reserved', 3: 'shipped'})
        self.assert_cancelled(
            self.client.post('/orders/1/cancel', headers=self.headers('alice')), 1
        )
        expected_state = (
            [(1, 'alice', 'tea', 2, 'cancelled'),
             (2, 'bob', 'tea', 1, 'reserved'),
             (3, 'alice', 'tea', 1, 'shipped')],
            [('tea', 5)],
        )
        self.assertEqual(self.persisted_state(), expected_state)
        self.assert_reads('alice', {1: 'cancelled', 3: 'shipped'})
        self.assert_cancelled(
            self.client.post('/orders/1/cancel', headers=self.headers('alice')), 1
        )
        self.assertEqual(self.persisted_state(), expected_state)
        self.assert_reads('alice', {1: 'cancelled', 3: 'shipped'})
        self.assert_reads('support', {1: 'cancelled', 2: 'reserved', 3: 'shipped'})

    def test_other_customer_denial_then_own_cancellation(self):
        initial = self.persisted_state()
        self.assert_reads('bob', {2: 'reserved'})
        denied = self.client.post('/orders/1/cancel', headers=self.headers('bob'))
        self.assertEqual(denied.status_code, 404)
        self.assertEqual(self.persisted_state(), initial)
        self.assertEqual(
            self.client.get('/orders/1', headers=self.headers('bob')).status_code, 404
        )
        self.assert_reads('bob', {2: 'reserved'})
        self.assert_cancelled(
            self.client.post('/orders/2/cancel', headers=self.headers('bob')), 2
        )
        after_bob = self.persisted_state()
        self.assertEqual(after_bob[1], [('tea', 4)])
        self.assert_reads('bob', {2: 'cancelled'})
        self.assert_reads('alice', {1: 'reserved', 3: 'shipped'})
        self.assertEqual(
            self.client.post('/orders/2/cancel', headers=self.headers('alice')).status_code,
            404,
        )
        self.assertEqual(self.persisted_state(), after_bob)
        self.assertEqual(
            self.client.get('/orders/2', headers=self.headers('alice')).status_code, 404
        )

    def test_support_reads_all_but_cannot_cancel_any_state(self):
        self.assert_reads('support', {1: 'reserved', 2: 'reserved', 3: 'shipped'})
        before = self.persisted_state()
        for order_id in (1, 2, 3, 999):
            with self.subTest(order_id=order_id):
                response = self.client.post(
                    f'/orders/{order_id}/cancel', headers=self.headers('support')
                )
                self.assertEqual(response.status_code, 403)
                self.assertEqual(self.persisted_state(), before)
        self.assert_reads('support', {1: 'reserved', 2: 'reserved', 3: 'shipped'})
        self.assert_cancelled(
            self.client.post('/orders/1/cancel', headers=self.headers('alice')), 1
        )
        after_owner = self.persisted_state()
        self.assertEqual(
            self.client.post('/orders/1/cancel', headers=self.headers('support')).status_code,
            403,
        )
        self.assertEqual(self.persisted_state(), after_owner)
        self.assert_reads('support', {1: 'cancelled', 2: 'reserved', 3: 'shipped'})

    def test_missing_and_unknown_sessions_cannot_read_or_write(self):
        before = self.persisted_state()
        for headers in ({}, {'X-Session': 'unknown'}, {'X-Session': 'alice'}):
            for method, path in (
                ('get', '/orders'), ('get', '/orders/1'),
                ('post', '/orders/1/cancel'), ('post', '/orders/999/cancel'),
            ):
                with self.subTest(headers=headers, method=method, path=path):
                    response = getattr(self.client, method)(path, headers=headers)
                    self.assertEqual(response.status_code, 401)
                    self.assertEqual(self.persisted_state(), before)
        self.assert_reads('alice', {1: 'reserved', 3: 'shipped'})

    def test_missing_order_does_not_change_state_or_reads(self):
        before = self.persisted_state()
        response = self.client.post('/orders/999/cancel', headers=self.headers('alice'))
        self.assertEqual(response.status_code, 404)
        self.assertEqual(self.persisted_state(), before)
        self.assertEqual(
            self.client.get('/orders/999', headers=self.headers('alice')).status_code, 404
        )
        self.assert_reads('alice', {1: 'reserved', 3: 'shipped'})

    def test_shipped_order_denial_preserves_state_and_reads(self):
        self.assert_reads('alice', {1: 'reserved', 3: 'shipped'})
        before = self.persisted_state()
        for _ in range(2):
            response = self.client.post('/orders/3/cancel', headers=self.headers('alice'))
            self.assertEqual(response.status_code, 409)
            self.assertEqual(self.persisted_state(), before)
            self.assert_reads('alice', {1: 'reserved', 3: 'shipped'})

    def test_inventory_failure_rolls_back_order_and_allows_retry(self):
        with closing(sqlite3.connect(self.db)) as conn:
            conn.executescript("""
                CREATE TRIGGER reject_restock BEFORE UPDATE ON inventory
                BEGIN SELECT RAISE(ABORT, 'fixture restock failure'); END;
            """)
        before = self.persisted_state()
        with TestClient(self.app, raise_server_exceptions=False) as client:
            response = client.post('/orders/1/cancel', headers=self.headers('alice'))
        self.assertEqual(response.status_code, 500)
        self.assertEqual(self.persisted_state(), before)
        self.assert_reads('alice', {1: 'reserved', 3: 'shipped'})
        with closing(sqlite3.connect(self.db)) as conn:
            conn.execute('DROP TRIGGER reject_restock')
            conn.commit()
        self.assert_cancelled(
            self.client.post('/orders/1/cancel', headers=self.headers('alice')), 1
        )
        self.assertEqual(self.persisted_state()[1], [('tea', 5)])
        self.assert_reads('alice', {1: 'cancelled', 3: 'shipped'})

    def test_simultaneous_owner_retries_restore_stock_once(self):
        barrier = Barrier(4)

        def cancel():
            with TestClient(self.app) as client:
                barrier.wait(timeout=5)
                return client.post('/orders/1/cancel', headers=self.headers('alice'))

        with ThreadPoolExecutor(max_workers=4) as executor:
            futures = [executor.submit(cancel) for _ in range(4)]
            responses = [future.result(timeout=15) for future in futures]
        for response in responses:
            self.assert_cancelled(response, 1)
        self.assertEqual(self.persisted_state()[1], [('tea', 5)])
        self.assert_reads('alice', {1: 'cancelled', 3: 'shipped'})
        self.assert_reads('bob', {2: 'reserved'})
