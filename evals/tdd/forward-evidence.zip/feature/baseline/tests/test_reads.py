import sqlite3
import tempfile
import unittest
from pathlib import Path

from fastapi.testclient import TestClient
from app import create_app

class ExistingReads(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.db = Path(self.temp.name) / 'orders.db'
        self.client = TestClient(create_app(self.db))
        self.addCleanup(self.client.close)

    def test_owner_reads_own_orders(self):
        result = self.client.get('/orders', headers={'X-Session': 'alice-session'})
        self.assertEqual(result.status_code, 200)
        self.assertEqual([row['id'] for row in result.json()], [1, 3])

    def test_other_customer_cannot_read_order(self):
        result = self.client.get('/orders/1', headers={'X-Session': 'bob-session'})
        self.assertEqual(result.status_code, 404)
