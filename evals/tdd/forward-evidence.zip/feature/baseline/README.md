# Synthetic order cancellation contract

This isolated FastAPI/SQLite fixture is not a production service.
Python 3.12; run: python -B -m unittest discover -s tests -v.
X-Session is a test-only token resolved by the server-side SESSIONS table;
it is not a claim of production authentication coverage.

- Customers may cancel only their own reserved order. Success is 200 with
  {"id": order_id, "status": "cancelled"}.
- Cancellation changes the order and restores its quantity to inventory exactly
  once. Repeating the same customer's cancellation returns that same 200 body
  without restoring stock again.
- Other customers' orders and missing orders return 404 without writes.
- The support role can read all orders but cancellation returns 403 without writes.
- Missing/unknown sessions return 401 without writes.
- Shipped orders return 409 without writes. No payment/refund integration exists.
- Existing list/detail behavior remains, including after denial or repeat actions.
- A failed request must not leave a partial order/stock change. Order status and
  stock are one SQLite transaction. Tests use disposable database files.
- No new roles, override privileges or refund policy should be invented.

Use existing unittest/TestClient conventions. Tests are regression obligations,
not disposable scaffolding. Requirement changes need an explicit rationale.
