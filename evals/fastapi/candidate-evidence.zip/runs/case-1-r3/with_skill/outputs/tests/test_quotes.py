import tempfile
import unittest
from pathlib import Path

from fastapi.testclient import TestClient

from store.api import create_app
from store.db import initialize, session


class QuoteBehavior(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.temp.name) / 'store.sqlite')
        initialize(self.path)
        self.client = TestClient(create_app(self.path))
        self.headers = {'Authorization': 'Bearer alice'}

    def tearDown(self):
        self.client.close()
        self.temp.cleanup()

    def snapshot(self):
        with session(self.path) as connection:
            return list(connection.iterdump())

    def test_quote_matches_order_and_ignores_client_prices_and_tier(self):
        basket = {
            'lines': [{'sku': 'A', 'quantity': 2, 'price_won': 1}],
            'coupon_code': 'SAVE500',
            'tier': 'regular',
            'subtotal_won': 1,
            'total_won': 1,
        }
        before = self.snapshot()
        response = self.client.post('/quotes', headers=self.headers, json=basket)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {
            'subtotal_won': 2002, 'discount_won': 701,
            'shipping_won': 700, 'total_won': 2001,
        })
        self.assertEqual(self.snapshot(), before)
        order = self.client.post('/orders', headers=self.headers, json=basket)
        self.assertEqual(order.status_code, 201)
        self.assertEqual({key: order.json()[key] for key in response.json()}, response.json())

    def test_regular_user_cannot_claim_vip_discount(self):
        basket = {'lines': [{'sku': 'B', 'quantity': 2}], 'tier': 'vip'}
        headers = {'Authorization': 'Bearer bob'}
        response = self.client.post('/quotes', headers=headers, json=basket)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {
            'subtotal_won': 5006, 'discount_won': 0,
            'shipping_won': 700, 'total_won': 5706,
        })
        order = self.client.post('/orders', headers=headers, json=basket)
        self.assertEqual(order.status_code, 201)
        self.assertEqual(order.json()['total_won'], response.json()['total_won'])

    def test_shipping_threshold_after_discounts_and_coupon_floor(self):
        with session(self.path) as connection:
            connection.execute("UPDATE products SET price_won = 10000 WHERE sku = 'A'")
            connection.execute("UPDATE products SET price_won = 100 WHERE sku = 'B'")
            connection.commit()
        scenarios = [
            ('bob', 'A', None, (10000, 0, 0, 10000)),
            ('bob', 'A', 'SAVE500', (10000, 500, 700, 10200)),
            ('alice', 'A', None, (10000, 1000, 700, 9700)),
            ('alice', 'B', 'SAVE500', (100, 100, 700, 700)),
        ]
        for token, sku, coupon, expected in scenarios:
            with self.subTest(token=token, sku=sku, coupon=coupon):
                basket = {'lines': [{'sku': sku, 'quantity': 1}], 'coupon_code': coupon}
                headers = {'Authorization': f'Bearer {token}'}
                before = self.snapshot()
                quote = self.client.post('/quotes', headers=headers, json=basket)
                self.assertEqual(quote.status_code, 200)
                self.assertEqual(quote.json(), dict(zip(
                    ('subtotal_won', 'discount_won', 'shipping_won', 'total_won'), expected)))
                self.assertEqual(self.snapshot(), before)
                order = self.client.post('/orders', headers=headers, json=basket)
                self.assertEqual(order.status_code, 201)
                self.assertEqual(order.json()['total_won'], quote.json()['total_won'])

    def test_input_product_and_coupon_errors_match_orders_without_mutation(self):
        invalid_baskets = [
            {}, {'lines': []},
            {'lines': [{'sku': '', 'quantity': 1}]},
            {'lines': [{'sku': 'A', 'quantity': 1}] * 51},
            {'lines': [{'sku': 'missing', 'quantity': 1}]},
            {'lines': [{'sku': 'A', 'quantity': 1}], 'coupon_code': 'NOPE'},
            {'lines': [{'sku': 'missing', 'quantity': 1}], 'coupon_code': 'NOPE'},
        ]
        invalid_baskets.extend(
            {'lines': [{'sku': 'A', 'quantity': quantity}]}
            for quantity in (True, 0, -1, 101, 1.5, '2', None)
        )
        before = self.snapshot()
        for basket in invalid_baskets:
            with self.subTest(basket=basket):
                quote = self.client.post('/quotes', headers=self.headers, json=basket)
                order = self.client.post('/orders', headers=self.headers, json=basket)
                self.assertIn(quote.status_code, (404, 422))
                self.assertEqual(quote.status_code, order.status_code)
                self.assertEqual(quote.json(), order.json())
                self.assertEqual(self.snapshot(), before)

    def test_authentication_matches_orders(self):
        basket = {'lines': [{'sku': 'A', 'quantity': 1}]}
        before = self.snapshot()
        for headers in ({}, {'Authorization': 'Basic alice'}, {'Authorization': 'Bearer invalid'}):
            with self.subTest(headers=headers):
                quote = self.client.post('/quotes', headers=headers, json=basket)
                order = self.client.post('/orders', headers=headers, json=basket)
                self.assertEqual(quote.status_code, 401)
                self.assertEqual(quote.status_code, order.status_code)
                self.assertEqual(quote.json(), order.json())
        self.assertEqual(self.snapshot(), before)

    def test_quotes_do_not_reserve_or_decrement_stock(self):
        basket = {'lines': [{'sku': 'A', 'quantity': 99}]}
        before = self.snapshot()
        for _ in range(2):
            response = self.client.post('/quotes', headers=self.headers, json=basket)
            self.assertEqual(response.status_code, 200)
        self.assertEqual(self.snapshot(), before)


if __name__ == '__main__':
    unittest.main()
