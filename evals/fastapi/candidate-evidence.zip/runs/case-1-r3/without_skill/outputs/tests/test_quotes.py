import tempfile
import unittest
from pathlib import Path

from fastapi.testclient import TestClient

from store.api import create_app
from store.db import initialize, session


class QuotesBehavior(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.temp.name) / 'store.sqlite')
        initialize(self.path)
        self.client = TestClient(create_app(self.path))
        self.headers = {'Authorization': 'Bearer alice'}

    def tearDown(self):
        self.client.close()
        self.temp.cleanup()

    def snapshot(self):
        with session(self.path) as connection:
            return '\n'.join(connection.iterdump())

    def test_quote_matches_orders_across_pricing_rules(self):
        cases = [
            ('alice', [{'sku': 'A', 'quantity': 2}], 'SAVE500', (2002, 701, 700, 2001)),
            ('bob', [{'sku': 'A', 'quantity': 2}], None, (2002, 0, 700, 2702)),
            ('alice', [{'sku': 'A', 'quantity': 1}], None, (1001, 101, 700, 1600)),
            ('bob', [{'sku': 'B', 'quantity': 4}], None, (10012, 0, 0, 10012)),
            ('bob', [{'sku': 'B', 'quantity': 4}], 'SAVE500', (10012, 500, 700, 10212)),
            ('alice', [{'sku': 'A', 'quantity': 1}, {'sku': 'B', 'quantity': 1}], None, (3504, 351, 700, 3853)),
        ]
        for token, lines, coupon, expected in cases:
            with self.subTest(token=token, lines=lines, coupon=coupon):
                # Each case starts with sufficient inventory for a real order.
                with session(self.path) as connection:
                    with connection:
                        connection.execute('UPDATE products SET stock = 100')
                headers = {'Authorization': f'Bearer {token}'}
                basket = {'lines': lines, 'coupon_code': coupon}
                before = self.snapshot()
                quote = self.client.post('/quotes', headers=headers, json=basket)
                self.assertEqual(quote.status_code, 200)
                self.assertEqual(self.snapshot(), before)
                self.assertEqual(quote.json(), dict(zip(
                    ('subtotal_won', 'discount_won', 'shipping_won', 'total_won'), expected)))
                order = self.client.post('/orders', headers=headers, json=basket)
                self.assertEqual(order.status_code, 201)
                self.assertEqual(quote.json(), {key: value for key, value in order.json().items() if key != 'id'})

    def test_prices_and_tier_come_from_server(self):
        basket = {
            'lines': [{'sku': 'A', 'quantity': 2, 'price_won': 1, 'unit_price': 1}],
            'tier': 'vip', 'price_won': 1, 'total_won': 0,
            'actor': {'tier': 'vip'},
        }
        headers = {'Authorization': 'Bearer bob'}
        quote = self.client.post('/quotes', headers=headers, json=basket)
        self.assertEqual(quote.status_code, 200)
        self.assertEqual(quote.json(), {
            'subtotal_won': 2002, 'discount_won': 0, 'shipping_won': 700, 'total_won': 2702,
        })
        order = self.client.post('/orders', headers=headers, json=basket)
        self.assertEqual(order.status_code, 201)
        self.assertEqual(order.json()['total_won'], quote.json()['total_won'])

    def test_coupon_clamps_discount_at_zero(self):
        with session(self.path) as connection:
            with connection:
                connection.execute("UPDATE products SET price_won = 100 WHERE sku = 'A'")
        basket = {'lines': [{'sku': 'A', 'quantity': 1}], 'coupon_code': 'SAVE500'}
        before = self.snapshot()
        quote = self.client.post('/quotes', headers=self.headers, json=basket)
        self.assertEqual(quote.status_code, 200)
        self.assertEqual(quote.json(), {
            'subtotal_won': 100, 'discount_won': 100, 'shipping_won': 700, 'total_won': 700,
        })
        self.assertEqual(self.snapshot(), before)
        order = self.client.post('/orders', headers=self.headers, json=basket)
        self.assertEqual(order.status_code, 201)
        self.assertEqual(order.json()['total_won'], 700)

    def test_errors_match_orders_and_leave_database_unchanged(self):
        invalid_baskets = [
            {}, {'lines': []}, {'lines': [{'sku': '', 'quantity': 1}]},
            {'lines': [{'sku': 'A', 'quantity': 1}] * 51},
            {'lines': [{'sku': 'missing', 'quantity': 1}]},
            {'lines': [{'sku': 'A', 'quantity': 1}], 'coupon_code': 'BAD'},
            {'lines': [{'sku': 'A', 'quantity': 1}], 'coupon_code': 12},
            {'lines': [{'sku': 'missing', 'quantity': 1}], 'coupon_code': 'BAD'},
        ]
        invalid_baskets.extend(
            {'lines': [{'sku': 'A', 'quantity': value}]}
            for value in (True, False, 0, -1, 101, 1.5, '2', None)
        )
        for basket in invalid_baskets:
            with self.subTest(basket=basket):
                before = self.snapshot()
                quote = self.client.post('/quotes', headers=self.headers, json=basket)
                order = self.client.post('/orders', headers=self.headers, json=basket)
                self.assertEqual(quote.status_code, order.status_code)
                self.assertIn(quote.status_code, (404, 422))
                self.assertEqual(quote.json(), order.json())
                self.assertEqual(self.snapshot(), before)

    def test_authentication_matches_orders(self):
        basket = {'lines': [{'sku': 'A', 'quantity': 1}]}
        for authorization in (None, 'Basic alice', 'Bearer missing', 'Bearer '):
            headers = {} if authorization is None else {'Authorization': authorization}
            with self.subTest(authorization=authorization):
                before = self.snapshot()
                quote = self.client.post('/quotes', headers=headers, json=basket)
                order = self.client.post('/orders', headers=headers, json=basket)
                self.assertEqual(quote.status_code, 401)
                self.assertEqual(order.status_code, quote.status_code)
                self.assertEqual(order.json(), quote.json())
                self.assertEqual(self.snapshot(), before)

    def test_repeated_quotes_do_not_reserve_inventory(self):
        basket = {'lines': [{'sku': 'A', 'quantity': 2}, {'sku': 'A', 'quantity': 1}]}
        before = self.snapshot()
        responses = [self.client.post('/quotes', headers=self.headers, json=basket) for _ in range(3)]
        for response in responses:
            self.assertEqual(response.status_code, 200)
            self.assertEqual(response.json(), responses[0].json())
        self.assertEqual(self.snapshot(), before)
        order = self.client.post('/orders', headers=self.headers, json=basket)
        self.assertEqual(order.status_code, 201)
        self.assertEqual(order.json()['total_won'], responses[0].json()['total_won'])


if __name__ == '__main__':
    unittest.main()
