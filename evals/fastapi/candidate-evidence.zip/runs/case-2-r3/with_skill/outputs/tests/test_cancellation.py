import json
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from threading import Barrier

from fastapi.testclient import TestClient

from store.api import create_app
from store.db import initialize, session


class CancellationBehavior(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.temp.name) / 'store.sqlite')
        initialize(self.path)
        self.app = create_app(self.path)
        self.client = TestClient(self.app, raise_server_exceptions=False)

    def tearDown(self):
        self.client.close()
        self.temp.cleanup()

    def cancel(self, order_id=10, key='cancel-1', token='alice'):
        return self.client.post(
            f'/orders/{order_id}/cancel',
            headers={'Authorization': f'Bearer {token}', 'Idempotency-Key': key},
        )

    def assert_initial_state(self):
        with session(self.path) as connection:
            self.assertEqual(connection.execute('SELECT status FROM orders WHERE id=10').fetchone()[0], 'paid')
            self.assertEqual(connection.execute("SELECT stock FROM products WHERE sku='A'").fetchone()[0], 10)
            self.assertEqual(connection.execute('SELECT COUNT(*) FROM stock_movements').fetchone()[0], 0)
            self.assertEqual(connection.execute('SELECT COUNT(*) FROM cancel_requests').fetchone()[0], 0)

    def test_cancel_restores_each_product_and_persists_response(self):
        with session(self.path) as connection, connection:
            connection.execute("INSERT INTO order_lines VALUES (10, 'A', 1), (10, 'B', 3)")
        response = self.cancel()
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {'id': 10, 'status': 'canceled'})
        with session(self.path) as connection:
            self.assertEqual(connection.execute('SELECT status FROM orders WHERE id=10').fetchone()[0], 'canceled')
            self.assertEqual([tuple(row) for row in connection.execute('SELECT sku, stock FROM products ORDER BY sku')], [('A', 13), ('B', 11)])
            movements = connection.execute('SELECT order_id, sku, quantity, reason FROM stock_movements ORDER BY sku')
            self.assertEqual([tuple(row) for row in movements], [(10, 'A', 3, 'cancel'), (10, 'B', 3, 'cancel')])
            saved = connection.execute('SELECT * FROM cancel_requests').fetchone()
            self.assertEqual((saved['user_id'], saved['request_key'], saved['order_id']), (1, 'cancel-1', 10))
            self.assertEqual(json.loads(saved['response_json']), response.json())

    def test_retry_reuses_result_and_conflicts_do_not_change_stock(self):
        first = self.cancel()
        self.assertEqual(first.status_code, 200)
        # A fresh application instance must recover the persisted result.
        with TestClient(create_app(self.path)) as client:
            retry = client.post('/orders/10/cancel', headers={'Authorization': 'Bearer alice', 'Idempotency-Key': 'cancel-1'})
        self.assertEqual(retry.status_code, 200)
        self.assertEqual(retry.json(), first.json())
        self.assertEqual(self.cancel(order_id=11).status_code, 409)
        self.assertEqual(self.cancel(key='fresh-key').status_code, 409)
        with session(self.path) as connection:
            self.assertEqual(connection.execute("SELECT stock FROM products WHERE sku='A'").fetchone()[0], 12)
            self.assertEqual(connection.execute('SELECT status FROM orders WHERE id=11').fetchone()[0], 'paid')
            self.assertEqual(connection.execute('SELECT COUNT(*) FROM stock_movements').fetchone()[0], 1)
            self.assertEqual(connection.execute('SELECT COUNT(*) FROM cancel_requests').fetchone()[0], 1)

    def test_keys_are_scoped_to_authenticated_user(self):
        self.assertEqual(self.cancel().status_code, 200)
        self.assertEqual(self.cancel(order_id=20, token='bob').status_code, 200)
        self.assertEqual(self.cancel(order_id=12, token='manager').status_code, 200)
        with session(self.path) as connection:
            self.assertEqual(connection.execute('SELECT COUNT(*) FROM cancel_requests').fetchone()[0], 3)

    def test_access_matches_order_lookup(self):
        for token, order_id in [('alice', 12), ('alice', 20), ('manager', 20), ('bob', 10), ('alice', 999)]:
            with self.subTest(token=token, order=order_id):
                self.assertEqual(self.cancel(order_id=order_id, token=token).status_code, 404)
        for headers in [{'Idempotency-Key': 'k'}, {'Idempotency-Key': 'k', 'Authorization': 'Bearer bad'}]:
            self.assertEqual(self.client.post('/orders/10/cancel', headers=headers).status_code, 401)
        self.assert_initial_state()
        self.assertEqual(self.cancel(token='manager').status_code, 200)

    def test_header_validation_and_boundaries(self):
        self.assertEqual(self.client.post('/orders/10/cancel', headers={'Authorization': 'Bearer alice'}).status_code, 422)
        for key in ['', 'x' * 65, 'has space', 'has.dot', '한글', 'trailing\n']:
            # HTTPX rejects non-ASCII header values before sending; bytes exercise API validation.
            with self.subTest(key=key):
                headers = {b'Authorization': b'Bearer alice', b'Idempotency-Key': key.encode('utf-8')}
                self.assertEqual(self.client.post('/orders/10/cancel', headers=headers).status_code, 422)
        self.assert_initial_state()
        self.assertEqual(self.cancel(key='A').status_code, 200)
        self.assertEqual(self.cancel(order_id=11, key='aZ09_-' + 'x' * 58).status_code, 200)

    def test_other_status_is_not_cancelable(self):
        with session(self.path) as connection, connection:
            connection.execute("UPDATE orders SET status='pending' WHERE id=10")
        self.assertEqual(self.cancel().status_code, 409)
        with session(self.path) as connection:
            self.assertEqual(connection.execute('SELECT COUNT(*) FROM cancel_requests').fetchone()[0], 0)
            self.assertEqual(connection.execute('SELECT COUNT(*) FROM stock_movements').fetchone()[0], 0)

    def test_database_failure_rolls_back_every_write_and_key_can_retry(self):
        for table in ['orders', 'products', 'stock_movements', 'cancel_requests']:
            with self.subTest(table=table):
                operation = 'UPDATE' if table in ['orders', 'products'] else 'INSERT'
                with session(self.path) as connection, connection:
                    connection.execute(f"CREATE TRIGGER fail_cancel BEFORE {operation} ON {table} BEGIN SELECT RAISE(ABORT, 'injected failure'); END")
                self.assertEqual(self.cancel().status_code, 500)
                self.assert_initial_state()
                with session(self.path) as connection, connection:
                    connection.execute('DROP TRIGGER fail_cancel')
        self.assertEqual(self.cancel().status_code, 200)

    def test_concurrent_retries_only_apply_once(self):
        barrier = Barrier(6)

        def cancel_concurrently(_):
            with TestClient(self.app) as client:
                barrier.wait(timeout=10)
                return client.post('/orders/10/cancel', headers={'Authorization': 'Bearer alice', 'Idempotency-Key': 'concurrent'})

        with ThreadPoolExecutor(max_workers=6) as executor:
            responses = list(executor.map(cancel_concurrently, range(6)))
        self.assertEqual([response.status_code for response in responses], [200] * 6)
        self.assertTrue(all(response.json() == {'id': 10, 'status': 'canceled'} for response in responses))
        with session(self.path) as connection:
            self.assertEqual(connection.execute("SELECT stock FROM products WHERE sku='A'").fetchone()[0], 12)
            self.assertEqual(connection.execute('SELECT COUNT(*) FROM stock_movements').fetchone()[0], 1)
            self.assertEqual(connection.execute('SELECT COUNT(*) FROM cancel_requests').fetchone()[0], 1)


if __name__ == '__main__':
    unittest.main()
