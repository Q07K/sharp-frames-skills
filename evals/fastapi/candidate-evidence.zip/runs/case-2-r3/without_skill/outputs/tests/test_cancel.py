import json
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from threading import Barrier

from fastapi.testclient import TestClient
from store.api import create_app
from store.db import initialize, session


class CancelBehavior(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.temp.name) / 'store.sqlite')
        initialize(self.path)
        self.client = TestClient(create_app(self.path))

    def tearDown(self):
        self.client.close()
        self.temp.cleanup()

    def cancel(self, order_id=10, key='request-1', user='alice', client=None):
        headers = {'Authorization': f'Bearer {user}'}
        if key is not None:
            headers['Idempotency-Key'] = key
        return (client or self.client).post(f'/orders/{order_id}/cancel', headers=headers)

    def snapshot(self):
        with session(self.path) as connection:
            return {
                table: [tuple(row) for row in connection.execute(f'SELECT * FROM {table} ORDER BY rowid')]
                for table in ('orders', 'products', 'stock_movements', 'cancel_requests')
            }

    def test_cancel_multiple_products_and_replay(self):
        with session(self.path) as connection, connection:
            connection.executemany('INSERT INTO order_lines VALUES (10, ?, ?)', [('A', 1), ('B', 3)])
        response = self.cancel()
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {'id': 10, 'status': 'canceled'})
        with session(self.path) as connection:
            self.assertEqual(connection.execute('SELECT status FROM orders WHERE id=10').fetchone()[0], 'canceled')
            self.assertEqual([tuple(row) for row in connection.execute('SELECT sku, stock FROM products ORDER BY sku')], [('A', 13), ('B', 11)])
            self.assertEqual([tuple(row) for row in connection.execute('SELECT order_id, sku, quantity, reason FROM stock_movements ORDER BY sku')], [(10, 'A', 3, 'cancel'), (10, 'B', 3, 'cancel')])
            record = connection.execute('SELECT * FROM cancel_requests').fetchone()
            self.assertEqual((record['user_id'], record['request_key'], record['order_id']), (1, 'request-1', 10))
            self.assertEqual(json.loads(record['response_json']), response.json())
        after = self.snapshot()
        self.assertEqual(self.cancel().json(), response.json())
        self.assertEqual(self.cancel().status_code, 200)
        self.assertEqual(self.cancel(key='new-key').status_code, 409)
        self.assertEqual(self.cancel(order_id=11).status_code, 409)
        self.assertEqual(self.snapshot(), after)

    def test_visibility_and_authentication(self):
        before = self.snapshot()
        for order_id, user in [(20, 'alice'), (12, 'alice'), (10, 'bob'), (20, 'manager'), (999, 'alice')]:
            with self.subTest(order_id=order_id, user=user):
                self.assertEqual(self.cancel(order_id=order_id, user=user).status_code, 404)
        self.assertEqual(self.client.post('/orders/10/cancel', headers={'Idempotency-Key': 'a'}).status_code, 401)
        self.assertEqual(self.cancel(user='invalid').status_code, 401)
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(self.cancel(order_id=12, user='manager').status_code, 200)

    def test_key_validation_and_boundaries(self):
        before = self.snapshot()
        for key in [None, '', 'a' * 65, 'space key', 'x.y', 'x/y', 'x\n', b'\xe9']:
            with self.subTest(key=key):
                self.assertEqual(self.cancel(key=key).status_code, 422)
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(self.cancel(key='a').status_code, 200)
        self.assertEqual(self.cancel(order_id=11, key='AZaz09_-' * 8).status_code, 200)

    def test_key_scope_is_per_user(self):
        self.assertEqual(self.cancel().status_code, 200)
        self.assertEqual(self.cancel(order_id=20, user='bob').status_code, 200)
        self.assertEqual(self.cancel(order_id=12, user='manager').status_code, 200)
        after = self.snapshot()
        self.assertEqual(len(after['cancel_requests']), 3)
        self.assertEqual(self.cancel(user='manager').status_code, 409)
        self.assertEqual(self.snapshot(), after)

    def test_non_paid_order_conflicts(self):
        with session(self.path) as connection, connection:
            connection.execute("UPDATE orders SET status='pending' WHERE id=10")
        before = self.snapshot()
        self.assertEqual(self.cancel().status_code, 409)
        self.assertEqual(self.snapshot(), before)

    def test_failure_rolls_back_every_change_and_key_can_retry(self):
        with session(self.path) as connection, connection:
            connection.execute("INSERT INTO order_lines VALUES (10, 'B', 2)")
        for table, condition in [('products', "WHEN NEW.sku='B'"), ('stock_movements', "WHEN NEW.sku='B'"), ('cancel_requests', '')]:
            with self.subTest(table=table):
                before = self.snapshot()
                event = 'UPDATE' if table == 'products' else 'INSERT'
                with session(self.path) as connection:
                    connection.execute(f"CREATE TRIGGER reject_cancel BEFORE {event} ON {table} {condition} BEGIN SELECT RAISE(ABORT, 'injected failure'); END")
                with TestClient(create_app(self.path), raise_server_exceptions=False) as client:
                    self.assertEqual(self.cancel(client=client).status_code, 500)
                self.assertEqual(self.snapshot(), before)
                with session(self.path) as connection:
                    connection.execute('DROP TRIGGER reject_cancel')
        self.assertEqual(self.cancel().status_code, 200)

    def concurrent_cancel(self, requests):
        barrier = Barrier(len(requests))

        def invoke(request):
            with TestClient(create_app(self.path)) as client:
                barrier.wait(timeout=10)
                response = self.cancel(order_id=request[0], key=request[1], client=client)
                return response.status_code, response.json()

        with ThreadPoolExecutor(max_workers=len(requests)) as executor:
            return list(executor.map(invoke, requests))

    def test_concurrent_retries_change_stock_and_history_once(self):
        responses = self.concurrent_cancel([(10, 'same')] * 8)
        self.assertEqual(responses, [(200, {'id': 10, 'status': 'canceled'})] * 8)
        after = self.snapshot()
        self.assertEqual(after['products'][0][2], 12)
        self.assertEqual(len(after['stock_movements']), 1)
        self.assertEqual(len(after['cancel_requests']), 1)

    def test_concurrent_distinct_keys_for_same_order(self):
        responses = self.concurrent_cancel([(10, f'key-{n}') for n in range(8)])
        self.assertEqual(sorted(status for status, _ in responses), [200] + [409] * 7)
        after = self.snapshot()
        self.assertEqual(after['products'][0][2], 12)
        self.assertEqual(len(after['stock_movements']), 1)
        self.assertEqual(len(after['cancel_requests']), 1)

    def test_concurrent_same_key_for_different_orders(self):
        responses = self.concurrent_cancel([(10, 'same'), (11, 'same')])
        self.assertEqual(sorted(status for status, _ in responses), [200, 409])
        after = self.snapshot()
        self.assertEqual(len(after['stock_movements']), 1)
        self.assertEqual(len(after['cancel_requests']), 1)
        self.assertEqual(sum(row[3] == 'canceled' for row in after['orders']), 1)


if __name__ == '__main__':
    unittest.main()
