# Implementation report

Added `POST /orders/{order_id}/cancel` with required ASCII Idempotency-Key validation (1–64 letters, digits, hyphens, underscores). Reuses order visibility checks for members and tenant managers.

Cancellation restores grouped product quantities, records one cancel stock movement per product, and persists the original response under the actor’s key. SQLite `BEGIN IMMEDIATE` serializes competing writers; order, inventory, movements and key records commit or roll back together. Conflicting keys and non-paid orders return 409; matching retries return the saved 200 response.

Validation: `python -m unittest discover -s tests -v` passed all 12 tests (3 existing, 9 added). Coverage includes access boundaries, key validation and user scope, multiple products and duplicate lines, original-response retries, three concurrent request scenarios, and injected failures at product updates, movement insertion and key insertion. Initial run had a test-client Unicode-header encoding error; changed that test input to raw bytes and reran successfully.

Limits: concurrency checks use local SQLite and up to eight simultaneous requests. SQLite retains its existing 10-second lock timeout. The installed TestClient emits an httpx deprecation warning; tests pass.

