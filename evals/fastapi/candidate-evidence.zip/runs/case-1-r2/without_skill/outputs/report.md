Implemented `POST /quotes`, returning HTTP 200 with `subtotal_won`, `discount_won`, `shipping_won`, and `total_won`.

The endpoint shares basket validation, authentication, and authoritative database pricing with orders. It calls the existing read-only pricing function directly, without creating an order or changing inventory. Existing endpoints remain unchanged.

Validation: `python -m unittest discover -s tests -v` passed all 7 tests. Checks cover existing order/access behavior, exact totals and order parity for regular/VIP users and coupons, shipping thresholds, ignored caller prices/tiers, input/product/coupon/authentication error parity, and full database snapshots before/after repeated quotes and failures.

Limitations: quotes reflect prices at request time and do not reserve inventory. The existing TestClient dependency emitted an httpx deprecation warning; all tests completed successfully.
