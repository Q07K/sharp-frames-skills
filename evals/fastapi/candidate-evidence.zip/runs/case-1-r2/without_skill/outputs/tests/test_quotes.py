import tempfile
import unittest
from pathlib import Path

from fastapi.testclient import TestClient

from store.api import create_app
from store.db import initialize, session


class QuoteBehavior(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.temp.name) / 'store.sqlite')
        initialize(self.path)
        self.client = TestClient(create_app(self.path))
        self.headers = {'Authorization': 'Bearer alice'}

    def tearDown(self):
        self.client.close()
        self.temp.cleanup()

    def snapshot(self):
        with session(self.path) as connection:
            return list(connection.iterdump())

    def test_quote_matches_order_and_known_totals(self):
        cases = [
            ('alice', 2, 'SAVE500', (2002, 701, 700, 2001)),
            ('bob', 2, 'SAVE500', (2002, 500, 700, 2202)),
            ('alice', 1, None, (1001, 101, 700, 1600)),
            ('bob', 10, None, (10010, 0, 0, 10010)),
            ('alice', 10, None, (10010, 1001, 700, 9709)),
        ]
        for token, quantity, coupon, expected in cases:
            with self.subTest(token=token, quantity=quantity, coupon=coupon):
                headers = {'Authorization': f'Bearer {token}'}
                basket = {'lines': [{'sku': 'A', 'quantity': quantity}]}
                if coupon is not None:
                    basket['coupon_code'] = coupon
                before = self.snapshot()
                response = self.client.post('/quotes', headers=headers, json=basket)
                self.assertEqual(response.status_code, 200)
                totals = dict(zip(('subtotal_won', 'discount_won', 'shipping_won', 'total_won'), expected))
                self.assertEqual(response.json(), totals)
                self.assertEqual(self.snapshot(), before)
                order = self.client.post('/orders', headers=headers, json=basket)
                self.assertEqual(order.status_code, 201)
                self.assertEqual({key: order.json()[key] for key in totals}, totals)
                # Restore stock so each scenario remains independently orderable.
                with session(self.path) as connection:
                    connection.execute("UPDATE products SET stock = 10 WHERE sku = 'A'")
                    connection.commit()

    def test_untrusted_prices_and_tiers_are_ignored(self):
        basket = {
            'lines': [{'sku': 'A', 'quantity': 2, 'price_won': 0, 'unit_price': 0}],
            'tier': 'vip', 'price_won': 0, 'total_won': 0,
            'actor': {'id': 1, 'tier': 'vip'},
        }
        response = self.client.post('/quotes', headers={'Authorization': 'Bearer bob'}, json=basket)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {
            'subtotal_won': 2002, 'discount_won': 0, 'shipping_won': 700, 'total_won': 2702,
        })

    def test_repeated_quotes_do_not_change_any_database_state(self):
        before = self.snapshot()
        basket = {'lines': [{'sku': 'A', 'quantity': 6}, {'sku': 'A', 'quantity': 6}]}
        for _ in range(3):
            self.assertEqual(self.client.post('/quotes', headers=self.headers, json=basket).status_code, 200)
        self.assertEqual(self.snapshot(), before)

    def test_errors_match_orders_and_leave_database_unchanged(self):
        cases = [
            ({}, self.headers, 422),
            ({'lines': []}, self.headers, 422),
            ({'lines': [{'sku': '', 'quantity': 1}]}, self.headers, 422),
            ({'lines': [{'sku': 'missing', 'quantity': 1}]}, self.headers, 404),
            ({'lines': [{'sku': 'A', 'quantity': 1}], 'coupon_code': 'invalid'}, self.headers, 422),
            ({'lines': [{'sku': 'A', 'quantity': 1}]}, {}, 401),
            ({'lines': [{'sku': 'A', 'quantity': 1}]}, {'Authorization': 'Bearer invalid'}, 401),
            ({'lines': [{'sku': 'A', 'quantity': 1}]}, {'Authorization': 'alice'}, 401),
        ]
        cases.extend(
            ({'lines': [{'sku': 'A', 'quantity': quantity}]}, self.headers, 422)
            for quantity in (True, 0, -1, 101, 1.5, '2')
        )
        cases.append(({'lines': [{'sku': 'A', 'quantity': 1}] * 51}, self.headers, 422))
        before = self.snapshot()
        for basket, headers, status in cases:
            with self.subTest(basket=basket, headers=headers):
                quote = self.client.post('/quotes', headers=headers, json=basket)
                order = self.client.post('/orders', headers=headers, json=basket)
                self.assertEqual(quote.status_code, status)
                self.assertEqual(quote.status_code, order.status_code)
                self.assertEqual(quote.json(), order.json())
                self.assertEqual(self.snapshot(), before)
