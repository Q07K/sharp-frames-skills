# Changes

Added `POST /quotes` in `store/api.py`. It accepts the existing basket schema and returns the four won totals with HTTP 200. It shares authenticated user resolution and `price_basket` with orders, so database prices, membership discounts, coupon rules, rounding and shipping remain authoritative. It performs no writes and leaves existing APIs unchanged.

# Verification

Ran `python -m unittest discover -s tests -v` with the supplied runtime and dependency path, with temporary files inside `outputs/tmp`.

- Baseline: 3 tests passed.
- Final: all 10 tests passed (3 existing, 7 added).
- New integration checks cover quote/order parity, exact totals, VIP rounding, coupon and shipping behavior, multi-product baskets, ignored client price/tier/identity claims, matching authentication and validation/product/coupon errors, and unchanged complete SQLite dumps after repeated successful and failing quotes.
- Reviewed final implementation and tests for duplicate pricing policy, accidental writes and existing API changes.

# Limits

Tests use the provided local SQLite fixture. Prices are evaluated at request time; inventory reservation and concurrent price changes are outside this change. The existing TestClient stack emitted an httpx deprecation warning.

