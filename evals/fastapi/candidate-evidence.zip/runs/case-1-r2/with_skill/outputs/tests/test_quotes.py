import tempfile
import unittest
from pathlib import Path

from fastapi.testclient import TestClient

from store.api import create_app
from store.db import initialize, session


class Quotes(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.temp.name) / 'store.sqlite')
        initialize(self.path)
        self.client = TestClient(create_app(self.path))
        self.headers = {'Authorization': 'Bearer alice'}

    def tearDown(self):
        self.client.close()
        self.temp.cleanup()

    def snapshot(self):
        with session(self.path) as connection:
            return list(connection.iterdump())

    def assert_quote_matches_order(self, token, basket, expected):
        headers = {'Authorization': f'Bearer {token}'}
        before = self.snapshot()
        for _ in range(2):
            quote = self.client.post('/quotes', headers=headers, json=basket)
            self.assertEqual(quote.status_code, 200)
            self.assertEqual(quote.json(), dict(zip(
                ('subtotal_won', 'discount_won', 'shipping_won', 'total_won'),
                expected,
            )))
            self.assertEqual(self.snapshot(), before)
        order = self.client.post('/orders', headers=headers, json=basket)
        self.assertEqual(order.status_code, 201)
        self.assertEqual(quote.json(), {key: order.json()[key] for key in quote.json()})

    def test_vip_coupon_rounding_and_no_database_changes(self):
        self.assert_quote_matches_order(
            'alice', {'lines': [{'sku': 'A', 'quantity': 2}], 'coupon_code': 'SAVE500'},
            (2002, 701, 700, 2001),
        )

    def test_regular_free_shipping(self):
        self.assert_quote_matches_order(
            'bob', {'lines': [{'sku': 'B', 'quantity': 4}]}, (10012, 0, 0, 10012),
        )

    def test_shipping_threshold_uses_discounted_amount(self):
        self.assert_quote_matches_order(
            'alice', {'lines': [{'sku': 'B', 'quantity': 4}]}, (10012, 1002, 700, 9710),
        )

    def test_multiple_products(self):
        self.assert_quote_matches_order(
            'alice', {'lines': [{'sku': 'A', 'quantity': 1}, {'sku': 'B', 'quantity': 1}]},
            (3504, 351, 700, 3853),
        )

    def test_client_price_tier_and_identity_claims_have_no_authority(self):
        for token, expected in [('alice', 1600), ('bob', 1701)]:
            with self.subTest(token=token):
                before = self.snapshot()
                response = self.client.post('/quotes', headers={'Authorization': f'Bearer {token}'}, json={
                    'lines': [{'sku': 'A', 'quantity': 1, 'price_won': 1, 'unit_price': 1}],
                    'price_won': 1, 'tier': 'vip' if token == 'bob' else 'regular',
                    'user_id': 1, 'subtotal_won': 0, 'total_won': 0,
                })
                self.assertEqual(response.status_code, 200)
                self.assertEqual(response.json()['subtotal_won'], 1001)
                self.assertEqual(response.json()['total_won'], expected)
                self.assertEqual(self.snapshot(), before)

    def test_validation_product_and_coupon_errors_match_orders(self):
        cases = [
            ({}, 422),
            ({'lines': []}, 422),
            ({'lines': [{'sku': 'A', 'quantity': True}]}, 422),
            ({'lines': [{'sku': 'A', 'quantity': '1'}]}, 422),
            ({'lines': [{'sku': 'A', 'quantity': 0}]}, 422),
            ({'lines': [{'sku': 'A', 'quantity': 101}]}, 422),
            ({'lines': [{'sku': '', 'quantity': 1}]}, 422),
            ({'lines': [{'sku': 'A', 'quantity': 1}] * 51}, 422),
            ({'lines': [{'sku': 'missing', 'quantity': 1}]}, 404),
            ({'lines': [{'sku': 'A', 'quantity': 1}], 'coupon_code': 'invalid'}, 422),
            ({'lines': [{'sku': 'missing', 'quantity': 1}], 'coupon_code': 'invalid'}, 404),
        ]
        for basket, status in cases:
            with self.subTest(basket=basket):
                before = self.snapshot()
                quote = self.client.post('/quotes', headers=self.headers, json=basket)
                order = self.client.post('/orders', headers=self.headers, json=basket)
                self.assertEqual(quote.status_code, status)
                self.assertEqual(quote.status_code, order.status_code)
                self.assertEqual(quote.json(), order.json())
                self.assertEqual(self.snapshot(), before)

    def test_authentication_matches_orders(self):
        basket = {'lines': [{'sku': 'A', 'quantity': 1}]}
        for headers in [{}, {'Authorization': 'Basic alice'}, {'Authorization': 'Bearer invalid'}]:
            with self.subTest(headers=headers):
                before = self.snapshot()
                quote = self.client.post('/quotes', headers=headers, json=basket)
                order = self.client.post('/orders', headers=headers, json=basket)
                self.assertEqual(quote.status_code, 401)
                self.assertEqual(quote.status_code, order.status_code)
                self.assertEqual(quote.json(), order.json())
                self.assertEqual(self.snapshot(), before)


if __name__ == '__main__':
    unittest.main()
