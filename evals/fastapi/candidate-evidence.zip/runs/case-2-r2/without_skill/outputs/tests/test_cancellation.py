import json
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from threading import Barrier

from fastapi.testclient import TestClient
from store.api import create_app
from store.db import initialize, session


class CancellationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.temp.name) / 'store.sqlite')
        initialize(self.path)
        self.app = create_app(self.path)
        self.client = TestClient(self.app, raise_server_exceptions=False)

    def tearDown(self):
        self.client.close()
        self.temp.cleanup()

    def cancel(self, order=10, key='cancel-1', token='alice'):
        headers = {'Authorization': f'Bearer {token}'}
        if key is not None:
            headers['Idempotency-Key'] = key
        return self.client.post(f'/orders/{order}/cancel', headers=headers)

    def snapshot(self):
        with session(self.path) as connection:
            return {
                table: [tuple(row) for row in connection.execute(f'SELECT * FROM {table} ORDER BY 1, 2')]
                for table in ('orders', 'products', 'stock_movements', 'cancel_requests')
            }

    def test_cancel_aggregates_products_and_replays_saved_result(self):
        with session(self.path) as connection, connection:
            connection.execute("INSERT INTO order_lines VALUES (10, 'A', 3), (10, 'B', 2)")
        response = self.cancel()
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {'id': 10, 'status': 'canceled'})
        state = self.snapshot()
        self.assertEqual(self.cancel().json(), response.json())
        self.assertEqual(self.snapshot(), state)
        with session(self.path) as connection:
            self.assertEqual(connection.execute('SELECT status FROM orders WHERE id=10').fetchone()[0], 'canceled')
            self.assertEqual([tuple(r) for r in connection.execute('SELECT sku, stock FROM products ORDER BY sku')], [('A', 15), ('B', 10)])
            self.assertEqual([tuple(r) for r in connection.execute('SELECT sku, quantity, reason FROM stock_movements ORDER BY sku')], [('A', 5, 'cancel'), ('B', 2, 'cancel')])
            saved = connection.execute('SELECT * FROM cancel_requests').fetchone()
            self.assertEqual((saved['user_id'], saved['request_key'], saved['order_id']), (1, 'cancel-1', 10))
            self.assertEqual(json.loads(saved['response_json']), response.json())

    def test_conflicts_do_not_modify_state(self):
        self.assertEqual(self.cancel().status_code, 200)
        state = self.snapshot()
        self.assertEqual(self.cancel(order=11).status_code, 409)
        self.assertEqual(self.cancel(key='another').status_code, 409)
        self.assertEqual(self.snapshot(), state)

    def test_keys_are_scoped_to_actor(self):
        self.assertEqual(self.cancel().status_code, 200)
        self.assertEqual(self.cancel(order=20, token='bob').status_code, 200)
        self.assertEqual(self.cancel(order=12, token='manager').status_code, 200)
        with session(self.path) as connection:
            self.assertEqual(connection.execute('SELECT count(*) FROM cancel_requests').fetchone()[0], 3)

    def test_access_matches_order_read_including_replays(self):
        before = self.snapshot()
        for order, token in ((20, 'alice'), (12, 'alice'), (10, 'bob'), (20, 'manager'), (999, 'alice')):
            with self.subTest(order=order, token=token):
                self.assertEqual(self.cancel(order=order, token=token).status_code, 404)
        self.assertEqual(self.cancel(token='invalid').status_code, 401)
        self.assertEqual(self.client.post('/orders/10/cancel', headers={'Idempotency-Key': 'x'}).status_code, 401)
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(self.cancel().status_code, 200)
        with session(self.path) as connection, connection:
            connection.execute('UPDATE orders SET owner_id=4 WHERE id=10')
        self.assertEqual(self.cancel().status_code, 404)

    def test_header_validation_and_boundaries(self):
        before = self.snapshot()
        for key in (None, '', 'a' * 65, 'with space', 'a.b', 'a/b', 'a\nb', 'a\n', 'é'):
            with self.subTest(key=key):
                # HTTPX disallows non-ASCII header strings; raw bytes allow
                # exercising server validation of that invalid input.
                if key == 'é':
                    response = self.client.post('/orders/10/cancel', headers=[(b'Authorization', b'Bearer alice'), (b'Idempotency-Key', b'\xc3\xa9')])
                else:
                    response = self.cancel(key=key)
                self.assertEqual(response.status_code, 422)
                self.assertEqual(self.snapshot(), before)
        self.assertEqual(self.cancel(key='Z').status_code, 200)
        self.assertEqual(self.cancel(order=11, key='A0_-' * 16).status_code, 200)

    def test_non_paid_order_conflicts(self):
        with session(self.path) as connection, connection:
            connection.execute("UPDATE orders SET status='pending' WHERE id=10")
        before = self.snapshot()
        self.assertEqual(self.cancel().status_code, 409)
        self.assertEqual(self.snapshot(), before)

    def test_failure_rolls_back_every_write_then_retry_succeeds(self):
        before = self.snapshot()
        with session(self.path) as connection, connection:
            connection.execute("CREATE TRIGGER fail_cancel BEFORE INSERT ON cancel_requests BEGIN SELECT RAISE(ABORT, 'injected failure'); END")
        self.assertEqual(self.cancel().status_code, 500)
        self.assertEqual(self.snapshot(), before)
        with session(self.path) as connection, connection:
            connection.execute('DROP TRIGGER fail_cancel')
        self.assertEqual(self.cancel().status_code, 200)

    def run_concurrent(self, keys):
        barrier = Barrier(len(keys))

        def request(key):
            with TestClient(self.app) as client:
                barrier.wait(timeout=10)
                response = client.post('/orders/10/cancel', headers={'Authorization': 'Bearer alice', 'Idempotency-Key': key})
                return response.status_code, response.json()

        with ThreadPoolExecutor(max_workers=len(keys)) as executor:
            return list(executor.map(request, keys))

    def assert_single_restoration(self):
        with session(self.path) as connection:
            self.assertEqual(connection.execute("SELECT stock FROM products WHERE sku='A'").fetchone()[0], 12)
            self.assertEqual(connection.execute('SELECT count(*) FROM stock_movements').fetchone()[0], 1)
            self.assertEqual(connection.execute('SELECT count(*) FROM cancel_requests').fetchone()[0], 1)

    def test_concurrent_retries_restore_stock_once(self):
        self.assertEqual(self.run_concurrent(['same'] * 6), [(200, {'id': 10, 'status': 'canceled'})] * 6)
        self.assert_single_restoration()

    def test_concurrent_new_keys_have_one_winner(self):
        results = self.run_concurrent([f'key-{n}' for n in range(6)])
        self.assertEqual(sorted(status for status, _ in results), [200, 409, 409, 409, 409, 409])
        self.assert_single_restoration()


if __name__ == '__main__':
    unittest.main()
