Implemented `POST /orders/{order_id}/cancel` with the existing order visibility policy and required ASCII `Idempotency-Key` validation.

Cancellation acquires a SQLite write lock before reading cancellation state. It restores stock grouped by product, records one `cancel` movement per product, changes the order status, and stores the user-scoped response in a single transaction. Matching retries return the saved result; conflicting keys and non-paid orders return 409. Exceptions roll back every write.

Validation: `python -m unittest discover -s tests -v` passed all 12 tests (3 existing, 9 added). Tests cover access control, exact response and persistence, duplicate product lines, key boundaries, user scoping, conflicts, concurrent matching retries, concurrent distinct keys, and a database failure injected at the final key insert followed by a successful retry.

Limits: tested against the supplied local SQLite fixture and dependencies. SQLite serializes writers and retains the existing 10-second connection timeout. TestClient emitted the dependencies' HTTPX deprecation warning; tests passed. No network or external services were used.
