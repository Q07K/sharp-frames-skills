# Store API evaluation fixture

Small existing FastAPI application with SQLite. This is synthetic, not production.
Create databases with `store.db.initialize(path)` and apps with `store.api.create_app(path)`.
Bearer alice/bob/manager/charlie are fixture tokens; no external services.
Run `python -m unittest discover -s tests -v` with the supplied dependency path.
Keep existing API contracts and unrelated behavior. Add implementation and useful checks.

`POST /orders/{order_id}/cancel` uses the same visibility rules as order lookup.
Send a required `Idempotency-Key` of 1–64 ASCII letters, digits, hyphens or
underscores. Success returns `{"id": order_id, "status": "canceled"}` with 200.
The key is scoped to the authenticated user; repeating it for the same order
replays the saved result. Reusing it for another order, or canceling a non-paid
order with a new key, returns 409. Invalid or missing keys return 422.
Cancellation, stock restoration, per-product cancel movements and the saved
response commit together. SQLite serializes cancellation writers before their
status/key checks.
