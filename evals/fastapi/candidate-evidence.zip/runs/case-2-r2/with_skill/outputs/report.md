Implemented POST /orders/{order_id}/cancel using the existing order visibility policy.
The required Idempotency-Key accepts 1–64 ASCII letters, digits, hyphens and
underscores. Cancellation restores stock and writes one cancel movement per
product, including orders containing duplicate product lines.

An immediate SQLite transaction covers status, stock, movements and the
user-scoped saved response. Same-key retries replay the saved 200 response;
conflicting keys/orders and new-key cancellation of non-paid orders return 409.
Authorization remains enforced for replay requests.

Validation: python -m unittest discover -s tests -v passed all 13 tests
(3 existing, 10 added), using the supplied Python/dependencies and local file
SQLite databases. Coverage includes header boundaries, access, replay/conflicts,
eight simultaneous retries, competing keys/orders, and injected DB failures at
each write stage with full rollback. The initial run had one test transport error
because HTTPX rejects Unicode string headers; sending raw header bytes fixed the
test, and the full rerun passed.

Limits: concurrency was tested with threads and separate API/DB connections on
SQLite, not multiple OS processes or sustained load. SQLite writers retain the
existing 10-second busy timeout. The dependency stack emits an existing
Starlette/HTTPX deprecation warning.
