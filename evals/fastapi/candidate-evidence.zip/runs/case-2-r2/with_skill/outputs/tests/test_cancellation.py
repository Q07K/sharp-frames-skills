import json
import tempfile
import threading
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from fastapi.testclient import TestClient

from store.api import create_app
from store.db import initialize, session


class CancellationBehavior(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.temp.name) / 'store.sqlite')
        initialize(self.path)
        self.app = create_app(self.path)
        self.client = TestClient(self.app, raise_server_exceptions=False)

    def tearDown(self):
        self.client.close()
        self.temp.cleanup()

    def cancel(self, order_id=10, key='cancel-1', token='alice', client=None):
        return (client or self.client).post(
            f'/orders/{order_id}/cancel',
            headers={'Authorization': f'Bearer {token}', 'Idempotency-Key': key.encode('utf-8')},
        )

    def snapshot(self):
        with session(self.path) as connection:
            return {
                table: [tuple(row) for row in connection.execute(f'SELECT * FROM {table} ORDER BY 1, 2')]
                for table in ('orders', 'products', 'stock_movements', 'cancel_requests')
            }

    def test_cancel_aggregates_products_and_replays_saved_result(self):
        with session(self.path) as connection, connection:
            connection.execute("INSERT INTO order_lines VALUES (10, 'A', 3), (10, 'B', 2)")
        first = self.cancel()
        self.assertEqual(first.status_code, 200)
        self.assertEqual(first.json(), {'id': 10, 'status': 'canceled'})
        state = self.snapshot()
        retry = self.cancel()
        self.assertEqual(retry.status_code, 200)
        self.assertEqual(retry.json(), first.json())
        self.assertEqual(self.snapshot(), state)
        with session(self.path) as connection:
            self.assertEqual(connection.execute('SELECT status FROM orders WHERE id=10').fetchone()[0], 'canceled')
            self.assertEqual([tuple(row) for row in connection.execute('SELECT sku, stock FROM products ORDER BY sku')],
                             [('A', 15), ('B', 10)])
            self.assertEqual([tuple(row) for row in connection.execute(
                'SELECT order_id, sku, quantity, reason FROM stock_movements ORDER BY sku')],
                [(10, 'A', 5, 'cancel'), (10, 'B', 2, 'cancel')])
            saved = connection.execute('SELECT * FROM cancel_requests').fetchone()
            self.assertEqual((saved['user_id'], saved['request_key'], saved['order_id']), (1, 'cancel-1', 10))
            self.assertEqual(json.loads(saved['response_json']), first.json())

    def test_conflicts_do_not_change_state(self):
        self.assertEqual(self.cancel().status_code, 200)
        state = self.snapshot()
        self.assertEqual(self.cancel(order_id=11).status_code, 409)
        self.assertEqual(self.cancel(key='new-key').status_code, 409)
        self.assertEqual(self.snapshot(), state)

    def test_only_paid_orders_can_be_canceled(self):
        with session(self.path) as connection, connection:
            connection.execute("UPDATE orders SET status='pending' WHERE id=10")
        state = self.snapshot()
        self.assertEqual(self.cancel().status_code, 409)
        self.assertEqual(self.snapshot(), state)

    def test_keys_are_scoped_to_user(self):
        self.assertEqual(self.cancel().status_code, 200)
        self.assertEqual(self.cancel(order_id=20, token='bob').status_code, 200)
        self.assertEqual(self.cancel(order_id=12, token='manager').status_code, 200)
        self.assertEqual(self.cancel(token='manager').status_code, 409)
        self.assertEqual(len(self.snapshot()['cancel_requests']), 3)

    def test_access_matches_order_lookup_including_retries(self):
        state = self.snapshot()
        for order_id, token in ((20, 'alice'), (12, 'alice'), (10, 'bob'), (20, 'manager'), (999, 'alice')):
            with self.subTest(order_id=order_id, token=token):
                self.assertEqual(self.cancel(order_id=order_id, token=token).status_code, 404)
        self.assertEqual(self.client.post('/orders/10/cancel', headers={'Idempotency-Key': 'key'}).status_code, 401)
        self.assertEqual(self.cancel(token='invalid').status_code, 401)
        self.assertEqual(self.snapshot(), state)
        self.assertEqual(self.cancel(token='manager', order_id=12).status_code, 200)
        # A previously successful key cannot bypass a later loss of visibility.
        self.assertEqual(self.cancel().status_code, 200)
        with session(self.path) as connection, connection:
            connection.execute('UPDATE orders SET owner_id=4 WHERE id=10')
        self.assertEqual(self.cancel().status_code, 404)

    def test_header_validation_and_boundaries(self):
        state = self.snapshot()
        self.assertEqual(self.client.post('/orders/10/cancel', headers={'Authorization': 'Bearer alice'}).status_code, 422)
        for key in ('', 'a' * 65, 'a b', 'a.b', 'a/b', 'é', 'abc\n', 'abc\r', 'abc\t'):
            with self.subTest(key=repr(key)):
                self.assertEqual(self.cancel(key=key).status_code, 422)
        self.assertEqual(self.snapshot(), state)
        for order_id, key in ((10, 'a'), (11, 'Az09_-' + 'x' * 58)):
            self.assertEqual(self.cancel(order_id=order_id, key=key).status_code, 200)

    def test_database_failures_roll_back_every_write_and_allow_retry(self):
        for table in ('orders', 'products', 'stock_movements', 'cancel_requests'):
            with self.subTest(table=table):
                event = 'UPDATE' if table in ('orders', 'products') else 'INSERT'
                with session(self.path) as connection, connection:
                    connection.execute(
                        f"CREATE TRIGGER fail_cancel BEFORE {event} ON {table} "
                        "BEGIN SELECT RAISE(ABORT, 'injected failure'); END"
                    )
                state = self.snapshot()
                self.assertEqual(self.cancel().status_code, 500)
                self.assertEqual(self.snapshot(), state)
                with session(self.path) as connection, connection:
                    connection.execute('DROP TRIGGER fail_cancel')
        self.assertEqual(self.cancel().status_code, 200)
        self.assertEqual(self.cancel().status_code, 200)
        self.assertEqual(len(self.snapshot()['stock_movements']), 1)

    def concurrent_cancel(self, requests):
        barrier = threading.Barrier(len(requests))

        def call(request):
            with TestClient(self.app) as client:
                barrier.wait(timeout=10)
                response = self.cancel(order_id=request[0], key=request[1], client=client)
                return response.status_code, response.json()

        with ThreadPoolExecutor(max_workers=len(requests)) as executor:
            return list(executor.map(call, requests))

    def test_concurrent_same_key_retries_apply_once(self):
        results = self.concurrent_cancel([(10, 'shared')] * 8)
        self.assertEqual(results, [(200, {'id': 10, 'status': 'canceled'})] * 8)
        state = self.snapshot()
        self.assertEqual(state['products'][0][2], 12)
        self.assertEqual(len(state['stock_movements']), 1)
        self.assertEqual(len(state['cancel_requests']), 1)

    def test_concurrent_different_keys_for_same_order(self):
        results = self.concurrent_cancel([(10, 'first'), (10, 'second')])
        self.assertEqual(sorted(status for status, _ in results), [200, 409])
        state = self.snapshot()
        self.assertEqual(state['products'][0][2], 12)
        self.assertEqual(len(state['stock_movements']), 1)
        self.assertEqual(len(state['cancel_requests']), 1)

    def test_concurrent_same_key_for_different_orders(self):
        results = self.concurrent_cancel([(10, 'shared'), (11, 'shared')])
        self.assertEqual(sorted(status for status, _ in results), [200, 409])
        state = self.snapshot()
        self.assertEqual(len(state['stock_movements']), 1)
        self.assertEqual(len(state['cancel_requests']), 1)
        self.assertEqual(sum(row[3] == 'canceled' for row in state['orders']), 1)


if __name__ == '__main__':
    unittest.main()
