import tempfile
import unittest
from pathlib import Path

from fastapi.testclient import TestClient
from store.api import create_app
from store.db import initialize, session


class OrderListBehavior(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.temp.name) / 'store.sqlite')
        initialize(self.path)
        with session(self.path) as connection, connection:
            connection.executemany(
                'INSERT INTO orders VALUES (?, ?, ?, ?, ?)',
                [(13, 101, 1, 'canceled', 1000), (14, 101, 4, 'canceled', 2000),
                 (21, 202, 2, 'canceled', 3000)],
            )
        self.client = TestClient(create_app(self.path))

    def tearDown(self):
        self.client.close()
        self.temp.cleanup()

    def get(self, token='alice', **params):
        return self.client.get('/orders', headers={'Authorization': f'Bearer {token}'}, params=params)

    def test_default_response_and_access_policy(self):
        response = self.get()
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {
            'items': [{'id': 13, 'status': 'canceled', 'total_won': 1000},
                      {'id': 11, 'status': 'paid', 'total_won': 9000},
                      {'id': 10, 'status': 'paid', 'total_won': 8000}],
            'total': 3, 'limit': 20, 'offset': 0,
        })
        for token, expected in [('alice', [13, 11, 10]), ('bob', [21, 20]),
                                ('manager', [14, 13, 12, 11, 10]), ('charlie', [14, 12])]:
            with self.subTest(token=token):
                body = self.get(token).json()
                self.assertEqual([item['id'] for item in body['items']], expected)
                self.assertEqual(body['total'], len(expected))
                for order_id in (10, 11, 12, 13, 14, 20, 21):
                    visible = self.client.get(f'/orders/{order_id}', headers={
                        'Authorization': f'Bearer {token}'}).status_code == 200
                    self.assertEqual(order_id in expected, visible)

    def test_status_and_pagination(self):
        for token, status, ids in [('alice', 'paid', [11, 10]),
                                   ('alice', 'canceled', [13]),
                                   ('manager', 'canceled', [14, 13]),
                                   ('bob', 'paid', [20])]:
            with self.subTest(token=token, status=status):
                body = self.get(token, status=status, limit=1, offset=1).json()
                self.assertEqual([item['id'] for item in body['items']], ids[1:2])
                self.assertEqual(body['total'], len(ids))
                self.assertEqual((body['limit'], body['offset']), (1, 1))
                empty = self.get(token, status=status, offset=100).json()
                self.assertEqual(empty['items'], [])
                self.assertEqual(empty['total'], len(ids))
        self.assertEqual(self.get(limit=100).status_code, 200)
        self.assertEqual(self.get(offset=100).json()['total'], 3)
        huge_offset = self.get(offset=10**30)
        self.assertEqual(huge_offset.status_code, 200)
        self.assertEqual(huge_offset.json(), {
            'items': [], 'total': 3, 'limit': 20, 'offset': 10**30,
        })
        with session(self.path) as connection, connection:
            connection.execute("DELETE FROM orders WHERE id = 13")
        self.assertEqual(self.get(status='canceled').json()['total'], 0)

    def test_authentication_validation_and_injection(self):
        self.assertEqual(self.client.get('/orders').status_code, 401)
        self.assertEqual(self.get('missing').status_code, 401)
        self.assertEqual(self.get("alice' OR 1=1 --").status_code, 401)
        for params in [{'status': 'pending'}, {'status': ''}, {'status': "paid' OR 1=1 --"},
                       {'limit': 0}, {'limit': 101}, {'limit': -1}, {'limit': '1.5'},
                       {'limit': '1 OR 1=1'}, {'offset': -1}, {'offset': 'x'}, {'offset': '0; --'}]:
            with self.subTest(params=params):
                self.assertEqual(self.get(**params).status_code, 422)
        self.assertEqual(self.get().json()['total'], 3)


if __name__ == '__main__':
    unittest.main()
