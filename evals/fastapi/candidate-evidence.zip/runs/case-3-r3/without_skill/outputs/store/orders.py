from dataclasses import asdict
from fastapi import HTTPException
from .access import visibility_clause
from .settlement import price_basket


def list_orders(connection, actor, status, limit, offset):
    clause, values = visibility_clause(actor)
    if status is not None:
        clause = f'({clause}) AND status = ?'
        values = (*values, status)
    total = connection.execute(f'SELECT count(*) FROM orders WHERE {clause}', values).fetchone()[0]
    if offset >= total:
        return {'items': [], 'total': total, 'limit': limit, 'offset': offset}
    rows = connection.execute(
        f'SELECT id, status, total_won FROM orders WHERE {clause} ORDER BY id DESC LIMIT ? OFFSET ?',
        (*values, limit, offset),
    ).fetchall()
    return {'items': [dict(row) for row in rows], 'total': total, 'limit': limit, 'offset': offset}


def create_order(connection, actor, basket):
    with connection:
        totals = price_basket(connection, actor, basket)
        cursor = connection.execute('INSERT INTO orders(tenant_id, owner_id, status, total_won) VALUES (?, ?, ?, ?)', (actor.tenant_id, actor.id, 'paid', totals.total_won))
        order_id = cursor.lastrowid
        for line in basket.lines:
            changed = connection.execute('UPDATE products SET stock = stock - ? WHERE sku = ? AND stock >= ?', (line.quantity, line.sku, line.quantity)).rowcount
            if changed != 1:
                raise HTTPException(409, 'Insufficient stock')
            connection.execute('INSERT INTO order_lines VALUES (?, ?, ?)', (order_id, line.sku, line.quantity))
        return {'id': order_id, **asdict(totals)}
