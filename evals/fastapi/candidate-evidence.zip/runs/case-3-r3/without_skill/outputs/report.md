Implemented `GET /orders` with optional `paid`/`canceled` status, validated limit (default 20, 1–100), and offset (default 0, nonnegative). The query reuses the individual-order visibility policy, binds SQL values, counts all visible filtered orders, sorts by descending ID, and then paginates. Responses expose only id, status, and total_won per item. Empty pages retain total, including offsets beyond SQLite's integer range.

Validation: `python -m unittest discover -s tests -v` passed all 6 tests after the final change. Checks cover existing creation/read behavior, all fixture roles and tenants, filtered totals, pagination, empty pages, large offsets, 401 authentication, 422 invalid query values, and injection attempts.

Limits: validation used the local SQLite fixture and FastAPI TestClient; no external services were exercised. TestClient emitted an existing httpx deprecation warning.
