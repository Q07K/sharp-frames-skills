# Store API evaluation fixture

Small existing FastAPI application with SQLite. This is synthetic, not production.
Create databases with `store.db.initialize(path)` and apps with `store.api.create_app(path)`.
Bearer alice/bob/manager/charlie are fixture tokens; no external services.
Run `python -m unittest discover -s tests -v` with the supplied dependency path.
Keep existing API contracts and unrelated behavior. Add implementation and useful checks.

`GET /orders` uses the same bearer authentication and visibility rules as the
individual order endpoint. It accepts optional `status=paid|canceled`, `limit`
(default 20, range 1–100), and `offset` (default 0, nonnegative). The response is
`{items: [{id, status, total_won}], total, limit, offset}`. Results are ordered by
descending ID; `total` counts all visible orders matching the status before
pagination, including when the requested page is empty. Invalid query values
return 422; missing or invalid authentication returns 401.
