import tempfile
import unittest
from pathlib import Path

from fastapi.testclient import TestClient

from store.api import create_app
from store.db import initialize, session


class OrderListBehavior(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.temp.name) / 'store.sqlite')
        initialize(self.path)
        with session(self.path) as connection:
            connection.executemany(
                'INSERT INTO orders VALUES (?, ?, ?, ?, ?)',
                [(13, 101, 1, 'canceled', 8100),
                 (14, 101, 4, 'canceled', 7100),
                 (21, 202, 2, 'canceled', 6100),
                 (22, 202, 1, 'paid', 9100)],
            )
            connection.commit()
        self.client = TestClient(create_app(self.path))

    def tearDown(self):
        self.client.close()
        self.temp.cleanup()

    def get_orders(self, token='alice', **params):
        return self.client.get('/orders', params=params,
                               headers={'Authorization': f'Bearer {token}'})

    def test_default_contract_and_sort(self):
        response = self.get_orders()
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {
            'items': [
                {'id': 13, 'status': 'canceled', 'total_won': 8100},
                {'id': 11, 'status': 'paid', 'total_won': 9000},
                {'id': 10, 'status': 'paid', 'total_won': 8000},
            ],
            'total': 3, 'limit': 20, 'offset': 0,
        })

    def test_visibility_matches_individual_lookup(self):
        expected = {'alice': [13, 11, 10], 'charlie': [14, 12],
                    'manager': [14, 13, 12, 11, 10], 'bob': [21, 20]}
        for token, ids in expected.items():
            with self.subTest(token=token):
                response = self.get_orders(token)
                self.assertEqual(response.status_code, 200)
                self.assertEqual([row['id'] for row in response.json()['items']], ids)
                self.assertEqual(response.json()['total'], len(ids))
                for order_id in [10, 11, 12, 13, 14, 20, 21, 22]:
                    detail = self.client.get(f'/orders/{order_id}', headers={
                        'Authorization': f'Bearer {token}'})
                    self.assertEqual(detail.status_code, 200 if order_id in ids else 404)

    def test_filter_before_pagination_and_total(self):
        cases = [
            ('alice', 'paid', 1, 1, [10], 2),
            ('manager', 'canceled', 1, 1, [13], 2),
            ('bob', 'canceled', 100, 0, [21], 1),
            ('alice', 'paid', 1, 100, [], 2),
            ('charlie', 'canceled', 20, 1, [], 1),
            ('alice', 'paid', 20, 10**30, [], 2),
        ]
        for token, status, limit, offset, ids, total in cases:
            with self.subTest(token=token, status=status, offset=offset):
                response = self.get_orders(token, status=status, limit=limit, offset=offset)
                self.assertEqual(response.status_code, 200)
                body = response.json()
                self.assertEqual([row['id'] for row in body['items']], ids)
                self.assertEqual(body['total'], total)
                self.assertEqual(body['limit'], limit)
                self.assertEqual(body['offset'], offset)

    def test_default_limit_slices_large_result(self):
        with session(self.path) as connection:
            connection.executemany(
                'INSERT INTO orders VALUES (?, 101, 1, ?, 1000)',
                [(order_id, 'paid') for order_id in range(30, 55)],
            )
            connection.commit()
        response = self.get_orders()
        self.assertEqual(response.status_code, 200)
        body = response.json()
        self.assertEqual([row['id'] for row in body['items']], list(range(54, 34, -1)))
        self.assertEqual(body['total'], 28)
        self.assertEqual(body['limit'], 20)
        self.assertEqual(body['offset'], 0)

    def test_empty_result(self):
        with session(self.path) as connection:
            connection.execute('DELETE FROM orders WHERE id = 13')
            connection.commit()
        self.assertEqual(self.get_orders(status='canceled').json(), {
            'items': [], 'total': 0, 'limit': 20, 'offset': 0,
        })

    def test_invalid_filters_and_ranges(self):
        invalid = [
            {'status': ''}, {'status': 'pending'}, {'status': 'PAID'},
            {'status': "paid' OR 1=1 --"},
            {'limit': 0}, {'limit': -1}, {'limit': 101},
            {'limit': '1.5'}, {'limit': 'abc'}, {'limit': '1 OR 1=1'},
            {'offset': -1}, {'offset': '0.5'}, {'offset': 'abc'},
            {'offset': '0 UNION SELECT 1'},
        ]
        for params in invalid:
            with self.subTest(params=params):
                self.assertEqual(self.get_orders(**params).status_code, 422)
        self.assertEqual(self.get_orders().json()['total'], 3)

    def test_authentication(self):
        self.assertEqual(self.client.get('/orders').status_code, 401)
        for token in ['unknown', "alice' OR 1=1 --"]:
            self.assertEqual(self.get_orders(token).status_code, 401)


if __name__ == '__main__':
    unittest.main()
