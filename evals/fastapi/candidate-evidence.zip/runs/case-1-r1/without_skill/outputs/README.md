# Store API evaluation fixture

Small existing FastAPI application with SQLite. This is synthetic, not production.
Create databases with `store.db.initialize(path)` and apps with `store.api.create_app(path)`.
Bearer alice/bob/manager/charlie are fixture tokens; no external services.
Run `python -m unittest discover -s tests -v` with the supplied dependency path.
Keep existing API contracts and unrelated behavior. Add implementation and useful checks.

`POST /quotes` accepts the same authenticated basket as `POST /orders` and returns
`subtotal_won`, `discount_won`, `shipping_won`, and `total_won` with status 200.
It uses current database prices and the authenticated user's tier without writing
to the database. Quotes do not reserve stock; order placement still checks stock.
