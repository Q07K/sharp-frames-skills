# Changes

- Added authenticated `POST /quotes` with the existing `BasketInput`, authentication dependency, and shared `price_basket` calculation. Returns the four monetary fields with HTTP 200.
- Existing order routes and pricing rules remain unchanged. Client-supplied prices and tiers cannot override database values.
- Documented the endpoint and added six quote tests.

# Checks

Ran the supplied Python runtime with `PYTHONPATH` set to the supplied dependencies and `TMP`/`TEMP` set to `outputs/tmp`:

```text
python -m unittest discover -s tests -v
```

First run: 8 tests passed. Final run: **9 tests passed**, including all 3 existing tests. Coverage includes quote/order total parity, VIP rounding, coupon discount floor, shipping thresholds, duplicate lines, spoofed prices/tiers, changed database values, input/product/coupon errors, authentication, and full database snapshots before/after repeated quotes and errors.

# Limitations

Quotes reflect current prices and user tier and do not reserve or check stock. Existing order stock validation still runs when placing an order. No external services were accessed. The supplied Starlette TestClient emits an httpx deprecation warning; both test runs completed successfully.
