import tempfile
import unittest
from pathlib import Path

from fastapi.testclient import TestClient

from store.api import create_app
from store.db import initialize, session


class QuoteBehavior(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.temp.name) / 'store.sqlite')
        initialize(self.path)
        self.client = TestClient(create_app(self.path))
        self.headers = {'Authorization': 'Bearer alice'}

    def tearDown(self):
        self.client.close()
        self.temp.cleanup()

    def snapshot(self):
        with session(self.path) as connection:
            return list(connection.iterdump())

    def test_totals_match_real_orders(self):
        cases = [
            ('alice', [{'sku': 'A', 'quantity': 2}], 'SAVE500', (2002, 701, 700, 2001)),
            ('alice', [{'sku': 'A', 'quantity': 1}], None, (1001, 101, 700, 1600)),
            ('bob', [{'sku': 'A', 'quantity': 1}], 'SAVE500', (1001, 500, 700, 1201)),
            ('bob', [{'sku': 'B', 'quantity': 4}], None, (10012, 0, 0, 10012)),
            ('bob', [{'sku': 'B', 'quantity': 4}], 'SAVE500', (10012, 500, 700, 10212)),
            ('alice', [{'sku': 'A', 'quantity': 2}, {'sku': 'B', 'quantity': 4}], None, (12014, 1202, 0, 10812)),
            ('alice', [{'sku': 'A', 'quantity': 1}, {'sku': 'A', 'quantity': 1}], None, (2002, 201, 700, 2501)),
        ]
        fields = ('subtotal_won', 'discount_won', 'shipping_won', 'total_won')
        for index, (token, lines, coupon, expected) in enumerate(cases):
            with self.subTest(token=token, lines=lines, coupon=coupon):
                path = str(Path(self.temp.name) / f'case-{index}.sqlite')
                initialize(path)
                with TestClient(create_app(path)) as client:
                    headers = {'Authorization': f'Bearer {token}'}
                    basket = {'lines': lines, 'coupon_code': coupon}
                    quote = client.post('/quotes', headers=headers, json=basket)
                    order = client.post('/orders', headers=headers, json=basket)
                    self.assertEqual(quote.status_code, 200)
                    self.assertEqual(order.status_code, 201)
                    self.assertEqual(quote.json(), dict(zip(fields, expected)))
                    self.assertEqual(quote.json(), {key: order.json()[key] for key in fields})

    def test_untrusted_prices_and_tiers_have_no_effect(self):
        basket = {
            'lines': [{'sku': 'A', 'quantity': 2, 'price_won': 1, 'unit_price': 1}],
            'tier': 'vip', 'price_won': 1, 'total_won': 1,
            'actor': {'id': 1, 'tier': 'vip'}, 'user_id': 1,
        }
        headers = {'Authorization': 'Bearer bob'}
        quote = self.client.post('/quotes', headers=headers, json=basket)
        order = self.client.post('/orders', headers=headers, json=basket)
        expected = {'subtotal_won': 2002, 'discount_won': 0, 'shipping_won': 700, 'total_won': 2702}
        self.assertEqual(quote.status_code, 200)
        self.assertEqual(order.status_code, 201)
        self.assertEqual(quote.json(), expected)
        self.assertEqual({key: order.json()[key] for key in expected}, expected)

    def test_repeated_quotes_preserve_entire_database(self):
        before = self.snapshot()
        basket = {'lines': [{'sku': 'A', 'quantity': 2}], 'coupon_code': 'SAVE500'}
        for _ in range(3):
            response = self.client.post('/quotes', headers=self.headers, json=basket)
            self.assertEqual(response.status_code, 200)
            self.assertEqual(self.snapshot(), before)

    def test_current_database_prices_tier_and_coupon_floor(self):
        with session(self.path) as connection, connection:
            connection.execute("UPDATE products SET price_won = 101 WHERE sku = 'A'")
            connection.execute("UPDATE users SET tier = 'vip' WHERE token = 'bob'")
        before = self.snapshot()
        basket = {'lines': [{'sku': 'A', 'quantity': 2}], 'coupon_code': 'SAVE500', 'tier': 'regular'}
        headers = {'Authorization': 'Bearer bob'}
        quote = self.client.post('/quotes', headers=headers, json=basket)
        self.assertEqual(quote.status_code, 200)
        self.assertEqual(quote.json(), {'subtotal_won': 202, 'discount_won': 202, 'shipping_won': 700, 'total_won': 700})
        self.assertEqual(self.snapshot(), before)
        order = self.client.post('/orders', headers=headers, json=basket)
        self.assertEqual(order.status_code, 201)
        self.assertEqual(quote.json(), {key: order.json()[key] for key in quote.json()})

    def test_validation_and_business_errors_match_orders_without_mutation(self):
        invalid = [
            {}, {'lines': []}, {'lines': [{'sku': 'A', 'quantity': True}]},
            {'lines': [{'sku': 'A', 'quantity': '1'}]},
            {'lines': [{'sku': 'A', 'quantity': 1.0}]},
            {'lines': [{'sku': 'A', 'quantity': 0}]},
            {'lines': [{'sku': 'A', 'quantity': 101}]},
            {'lines': [{'sku': '', 'quantity': 1}]},
            {'lines': [{'sku': 'A', 'quantity': 1}] * 51},
            {'lines': [{'sku': 'missing', 'quantity': 1}]},
            {'lines': [{'sku': 'A', 'quantity': 1}], 'coupon_code': 'INVALID'},
            {'lines': [{'sku': 'missing', 'quantity': 1}], 'coupon_code': 'INVALID'},
        ]
        before = self.snapshot()
        for basket in invalid:
            with self.subTest(basket=basket):
                quote = self.client.post('/quotes', headers=self.headers, json=basket)
                order = self.client.post('/orders', headers=self.headers, json=basket)
                self.assertIn(quote.status_code, (404, 422))
                self.assertEqual(quote.status_code, order.status_code)
                self.assertEqual(quote.json(), order.json())
                self.assertEqual(self.snapshot(), before)

    def test_authentication_matches_orders(self):
        basket = {'lines': [{'sku': 'A', 'quantity': 1}]}
        before = self.snapshot()
        for authorization in (None, 'Basic alice', 'Bearer unknown', 'Bearer '):
            with self.subTest(authorization=authorization):
                headers = {} if authorization is None else {'Authorization': authorization}
                quote = self.client.post('/quotes', headers=headers, json=basket)
                order = self.client.post('/orders', headers=headers, json=basket)
                self.assertEqual(quote.status_code, 401)
                self.assertEqual(quote.status_code, order.status_code)
                self.assertEqual(quote.json(), order.json())
                self.assertEqual(self.snapshot(), before)


if __name__ == '__main__':
    unittest.main()
