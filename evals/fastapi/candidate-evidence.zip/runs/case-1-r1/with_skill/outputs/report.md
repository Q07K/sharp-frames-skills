# Quote API

- Added `POST /quotes`, returning HTTP 200 and exactly `subtotal_won`, `discount_won`, `shipping_won`, and `total_won`.
- Reused the order endpoint's `BasketInput`, authenticated actor dependency, database session dependency, and authoritative `settlement.price_basket` calculation. Prices come from products and membership tier comes from authenticated user data. No order creation or stock update is invoked.
- Preserved existing order and access endpoints. Added integration coverage for quote/order parity, VIP integer rounding, coupon floor, shipping thresholds, untrusted price/tier fields, matching validation/product/coupon/authentication failures, repeated quotes, and unchanged database contents.

Validation: ran the supplied Python runtime with the supplied dependency path, local `TMP`/`TEMP`, and `python -m unittest discover -s tests -v` outside the Windows sandbox as requested. All 10 tests passed (3 existing, 7 new). Reviewed final API and test source.

Limitations: validation uses the fixture's local SQLite database and FastAPI TestClient; no network or external deployment checks were performed. The existing TestClient stack emitted a Starlette deprecation warning about httpx; it did not affect results. Quotes calculate current prices without reserving stock; later product or user changes can affect a subsequent order.
