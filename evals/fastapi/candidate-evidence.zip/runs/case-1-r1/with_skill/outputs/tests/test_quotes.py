import tempfile
import unittest
from pathlib import Path

from fastapi.testclient import TestClient

from store.api import create_app
from store.db import initialize, session


class QuoteBehavior(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.temp.name) / 'store.sqlite')
        initialize(self.path)
        self.client = TestClient(create_app(self.path))
        self.headers = {'Authorization': 'Bearer alice'}

    def tearDown(self):
        self.client.close()
        self.temp.cleanup()

    def snapshot(self):
        with session(self.path) as connection:
            return '\n'.join(connection.iterdump())

    def test_quote_policy_and_order_parity(self):
        cases = [
            ('alice', [{'sku': 'A', 'quantity': 2}], 'SAVE500',
             {'subtotal_won': 2002, 'discount_won': 701,
              'shipping_won': 700, 'total_won': 2001}),
            ('bob', [{'sku': 'A', 'quantity': 1}], None,
             {'subtotal_won': 1001, 'discount_won': 0,
              'shipping_won': 700, 'total_won': 1701}),
            ('alice', [{'sku': 'B', 'quantity': 1}], None,
             {'subtotal_won': 2503, 'discount_won': 251,
              'shipping_won': 700, 'total_won': 2952}),
            ('bob', [{'sku': 'A', 'quantity': 2}, {'sku': 'B', 'quantity': 4}], None,
             {'subtotal_won': 12014, 'discount_won': 0,
              'shipping_won': 0, 'total_won': 12014}),
        ]
        for token, lines, coupon, expected in cases:
            with self.subTest(token=token, lines=lines, coupon=coupon):
                headers = {'Authorization': f'Bearer {token}'}
                basket = {'lines': lines, 'coupon_code': coupon}
                before = self.snapshot()
                quote = self.client.post('/quotes', headers=headers, json=basket)
                self.assertEqual(quote.status_code, 200, quote.text)
                self.assertEqual(quote.json(), expected)
                self.assertEqual(self.snapshot(), before)
                order = self.client.post('/orders', headers=headers, json=basket)
                self.assertEqual(order.status_code, 201, order.text)
                self.assertEqual({k: v for k, v in order.json().items() if k != 'id'}, expected)

    def test_shipping_threshold_uses_discounted_amount(self):
        with session(self.path) as connection:
            connection.execute("UPDATE products SET price_won = 10000 WHERE sku = 'A'")
            connection.commit()
        for token, coupon, expected in [
            ('bob', None, (0, 0, 10000)),
            ('bob', 'SAVE500', (500, 700, 10200)),
            ('alice', None, (1000, 700, 9700)),
        ]:
            with self.subTest(token=token, coupon=coupon):
                basket = {'lines': [{'sku': 'A', 'quantity': 1}], 'coupon_code': coupon}
                response = self.client.post('/quotes', headers={'Authorization': f'Bearer {token}'}, json=basket)
                self.assertEqual(response.status_code, 200)
                discount, shipping, total = expected
                self.assertEqual(response.json(), {
                    'subtotal_won': 10000, 'discount_won': discount,
                    'shipping_won': shipping, 'total_won': total,
                })

    def test_coupon_cannot_make_discounted_amount_negative(self):
        with session(self.path) as connection:
            connection.execute("UPDATE products SET price_won = 100 WHERE sku = 'A'")
            connection.commit()
        basket = {'lines': [{'sku': 'A', 'quantity': 1}], 'coupon_code': 'SAVE500'}
        response = self.client.post('/quotes', headers=self.headers, json=basket)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {
            'subtotal_won': 100, 'discount_won': 100,
            'shipping_won': 700, 'total_won': 700,
        })

    def test_client_prices_and_tier_are_ignored(self):
        basket = {
            'lines': [{'sku': 'B', 'quantity': 1, 'price_won': 1, 'unit_price': 1}],
            'tier': 'vip', 'price_won': 1, 'subtotal_won': 1, 'total_won': 1,
        }
        headers = {'Authorization': 'Bearer bob'}
        response = self.client.post('/quotes', headers=headers, json=basket)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {
            'subtotal_won': 2503, 'discount_won': 0,
            'shipping_won': 700, 'total_won': 3203,
        })
        order = self.client.post('/orders', headers=headers, json=basket)
        self.assertEqual(order.status_code, 201)
        self.assertEqual(order.json()['total_won'], response.json()['total_won'])

    def test_validation_and_domain_errors_match_orders_without_writes(self):
        cases = [
            ({}, 422),
            ({'lines': []}, 422),
            ({'lines': [{'sku': 'A', 'quantity': 1}] * 51}, 422),
            ({'lines': [{'sku': '', 'quantity': 1}]}, 422),
            ({'lines': [{'sku': 'missing', 'quantity': 1}]}, 404),
            ({'lines': [{'sku': 'A', 'quantity': 1}], 'coupon_code': 'INVALID'}, 422),
            ({'lines': [{'sku': 'missing', 'quantity': 1}], 'coupon_code': 'INVALID'}, 404),
        ]
        cases.extend(({'lines': [{'sku': 'A', 'quantity': quantity}]}, 422)
                     for quantity in [0, -1, 101, True, '2', 1.5])
        for basket, status in cases:
            with self.subTest(basket=basket):
                before = self.snapshot()
                quote = self.client.post('/quotes', headers=self.headers, json=basket)
                order = self.client.post('/orders', headers=self.headers, json=basket)
                self.assertEqual(quote.status_code, status)
                self.assertEqual(quote.status_code, order.status_code)
                self.assertEqual(quote.json(), order.json())
                self.assertEqual(self.snapshot(), before)

    def test_authentication_matches_orders_without_writes(self):
        basket = {'lines': [{'sku': 'A', 'quantity': 1}]}
        for headers in [{}, {'Authorization': 'Basic alice'}, {'Authorization': 'Bearer unknown'}]:
            with self.subTest(headers=headers):
                before = self.snapshot()
                quote = self.client.post('/quotes', headers=headers, json=basket)
                order = self.client.post('/orders', headers=headers, json=basket)
                self.assertEqual(quote.status_code, 401)
                self.assertEqual(quote.status_code, order.status_code)
                self.assertEqual(quote.json(), order.json())
                self.assertEqual(self.snapshot(), before)

    def test_repeated_quotes_do_not_change_any_database_state(self):
        basket = {'lines': [{'sku': 'A', 'quantity': 2}, {'sku': 'A', 'quantity': 1}]}
        before = self.snapshot()
        first = self.client.post('/quotes', headers=self.headers, json=basket)
        second = self.client.post('/quotes', headers=self.headers, json=basket)
        self.assertEqual(first.status_code, 200)
        self.assertEqual(second.status_code, 200)
        self.assertEqual(first.json(), second.json())
        self.assertEqual(self.snapshot(), before)


if __name__ == '__main__':
    unittest.main()
