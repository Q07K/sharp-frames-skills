from pydantic import BaseModel, Field
from typing import Literal


OrderStatus = Literal['paid', 'canceled']


class OrderSummary(BaseModel):
    id: int
    status: str
    total_won: int


class OrderPage(BaseModel):
    items: list[OrderSummary]
    total: int
    limit: int
    offset: int


class LineInput(BaseModel):
    sku: str = Field(min_length=1)
    quantity: int = Field(strict=True, gt=0, le=100)


class BasketInput(BaseModel):
    lines: list[LineInput] = Field(min_length=1, max_length=50)
    coupon_code: str | None = None
