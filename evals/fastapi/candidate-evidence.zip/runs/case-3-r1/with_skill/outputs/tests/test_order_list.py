import tempfile
import unittest
from pathlib import Path

from fastapi.testclient import TestClient

from store.api import create_app
from store.db import initialize, session


class OrderListBehavior(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.temp.name) / 'store.sqlite')
        initialize(self.path)
        with session(self.path) as connection, connection:
            connection.execute("INSERT INTO users VALUES (5, 101, 'member', 'regular', 'empty')")
            connection.executemany('INSERT INTO orders VALUES (?, ?, ?, ?, ?)', [
                (21, 101, 1, 'canceled', 4000),
                (22, 101, 4, 'canceled', 5000),
                (23, 202, 2, 'canceled', 6000),
                (24, 202, 1, 'paid', 7000),
            ])
        self.client = TestClient(create_app(self.path))

    def tearDown(self):
        self.client.close()
        self.temp.cleanup()

    def get_page(self, actor='alice', **params):
        return self.client.get('/orders', headers={'Authorization': f'Bearer {actor}'}, params=params)

    def test_default_contract_and_visibility(self):
        expected = {
            'alice': [21, 11, 10],
            'charlie': [22, 12],
            'bob': [23, 20],
            'manager': [22, 21, 12, 11, 10],
        }
        for actor, ids in expected.items():
            with self.subTest(actor=actor):
                response = self.get_page(actor)
                self.assertEqual(response.status_code, 200)
                page = response.json()
                self.assertEqual(set(page), {'items', 'total', 'limit', 'offset'})
                self.assertEqual([item['id'] for item in page['items']], ids)
                self.assertEqual(page['total'], len(ids))
                self.assertEqual((page['limit'], page['offset']), (20, 0))
                for item in page['items']:
                    self.assertEqual(set(item), {'id', 'status', 'total_won'})
        self.assertEqual(self.get_page().json()['items'][0], {
            'id': 21, 'status': 'canceled', 'total_won': 4000,
        })

    def test_filters_and_pagination_keep_filtered_total(self):
        for actor, status, ids in [
            ('alice', 'paid', [11, 10]),
            ('alice', 'canceled', [21]),
            ('manager', 'paid', [12, 11, 10]),
            ('manager', 'canceled', [22, 21]),
        ]:
            with self.subTest(actor=actor, status=status):
                page = self.get_page(actor, status=status, limit=1, offset=1).json()
                self.assertEqual([item['id'] for item in page['items']], ids[1:2])
                self.assertEqual(page['total'], len(ids))
                self.assertEqual((page['limit'], page['offset']), (1, 1))
        self.assertEqual(self.get_page(limit=1, offset=1).json(), {
            'items': [{'id': 11, 'status': 'paid', 'total_won': 9000}],
            'total': 3, 'limit': 1, 'offset': 1,
        })
        for offset in (3, 100, 10**30):
            self.assertEqual(self.get_page(offset=offset).json(), {
                'items': [], 'total': 3, 'limit': 20, 'offset': offset,
            })
        self.assertEqual(self.get_page('empty', status='paid').json(), {
            'items': [], 'total': 0, 'limit': 20, 'offset': 0,
        })

    def test_authentication_and_untrusted_inputs(self):
        self.assertEqual(self.client.get('/orders').status_code, 401)
        for token in ('unknown', "alice' OR 1=1 --"):
            self.assertEqual(self.get_page(token).status_code, 401)
        invalid_params = [
            {'status': ''}, {'status': 'pending'}, {'status': 'PAID'},
            {'status': "paid' OR 1=1 --"},
            {'limit': 0}, {'limit': -1}, {'limit': 101},
            {'limit': '1.5'}, {'limit': 'abc'}, {'limit': '1 OR 1=1'},
            {'offset': -1}, {'offset': '1.5'}, {'offset': 'abc'},
            {'offset': '0 OR 1=1'},
        ]
        for params in invalid_params:
            with self.subTest(params=params):
                self.assertEqual(self.get_page(**params).status_code, 422)
        self.assertEqual(self.get_page(limit=100, offset=0).status_code, 200)


if __name__ == '__main__':
    unittest.main()
