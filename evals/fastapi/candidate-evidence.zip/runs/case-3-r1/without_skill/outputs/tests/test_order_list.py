import tempfile
import unittest
from pathlib import Path

from fastapi.testclient import TestClient
from store.api import create_app
from store.db import initialize, session


class OrderList(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.temp.name) / 'store.sqlite')
        initialize(self.path)
        with session(self.path) as connection, connection:
            connection.executemany(
                'INSERT INTO orders VALUES (?, ?, ?, ?, ?)',
                [(13, 101, 1, 'canceled', 1000),
                 (14, 101, 4, 'canceled', 2000),
                 (21, 202, 2, 'canceled', 3000)],
            )
        self.client = TestClient(create_app(self.path))

    def tearDown(self):
        self.client.close()
        self.temp.cleanup()

    def get_orders(self, token='alice', **params):
        return self.client.get('/orders', headers={'Authorization': f'Bearer {token}'}, params=params)

    def test_defaults_and_exact_shape(self):
        response = self.get_orders()
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {
            'items': [{'id': 13, 'status': 'canceled', 'total_won': 1000},
                      {'id': 11, 'status': 'paid', 'total_won': 9000},
                      {'id': 10, 'status': 'paid', 'total_won': 8000}],
            'total': 3, 'limit': 20, 'offset': 0,
        })

    def test_visibility_matches_individual_order_policy(self):
        for token in ('alice', 'bob', 'manager', 'charlie'):
            with self.subTest(token=token):
                result = self.get_orders(token).json()
                visible = []
                for order_id in (10, 11, 12, 13, 14, 20, 21):
                    response = self.client.get(
                        f'/orders/{order_id}', headers={'Authorization': f'Bearer {token}'})
                    if response.status_code == 200:
                        visible.append(order_id)
                self.assertEqual([item['id'] for item in result['items']], sorted(visible, reverse=True))
                self.assertEqual(result['total'], len(visible))

    def test_filter_before_count_and_pagination(self):
        result = self.get_orders('manager', status='paid', limit=1, offset=1).json()
        self.assertEqual(result, {
            'items': [{'id': 11, 'status': 'paid', 'total_won': 9000}],
            'total': 3, 'limit': 1, 'offset': 1,
        })
        canceled = self.get_orders('manager', status='canceled', limit=100).json()
        self.assertEqual([item['id'] for item in canceled['items']], [14, 13])
        self.assertEqual(canceled['total'], 2)

    def test_empty_page_keeps_filtered_total(self):
        result = self.get_orders(status='paid', offset=100).json()
        self.assertEqual(result, {'items': [], 'total': 2, 'limit': 20, 'offset': 100})
        with session(self.path) as connection, connection:
            connection.execute("UPDATE orders SET status = 'paid' WHERE id = 13")
        result = self.get_orders(status='canceled').json()
        self.assertEqual(result['items'], [])
        self.assertEqual(result['total'], 0)

    def test_large_offset_is_an_empty_page(self):
        offset = 10 ** 100
        response = self.get_orders(offset=offset)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {'items': [], 'total': 3, 'limit': 20, 'offset': offset})

    def test_authentication_required(self):
        for headers in ({}, {'Authorization': 'Basic alice'}, {'Authorization': 'Bearer unknown'}):
            with self.subTest(headers=headers):
                self.assertEqual(self.client.get('/orders', headers=headers).status_code, 401)
        self.assertEqual(self.client.get('/orders?limit=0').status_code, 401)

    def test_invalid_filters_and_ranges(self):
        cases = [
            {'status': ''}, {'status': 'pending'}, {'status': 'PAID'},
            {'limit': 0}, {'limit': -1}, {'limit': 101}, {'limit': 'abc'},
            {'limit': '1.5'}, {'offset': -1}, {'offset': 'abc'}, {'offset': '1.5'},
            {'status': "paid' OR 1=1 --"},
            {'limit': '1 OR 1=1'}, {'offset': '0 UNION SELECT 1'},
        ]
        for params in cases:
            with self.subTest(params=params):
                self.assertEqual(self.get_orders(**params).status_code, 422)
        self.assertEqual(self.get_orders('manager').json()['total'], 5)


if __name__ == '__main__':
    unittest.main()
