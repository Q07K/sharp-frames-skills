# Changes and validation

Added `GET /orders` with optional `paid`/`canceled` status filtering, bounded limit (default 20), and nonnegative offset (default 0). The list and count share the existing visibility policy. Queries bind all user values, order by descending ID, and return only `id`, `status`, and `total_won` in items. Empty pages preserve the filtered total, including offsets beyond SQLite integer capacity.

Validation: `python -m unittest discover -s tests -v` passed all 10 tests (3 existing, 7 new). Checks cover member/manager visibility against individual order access, tenant boundaries, response shape, filtering before pagination, retained totals, authentication, invalid inputs, and SQL injection attempts.

Limit: the supplied Starlette TestClient emits an httpx deprecation warning. No external services or deployment were involved.
