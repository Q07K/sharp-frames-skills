import json
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from threading import Barrier

from fastapi.testclient import TestClient

from store.api import create_app
from store.db import initialize, session


class CancellationBehavior(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.temp.name) / 'store.sqlite')
        initialize(self.path)
        self.app = create_app(self.path)
        self.client = TestClient(self.app)

    def tearDown(self):
        self.client.close()
        self.temp.cleanup()

    def cancel(self, order_id=10, key='request-1', token='alice'):
        return self.client.post(
            f'/orders/{order_id}/cancel',
            headers={'Authorization': f'Bearer {token}', 'Idempotency-Key': key},
        )

    def snapshot(self):
        with session(self.path) as connection:
            return {
                table: [tuple(row) for row in connection.execute(f'SELECT * FROM {table} ORDER BY rowid')]
                for table in ('orders', 'products', 'order_lines', 'stock_movements', 'cancel_requests')
            }

    def test_cancellation_restores_each_product_and_stores_result(self):
        with session(self.path) as connection, connection:
            # Duplicate product lines still produce one movement per product.
            connection.execute("INSERT INTO order_lines VALUES (10, 'A', 3)")
            connection.execute("INSERT INTO order_lines VALUES (10, 'B', 4)")
        response = self.cancel()
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {'id': 10, 'status': 'canceled'})
        self.assertEqual(self.client.get('/orders/10', headers={'Authorization': 'Bearer alice'}).json()['status'], 'canceled')
        with session(self.path) as connection:
            self.assertEqual([tuple(row) for row in connection.execute('SELECT sku, stock FROM products ORDER BY sku')], [('A', 15), ('B', 12)])
            self.assertEqual([tuple(row) for row in connection.execute('SELECT order_id, sku, quantity, reason FROM stock_movements ORDER BY sku')], [(10, 'A', 5, 'cancel'), (10, 'B', 4, 'cancel')])
            saved = connection.execute('SELECT * FROM cancel_requests').fetchone()
            self.assertEqual((saved['user_id'], saved['request_key'], saved['order_id']), (1, 'request-1', 10))
            self.assertEqual(json.loads(saved['response_json']), response.json())

    def test_replay_and_conflicts_leave_state_unchanged(self):
        first = self.cancel()
        state = self.snapshot()
        repeated = self.cancel()
        self.assertEqual(repeated.status_code, 200)
        self.assertEqual(repeated.json(), first.json())
        self.assertEqual(self.cancel(11).status_code, 409)
        self.assertEqual(self.cancel(key='new-key').status_code, 409)
        self.assertEqual(self.snapshot(), state)

    def test_key_is_scoped_to_user(self):
        self.assertEqual(self.cancel().status_code, 200)
        self.assertEqual(self.cancel(20, token='bob').status_code, 200)
        self.assertEqual(self.cancel(12, token='manager').status_code, 200)
        with session(self.path) as connection:
            self.assertEqual(connection.execute('SELECT count(*) FROM cancel_requests').fetchone()[0], 3)

    def test_access_matches_order_lookup_and_precedes_replay(self):
        original = self.snapshot()
        for token, order_id in [('alice', 12), ('alice', 20), ('bob', 10), ('manager', 20), ('alice', 999)]:
            with self.subTest(token=token, order_id=order_id):
                self.assertEqual(self.cancel(order_id, token=token).status_code, 404)
        self.assertEqual(self.client.post('/orders/10/cancel', headers={'Idempotency-Key': 'key'}).status_code, 401)
        self.assertEqual(self.cancel(token='invalid').status_code, 401)
        self.assertEqual(self.snapshot(), original)
        self.assertEqual(self.cancel(12, token='manager').status_code, 200)
        self.assertEqual(self.cancel(12, key='other', token='charlie').status_code, 409)
        self.assertEqual(self.cancel().status_code, 200)
        with session(self.path) as connection, connection:
            connection.execute('UPDATE orders SET owner_id = 4 WHERE id = 10')
        self.assertEqual(self.cancel().status_code, 404)

    def test_required_and_strict_header_validation(self):
        original = self.snapshot()
        self.assertEqual(self.client.post('/orders/10/cancel', headers={'Authorization': 'Bearer alice'}).status_code, 422)
        for key in ('', 'a' * 65, 'with space', 'a.b', 'a/b', 'a\tb', 'a\n', '한글'):
            with self.subTest(key=key):
                # Use bytes for non-ASCII to reach request validation through httpx.
                headers = [(b'Authorization', b'Bearer alice'), (b'Idempotency-Key', key.encode('utf-8'))]
                self.assertEqual(self.client.post('/orders/10/cancel', headers=headers).status_code, 422)
        self.assertEqual(self.snapshot(), original)
        self.assertEqual(self.cancel(key='a').status_code, 200)
        self.assertEqual(self.cancel(11, key='A0_-' * 16).status_code, 200)

    def test_non_paid_status_is_conflict(self):
        with session(self.path) as connection, connection:
            connection.execute("UPDATE orders SET status = 'pending' WHERE id = 10")
        original = self.snapshot()
        self.assertEqual(self.cancel().status_code, 409)
        self.assertEqual(self.snapshot(), original)

    def test_database_failures_roll_back_every_write_and_allow_retry(self):
        triggers = (
            "BEFORE UPDATE ON orders BEGIN SELECT RAISE(ABORT, 'failure'); END",
            "BEFORE UPDATE ON products WHEN OLD.sku = 'B' BEGIN SELECT RAISE(ABORT, 'failure'); END",
            "BEFORE INSERT ON stock_movements WHEN NEW.sku = 'B' BEGIN SELECT RAISE(ABORT, 'failure'); END",
            "BEFORE INSERT ON cancel_requests BEGIN SELECT RAISE(ABORT, 'failure'); END",
        )
        with session(self.path) as connection, connection:
            connection.execute("INSERT INTO order_lines VALUES (10, 'B', 1)")
        for trigger in triggers:
            with self.subTest(trigger=trigger):
                original = self.snapshot()
                with session(self.path) as connection, connection:
                    connection.execute(f'CREATE TRIGGER fail_cancel {trigger}')
                with TestClient(self.app, raise_server_exceptions=False) as client:
                    response = client.post('/orders/10/cancel', headers={'Authorization': 'Bearer alice', 'Idempotency-Key': 'retry'})
                self.assertEqual(response.status_code, 500)
                self.assertEqual(self.snapshot(), original)
                with session(self.path) as connection, connection:
                    connection.execute('DROP TRIGGER fail_cancel')
        self.assertEqual(self.cancel(key='retry').status_code, 200)

    def concurrent_cancellations(self, requests):
        barrier = Barrier(len(requests))

        def send(request):
            order_id, key = request
            with TestClient(self.app) as client:
                barrier.wait(timeout=10)
                response = client.post(f'/orders/{order_id}/cancel', headers={'Authorization': 'Bearer alice', 'Idempotency-Key': key})
                return response.status_code, response.json()

        with ThreadPoolExecutor(max_workers=len(requests)) as executor:
            return list(executor.map(send, requests))

    def test_concurrent_same_key_retries_apply_once(self):
        responses = self.concurrent_cancellations([(10, 'same-key')] * 8)
        self.assertEqual(responses, [(200, {'id': 10, 'status': 'canceled'})] * 8)
        with session(self.path) as connection:
            self.assertEqual(connection.execute("SELECT stock FROM products WHERE sku = 'A'").fetchone()[0], 12)
            self.assertEqual(connection.execute('SELECT count(*) FROM stock_movements').fetchone()[0], 1)
            self.assertEqual(connection.execute('SELECT count(*) FROM cancel_requests').fetchone()[0], 1)

    def test_concurrent_new_keys_only_one_succeeds(self):
        responses = self.concurrent_cancellations([(10, f'key-{index}') for index in range(6)])
        self.assertEqual(sorted(status for status, _ in responses), [200, 409, 409, 409, 409, 409])
        with session(self.path) as connection:
            self.assertEqual(connection.execute("SELECT stock FROM products WHERE sku = 'A'").fetchone()[0], 12)
            self.assertEqual(connection.execute('SELECT count(*) FROM stock_movements').fetchone()[0], 1)
            self.assertEqual(connection.execute('SELECT count(*) FROM cancel_requests').fetchone()[0], 1)

    def test_concurrent_same_key_different_orders_conflicts(self):
        responses = self.concurrent_cancellations([(10, 'same-key'), (11, 'same-key')])
        self.assertEqual(sorted(status for status, _ in responses), [200, 409])
        with session(self.path) as connection:
            self.assertEqual(connection.execute("SELECT count(*) FROM orders WHERE status = 'canceled'").fetchone()[0], 1)
            self.assertEqual(connection.execute('SELECT count(*) FROM stock_movements').fetchone()[0], 1)
            self.assertEqual(connection.execute('SELECT count(*) FROM cancel_requests').fetchone()[0], 1)


if __name__ == '__main__':
    unittest.main()
