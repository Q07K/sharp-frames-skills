# Store API evaluation fixture

Small existing FastAPI application with SQLite. This is synthetic, not production.
Create databases with `store.db.initialize(path)` and apps with `store.api.create_app(path)`.
Bearer alice/bob/manager/charlie are fixture tokens; no external services.
Run `python -m unittest discover -s tests -v` with the supplied dependency path.
Keep existing API contracts and unrelated behavior. Add implementation and useful checks.

`POST /orders/{order_id}/cancel` uses the same visibility rules as order lookup.
Send `Idempotency-Key` with 1–64 ASCII letters, digits, hyphens or underscores
(missing/invalid keys return 422). A paid order becomes canceled, inventory is
restored, and one `cancel` stock movement is recorded per product atomically.
The response is `{"id": order_id, "status": "canceled"}` with HTTP 200.
Retries by the same user with the same key and order return the saved result;
reusing a key for another visible order or canceling a non-paid order with a
new key returns 409. Keys are scoped to each authenticated user.
