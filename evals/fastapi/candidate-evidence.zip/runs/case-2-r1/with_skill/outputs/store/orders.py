from dataclasses import asdict
import json
import sqlite3
from fastapi import HTTPException
from .access import require_visible_order
from .auth import Actor
from .settlement import price_basket


def create_order(connection, actor, basket):
    with connection:
        totals = price_basket(connection, actor, basket)
        cursor = connection.execute('INSERT INTO orders(tenant_id, owner_id, status, total_won) VALUES (?, ?, ?, ?)', (actor.tenant_id, actor.id, 'paid', totals.total_won))
        order_id = cursor.lastrowid
        for line in basket.lines:
            changed = connection.execute('UPDATE products SET stock = stock - ? WHERE sku = ? AND stock >= ?', (line.quantity, line.sku, line.quantity)).rowcount
            if changed != 1:
                raise HTTPException(409, 'Insufficient stock')
            connection.execute('INSERT INTO order_lines VALUES (?, ?, ?)', (order_id, line.sku, line.quantity))
        return {'id': order_id, **asdict(totals)}


def cancel_order(connection: sqlite3.Connection, actor: Actor, order_id: int, request_key: str) -> dict:
    with connection:
        # Serialize writers before reading the status/key so concurrent retries
        # observe the committed result without restoring inventory twice.
        connection.execute('BEGIN IMMEDIATE')
        order = require_visible_order(connection, actor, order_id)
        previous = connection.execute(
            'SELECT order_id, response_json FROM cancel_requests WHERE user_id = ? AND request_key = ?',
            (actor.id, request_key),
        ).fetchone()
        if previous is not None:
            if previous['order_id'] != order_id:
                raise HTTPException(409, 'Idempotency key already used for another order')
            return json.loads(previous['response_json'])
        if order['status'] != 'paid':
            raise HTTPException(409, 'Order is not paid')

        connection.execute("UPDATE orders SET status = 'canceled' WHERE id = ?", (order_id,))
        lines = connection.execute(
            'SELECT sku, SUM(quantity) AS quantity FROM order_lines WHERE order_id = ? GROUP BY sku',
            (order_id,),
        ).fetchall()
        for line in lines:
            connection.execute(
                'UPDATE products SET stock = stock + ? WHERE sku = ?',
                (line['quantity'], line['sku']),
            )
            connection.execute(
                'INSERT INTO stock_movements(order_id, sku, quantity, reason) VALUES (?, ?, ?, ?)',
                (order_id, line['sku'], line['quantity'], 'cancel'),
            )
        result = {'id': order_id, 'status': 'canceled'}
        connection.execute(
            'INSERT INTO cancel_requests(user_id, request_key, order_id, response_json) VALUES (?, ?, ?, ?)',
            (actor.id, request_key, order_id, json.dumps(result)),
        )
        return result
