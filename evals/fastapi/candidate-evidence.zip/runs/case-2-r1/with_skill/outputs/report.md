Implemented `POST /orders/{order_id}/cancel` with the existing order visibility policy and required, strictly validated `Idempotency-Key` header.

Cancellation, aggregated per-product inventory restoration, `cancel` stock movements and the saved per-user response share one transaction. SQLite `BEGIN IMMEDIATE` serializes concurrent writers before status/key checks. Retries return the persisted response; conflicting key reuse and non-paid orders return 409.

Validation: `python -m unittest discover -s tests -v` passed all 13 tests (3 existing, 10 added). Coverage includes authorization, header boundaries, user key isolation, duplicate product lines, conflicting requests, concurrent retries/new keys, and complete rollback on failures at each write stage and commit. An initial test failure came from httpx rejecting a Unicode string header before sending; the test now sends its UTF-8 bytes and verifies the API returns 422. The supplied dependency stack emits an httpx deprecation warning.
