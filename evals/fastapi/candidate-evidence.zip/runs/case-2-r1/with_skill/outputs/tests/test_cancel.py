import json
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from threading import Barrier

from fastapi.testclient import TestClient

from store.api import create_app
from store.db import initialize, session


class CancelBehavior(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.temp.name) / 'store.sqlite')
        initialize(self.path)
        self.client = TestClient(create_app(self.path), raise_server_exceptions=False)

    def tearDown(self):
        self.client.close()
        self.temp.cleanup()

    def cancel(self, order_id=10, key='cancel-1', token='alice'):
        headers = {'Authorization': f'Bearer {token}'} if token else {}
        if key is not None:
            headers['Idempotency-Key'] = key.encode('utf-8')
        return self.client.post(f'/orders/{order_id}/cancel', headers=headers)

    def state(self):
        with session(self.path) as connection:
            return {
                table: [tuple(row) for row in connection.execute(f'SELECT * FROM {table} ORDER BY rowid')]
                for table in ('orders', 'products', 'stock_movements', 'cancel_requests')
            }

    def test_restores_each_product_once_and_saves_result(self):
        with session(self.path) as connection, connection:
            connection.execute("INSERT INTO order_lines VALUES (10, 'A', 3), (10, 'B', 4)")
        response = self.cancel()
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {'id': 10, 'status': 'canceled'})
        with session(self.path) as connection:
            self.assertEqual(connection.execute('SELECT status FROM orders WHERE id=10').fetchone()[0], 'canceled')
            self.assertEqual([tuple(row) for row in connection.execute('SELECT sku, stock FROM products ORDER BY sku')], [('A', 15), ('B', 12)])
            self.assertEqual([tuple(row) for row in connection.execute('SELECT order_id, sku, quantity, reason FROM stock_movements ORDER BY sku')], [(10, 'A', 5, 'cancel'), (10, 'B', 4, 'cancel')])
            saved = connection.execute('SELECT * FROM cancel_requests').fetchone()
            self.assertEqual((saved['user_id'], saved['request_key'], saved['order_id']), (1, 'cancel-1', 10))
            self.assertEqual(json.loads(saved['response_json']), response.json())
        after = self.state()
        self.assertEqual(self.cancel().json(), response.json())
        self.assertEqual(self.cancel().status_code, 200)
        self.assertEqual(self.state(), after)

    def test_conflicts_do_not_change_state(self):
        self.assertEqual(self.cancel().status_code, 200)
        after = self.state()
        self.assertEqual(self.cancel(order_id=11).status_code, 409)
        self.assertEqual(self.cancel(key='new-key').status_code, 409)
        self.assertEqual(self.state(), after)

    def test_non_paid_order_conflicts(self):
        with session(self.path) as connection, connection:
            connection.execute("UPDATE orders SET status='pending' WHERE id=10")
        before = self.state()
        self.assertEqual(self.cancel().status_code, 409)
        self.assertEqual(self.state(), before)

    def test_access_matches_order_lookup(self):
        before = self.state()
        for token, order_id, status in [
            (None, 10, 401), ('invalid', 10, 401),
            ('alice', 20, 404), ('alice', 12, 404),
            ('bob', 10, 404), ('manager', 20, 404), ('alice', 999, 404),
        ]:
            with self.subTest(token=token, order_id=order_id):
                self.assertEqual(self.cancel(order_id, token=token).status_code, status)
        self.assertEqual(self.state(), before)
        self.assertEqual(self.cancel(order_id=12, token='manager').status_code, 200)
        # An existing saved result must not bypass visibility checks.
        self.assertEqual(self.cancel(order_id=20, token='manager').status_code, 404)
        self.assertEqual(self.cancel(order_id=12, token='alice').status_code, 404)

    def test_keys_are_scoped_to_the_authenticated_user(self):
        self.assertEqual(self.cancel(token='alice').status_code, 200)
        self.assertEqual(self.cancel(order_id=20, token='bob').status_code, 200)
        self.assertEqual(self.cancel(order_id=12, token='manager').status_code, 200)
        with session(self.path) as connection:
            self.assertEqual(connection.execute('SELECT count(*) FROM cancel_requests').fetchone()[0], 3)
        # A manager has access, but cannot replay another user's result.
        self.assertEqual(self.cancel(token='manager', key='other').status_code, 409)

    def test_required_header_validation_and_valid_boundaries(self):
        before = self.state()
        for key in (None, '', 'x' * 65, 'with space', 'a.b', 'a/b', '한글', 'a\n', 'a\r', ' a', 'a '):
            with self.subTest(key=key):
                self.assertEqual(self.cancel(key=key).status_code, 422)
        self.assertEqual(self.state(), before)
        self.assertEqual(self.cancel(key='_').status_code, 200)
        self.assertEqual(self.cancel(order_id=11, key='Ab9_-' + 'z' * 59).status_code, 200)

    def test_database_failures_roll_back_every_write_and_allow_retry(self):
        triggers = {
            'order': "BEFORE UPDATE OF status ON orders BEGIN SELECT RAISE(ABORT, 'order failure'); END",
            'stock': "BEFORE UPDATE OF stock ON products WHEN NEW.sku='B' BEGIN SELECT RAISE(ABORT, 'stock failure'); END",
            'history': "BEFORE INSERT ON stock_movements WHEN NEW.sku='B' BEGIN SELECT RAISE(ABORT, 'history failure'); END",
            'key': "BEFORE INSERT ON cancel_requests BEGIN SELECT RAISE(ABORT, 'key failure'); END",
            'commit': "AFTER INSERT ON cancel_requests BEGIN INSERT INTO commit_guard VALUES (99999); END",
        }
        for stage, trigger in triggers.items():
            with self.subTest(stage=stage):
                with tempfile.TemporaryDirectory() as directory:
                    path = str(Path(directory) / 'failure.sqlite')
                    initialize(path)
                    with session(path) as connection, connection:
                        connection.execute("INSERT INTO order_lines VALUES (10, 'B', 2)")
                        connection.execute('CREATE TABLE commit_guard(user_id INTEGER REFERENCES users(id) DEFERRABLE INITIALLY DEFERRED)')
                        connection.execute(f'CREATE TRIGGER fail_cancel {trigger}')
                    original_path = self.path
                    self.path = path
                    try:
                        before = self.state()
                        with TestClient(create_app(path), raise_server_exceptions=False) as client:
                            headers = {'Authorization': 'Bearer alice', 'Idempotency-Key': 'retry'}
                            self.assertEqual(client.post('/orders/10/cancel', headers=headers).status_code, 500)
                            self.assertEqual(self.state(), before)
                            with session(path) as connection, connection:
                                connection.execute('DROP TRIGGER fail_cancel')
                            self.assertEqual(client.post('/orders/10/cancel', headers=headers).status_code, 200)
                    finally:
                        self.path = original_path

    def concurrent_cancels(self, requests):
        barrier = Barrier(len(requests))

        def send(request):
            order_id, key = request
            with TestClient(create_app(self.path)) as client:
                barrier.wait(timeout=10)
                return client.post(f'/orders/{order_id}/cancel', headers={
                    'Authorization': 'Bearer alice', 'Idempotency-Key': key,
                })

        with ThreadPoolExecutor(max_workers=len(requests)) as executor:
            return list(executor.map(send, requests))

    def test_concurrent_retries_only_restore_once(self):
        responses = self.concurrent_cancels([(10, 'parallel')] * 8)
        self.assertEqual([response.status_code for response in responses], [200] * 8)
        self.assertTrue(all(response.json() == {'id': 10, 'status': 'canceled'} for response in responses))
        with session(self.path) as connection:
            self.assertEqual(connection.execute("SELECT stock FROM products WHERE sku='A'").fetchone()[0], 12)
            self.assertEqual(connection.execute('SELECT count(*) FROM stock_movements').fetchone()[0], 1)
            self.assertEqual(connection.execute('SELECT count(*) FROM cancel_requests').fetchone()[0], 1)

    def test_concurrent_new_keys_only_one_succeeds(self):
        responses = self.concurrent_cancels([(10, f'key-{index}') for index in range(8)])
        self.assertEqual(sorted(response.status_code for response in responses), [200] + [409] * 7)
        with session(self.path) as connection:
            self.assertEqual(connection.execute("SELECT stock FROM products WHERE sku='A'").fetchone()[0], 12)
            self.assertEqual(connection.execute('SELECT count(*) FROM stock_movements').fetchone()[0], 1)
            self.assertEqual(connection.execute('SELECT count(*) FROM cancel_requests').fetchone()[0], 1)

    def test_concurrent_key_reuse_for_different_orders(self):
        responses = self.concurrent_cancels([(10, 'shared'), (11, 'shared')])
        self.assertEqual(sorted(response.status_code for response in responses), [200, 409])
        with session(self.path) as connection:
            self.assertEqual(connection.execute("SELECT count(*) FROM orders WHERE status='canceled'").fetchone()[0], 1)
            self.assertEqual(connection.execute('SELECT count(*) FROM stock_movements').fetchone()[0], 1)
            self.assertEqual(connection.execute('SELECT count(*) FROM cancel_requests').fetchone()[0], 1)


if __name__ == '__main__':
    unittest.main()
