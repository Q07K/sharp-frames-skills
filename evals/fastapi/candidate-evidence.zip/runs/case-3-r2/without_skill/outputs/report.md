# Order listing API

Added `GET /orders` with shared order visibility rules, optional paid/canceled filtering, validated pagination, descending ID order, and summary-only response items. The count applies the same visibility and status conditions before paging and remains available for empty pages. SQL values use bound parameters; very large offsets return an empty page safely.

Validation: `python -m unittest discover -s tests -v` passed all 7 tests, including all 3 existing tests. New checks cover all fixture roles, totals, filters, pagination, empty pages, invalid input, missing authentication, and injection attempts.

Limits: verified against the local SQLite fixture. The bundled TestClient emits an httpx deprecation warning; tests pass.

