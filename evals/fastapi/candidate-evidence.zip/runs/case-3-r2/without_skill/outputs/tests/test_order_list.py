import tempfile
import unittest
from pathlib import Path

from fastapi.testclient import TestClient
from store.api import create_app
from store.db import initialize, session


class OrderListBehavior(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.temp.name) / 'store.sqlite')
        initialize(self.path)
        with session(self.path) as connection, connection:
            connection.executemany('INSERT INTO orders VALUES (?, ?, ?, ?, ?)', [
                (21, 101, 1, 'canceled', 3000),
                (22, 101, 4, 'canceled', 4000),
                (23, 202, 2, 'canceled', 5000),
                (24, 101, 1, 'paid', 1000),
            ])
        self.client = TestClient(create_app(self.path))

    def tearDown(self):
        self.client.close()
        self.temp.cleanup()

    def get_orders(self, token='alice', **params):
        return self.client.get('/orders', headers={'Authorization': f'Bearer {token}'}, params=params)

    def test_default_response_and_access_policy_match_details(self):
        expected_ids = {'alice': [24, 21, 11, 10], 'manager': [24, 22, 21, 12, 11, 10],
                        'charlie': [22, 12], 'bob': [23, 20]}
        for token, ids in expected_ids.items():
            with self.subTest(token=token):
                response = self.get_orders(token)
                self.assertEqual(response.status_code, 200)
                body = response.json()
                self.assertEqual(set(body), {'items', 'total', 'limit', 'offset'})
                self.assertEqual([item['id'] for item in body['items']], ids)
                self.assertEqual((body['total'], body['limit'], body['offset']), (len(ids), 20, 0))
                for item in body['items']:
                    detail = self.client.get(f"/orders/{item['id']}", headers={'Authorization': f'Bearer {token}'}).json()
                    self.assertEqual(item, {key: detail[key] for key in ('id', 'status', 'total_won')})

    def test_filters_and_pagination(self):
        self.assertEqual(self.get_orders(status='paid', limit=1, offset=1).json(), {
            'items': [{'id': 11, 'status': 'paid', 'total_won': 9000}],
            'total': 3, 'limit': 1, 'offset': 1,
        })
        self.assertEqual(self.get_orders('manager', status='canceled', limit=1, offset=1).json(), {
            'items': [{'id': 21, 'status': 'canceled', 'total_won': 3000}],
            'total': 2, 'limit': 1, 'offset': 1,
        })
        for offset in (3, 100, 2**64):
            with self.subTest(offset=offset):
                self.assertEqual(self.get_orders(status='paid', limit=100, offset=offset).json(), {
                    'items': [], 'total': 3, 'limit': 100, 'offset': offset,
                })
        with session(self.path) as connection, connection:
            connection.execute("DELETE FROM orders WHERE status = 'canceled' AND tenant_id = 101")
        self.assertEqual(self.get_orders(status='canceled').json(), {
            'items': [], 'total': 0, 'limit': 20, 'offset': 0,
        })

    def test_invalid_filters_and_ranges(self):
        for params in ({'status': ''}, {'status': 'pending'}, {'status': 'PAID'},
                       {'status': "paid' OR 1=1 --"}, {'limit': 0}, {'limit': -1},
                       {'limit': 101}, {'limit': 'abc'}, {'limit': '1.5'},
                       {'offset': -1}, {'offset': 'abc'}, {'offset': '0 OR 1=1'}):
            with self.subTest(params=params):
                self.assertEqual(self.get_orders(**params).status_code, 422)

    def test_authentication_and_injection_boundaries(self):
        self.assertEqual(self.client.get('/orders').status_code, 401)
        self.assertEqual(self.client.get('/orders', params={'limit': 0}).status_code, 401)
        for token in ('unknown', "alice' OR 1=1 --"):
            with self.subTest(token=token):
                self.assertEqual(self.get_orders(token).status_code, 401)
        self.assertEqual([item['id'] for item in self.get_orders().json()['items']], [24, 21, 11, 10])


if __name__ == '__main__':
    unittest.main()
