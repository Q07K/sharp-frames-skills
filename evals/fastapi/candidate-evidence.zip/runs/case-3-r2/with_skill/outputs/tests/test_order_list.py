import tempfile
import unittest
from pathlib import Path

from fastapi.testclient import TestClient

from store.api import create_app
from store.db import initialize, session


class OrderListBehavior(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = str(Path(self.temp.name) / 'store.sqlite')
        initialize(self.path)
        with session(self.path) as connection:
            connection.executemany(
                'INSERT INTO orders VALUES (?, ?, ?, ?, ?)',
                [(13, 101, 1, 'canceled', 5000),
                 (14, 101, 4, 'canceled', 4000),
                 (21, 202, 2, 'canceled', 3000),
                 (22, 202, 1, 'paid', 2000)],
            )
            connection.commit()
        self.client = TestClient(create_app(self.path))
        self.addCleanup(self.client.close)

    def get_orders(self, actor='alice', **params):
        return self.client.get(
            '/orders', params=params, headers={'Authorization': f'Bearer {actor}'}
        )

    def test_default_contract(self):
        response = self.get_orders()
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {
            'items': [
                {'id': 13, 'status': 'canceled', 'total_won': 5000},
                {'id': 11, 'status': 'paid', 'total_won': 9000},
                {'id': 10, 'status': 'paid', 'total_won': 8000},
            ],
            'total': 3, 'limit': 20, 'offset': 0,
        })

    def test_visibility_matches_individual_order_policy(self):
        for actor, expected in [
            ('alice', [13, 11, 10]),
            ('charlie', [14, 12]),
            ('manager', [14, 13, 12, 11, 10]),
            ('bob', [21, 20]),
        ]:
            with self.subTest(actor=actor):
                response = self.get_orders(actor)
                self.assertEqual(response.status_code, 200)
                self.assertEqual([item['id'] for item in response.json()['items']], expected)
                self.assertEqual(response.json()['total'], len(expected))
                for order_id in [10, 11, 12, 13, 14, 20, 21, 22]:
                    detail = self.client.get(
                        f'/orders/{order_id}',
                        headers={'Authorization': f'Bearer {actor}'},
                    )
                    self.assertEqual(detail.status_code, 200 if order_id in expected else 404)

    def test_status_before_pagination_and_count(self):
        response = self.get_orders('manager', status='paid', limit=1, offset=1)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {
            'items': [{'id': 11, 'status': 'paid', 'total_won': 9000}],
            'total': 3, 'limit': 1, 'offset': 1,
        })
        response = self.get_orders('manager', status='canceled', limit=1)
        self.assertEqual(response.json()['items'], [
            {'id': 14, 'status': 'canceled', 'total_won': 4000},
        ])
        self.assertEqual(response.json()['total'], 2)

    def test_empty_pages_retain_total(self):
        for offset in [2, 100, 10 ** 30]:
            with self.subTest(offset=offset):
                response = self.get_orders('manager', status='canceled', offset=offset)
                self.assertEqual(response.status_code, 200)
                self.assertEqual(response.json(), {
                    'items': [], 'total': 2, 'limit': 20, 'offset': offset,
                })
        with session(self.path) as connection:
            connection.execute('DELETE FROM order_lines WHERE order_id IN (10, 11)')
            connection.execute('DELETE FROM orders WHERE tenant_id=101 AND owner_id=1')
            connection.commit()
        self.assertEqual(self.get_orders().json()['total'], 0)
        self.assertEqual(self.get_orders().json()['items'], [])

    def test_pagination_boundaries(self):
        self.assertEqual(self.get_orders(limit=100, offset=0).status_code, 200)
        self.assertEqual(self.get_orders(limit=1, offset=2).json()['items'], [
            {'id': 10, 'status': 'paid', 'total_won': 8000},
        ])

    def test_invalid_query_parameters(self):
        for params in [
            {'status': 'pending'}, {'status': ''}, {'status': 'PAID'},
            {'status': "paid' OR 1=1 --"},
            {'limit': 0}, {'limit': 101}, {'limit': -1},
            {'limit': '1 OR 1=1'}, {'limit': '1.5'}, {'limit': ''},
            {'offset': -1}, {'offset': '0 UNION SELECT 1'}, {'offset': '1.5'},
        ]:
            with self.subTest(params=params):
                self.assertEqual(self.get_orders(**params).status_code, 422)

    def test_authentication_required(self):
        for headers in [{}, {'Authorization': 'Basic alice'},
                        {'Authorization': 'Bearer unknown'},
                        {'Authorization': "Bearer alice' OR 1=1 --"}]:
            with self.subTest(headers=headers):
                self.assertEqual(self.client.get('/orders', headers=headers).status_code, 401)


if __name__ == '__main__':
    unittest.main()
