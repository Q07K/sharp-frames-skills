from typing import Literal
from fastapi import Depends, FastAPI, Header, Query
from . import access, orders
from .auth import authenticate
from .db import session
from .schemas import BasketInput, OrderPage


def create_app(database_path: str) -> FastAPI:
    app = FastAPI()

    def database():
        with session(database_path) as connection:
            yield connection

    def current_actor(authorization: str | None = Header(default=None), connection=Depends(database)):
        return authenticate(connection, authorization)

    @app.get('/orders', response_model=OrderPage)
    def get_orders(
        status: Literal['paid', 'canceled'] | None = Query(default=None),
        limit: int = Query(default=20, ge=1, le=100),
        offset: int = Query(default=0, ge=0),
        actor=Depends(current_actor),
        connection=Depends(database),
    ):
        return orders.list_orders(connection, actor, status, limit, offset)

    @app.get('/orders/{order_id}')
    def get_order(order_id: int, actor=Depends(current_actor), connection=Depends(database)):
        return dict(access.require_visible_order(connection, actor, order_id))

    @app.post('/orders', status_code=201)
    def place_order(basket: BasketInput, actor=Depends(current_actor), connection=Depends(database)):
        return orders.create_order(connection, actor, basket)

    return app
