from pathlib import Path
import hashlib
import json

repo = Path.cwd()
root = repo / 'evals/short-prompt'
artifacts = Path(__file__).resolve().parent
manifest = json.loads((artifacts / 'workspaces.json').read_text())
baseline = Path(next(item['path'] for item in manifest['workspaces'] if item['condition'] == 'without-skill'))
ignored = {'.venv', '.claude', '.git', '.pytest_cache', '__pycache__'}
sources = {path.relative_to(baseline).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(baseline.rglob('*')) if path.is_file() and not any(part in ignored for part in path.relative_to(baseline).parts) and path.suffix not in ('.db', '.sqlite3', '.pyc') and '.db-' not in path.name and '.sqlite3-' not in path.name}
checks = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in ('evaluate.py', 'adapters.json', 'baseline-openapi.json', 'without-skill-results.json')}
assert json.loads((root / 'without-skill-results.json').read_text())['tests_run'] == 7
(root / 'cleanup-frozen.json').write_text(json.dumps({'baseline': sources, 'checks': checks}, indent=2), encoding='utf-8')
print('Frozen baseline and external checks before cleanup generation.')
