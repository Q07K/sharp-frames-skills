from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json
import shutil
import subprocess
import sys
import time

artifacts = Path(__file__).resolve().parent
manifest = json.loads((artifacts / 'workspaces.json').read_text())
protocol = json.loads((Path.cwd() / 'evals/short-prompt/protocol.json').read_text(encoding='utf-8'))
cleanup = '--cleanup' in sys.argv
common = protocol['task'] + '\n\n환경 안내: ENVIRONMENT.md를 읽어줘.'

def run(item):
    condition = item['condition']
    path = Path(item['path'])
    task = protocol['cleanup_task'] + '\n\n환경 안내: ENVIRONMENT.md를 읽어줘.' if cleanup else common
    prompt = ('/sharp-frames-development\n' if condition != 'without-skill' else '') + task
    command = [shutil.which('claude'), '-p', prompt, '--output-format', 'stream-json', '--verbose', '--no-session-persistence',
               '--tools', 'Read,Write,Edit,Glob,Grep,Bash,Skill', '--allowedTools', 'Read,Write,Edit,Glob,Grep,Bash,Skill',
               '--permission-mode', 'acceptEdits', '--permission-prompts', 'none', '--strict-mcp-config',
               '--setting-sources', 'project', '--no-chrome', '--settings', str(path / '.claude/settings.json')]
    start = time.monotonic()
    with (artifacts / (condition + '.jsonl')).open('w', encoding='utf-8') as out, (artifacts / (condition + '.stderr.txt')).open('w', encoding='utf-8') as err:
        try:
            result = subprocess.run(command, cwd=path, stdout=out, stderr=err, timeout=1200, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            status = {'exit_code': result.returncode}
        except subprocess.TimeoutExpired:
            status = {'timeout': True}
    status.update(condition=condition, elapsed_seconds=round(time.monotonic()-start, 2), prompt=prompt, command=command, workspace=str(path))
    (artifacts / (condition + '.status.json')).write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(status, ensure_ascii=False), flush=True)

items = [manifest['refactored']] if cleanup else manifest['workspaces']
with ThreadPoolExecutor(max_workers=len(items)) as executor:
    list(executor.map(run, items))
