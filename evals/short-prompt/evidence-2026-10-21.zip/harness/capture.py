from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import uuid

repo = Path.cwd()
artifacts = Path(__file__).resolve().parent
manifest = json.loads((artifacts / 'workspaces.json').read_text())
cleanup = '--cleanup' in sys.argv
items = [manifest['refactored']] if cleanup else manifest['workspaces']
records = []
ignored = {'.venv', '.git', '.claude', '.pytest_cache', '__pycache__'}
for item in items:
    status = json.loads((artifacts / (item['condition'] + '.status.json')).read_text(encoding='utf-8'))
    source = Path(item['path'])
    target = repo / 'examples/fastapi-short-prompt' / item['condition']
    target.mkdir(parents=True, exist_ok=False)
    hashes = {}
    for path in sorted(source.rglob('*')):
        rel = path.relative_to(source)
        if not path.is_file() or any(part in ignored for part in rel.parts) or path.suffix in ('.pyc', '.db', '.sqlite3') or '.db-' in path.name or '.sqlite3-' in path.name:
            continue
        output = target / rel
        output.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, output)
        hashes[rel.as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
    rows = [json.loads(line) for line in (artifacts / (item['condition'] + '.jsonl')).read_text(encoding='utf-8').splitlines()]
    init = next(row for row in rows if row.get('type') == 'system' and row.get('subtype') == 'init')
    results = [row for row in rows if row.get('type') == 'result']
    calls = [block for row in rows if row.get('type') == 'assistant' for block in row.get('message', {}).get('content', []) if block.get('type') == 'tool_use']
    call_ids = {call['id'] for call in calls if call['name'] == 'Bash'}
    outputs = [block for row in rows if row.get('type') == 'user' for block in row.get('message', {}).get('content', []) if block.get('type') == 'tool_result' and block.get('tool_use_id') in call_ids]
    record = {'condition': item['condition'], 'status': status, 'initialization': {key: init.get(key) for key in ('model', 'claude_code_version', 'tools', 'skills', 'plugins')}, 'result': results[-1] if results else None, 'tool_calls': calls, 'bash_results': outputs, 'files_sha256': hashes}
    records.append(record)
(artifacts / ('captured-cleanup.json' if cleanup else 'captured-pair.json')).write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding='utf-8')
print([(record['condition'], len(record['files_sha256'])) for record in records])

if not cleanup:
    assert (repo / 'evals/short-prompt/cleanup-frozen.json').exists(), 'Freeze baseline HTTP checks before cleanup setup'
    path = Path(manifest['base']) / uuid.uuid4().hex[:8]
    shutil.copytree(repo / 'examples/fastapi-short-prompt/without-skill', path)
    (path / '.claude').mkdir()
    control = Path(next(item['path'] for item in manifest['workspaces'] if item['condition'] == 'without-skill'))
    shutil.copyfile(control / '.claude/settings.json', path / '.claude/settings.json')
    shutil.copytree(repo / 'skills/sharp-frames-development', path / '.claude/skills/sharp-frames-development')
    runtime = '<USER>/AppData/Roaming/uv/python/cpython-3.13.8-windows-x86_64-none/python.exe'
    subprocess.run(['uv', 'venv', '--python', runtime, str(path / '.venv')], check=True)
    subprocess.run(['uv', 'pip', 'install', '--python', str(path / '.venv/Scripts/python.exe'), '-r', str(path / 'requirements.txt')], check=True)
    result = subprocess.run(['uv', 'pip', 'freeze', '--python', str(path / '.venv/Scripts/python.exe')], check=True, capture_output=True, text=True)
    (artifacts / 'refactored-environment.txt').write_text(result.stdout, encoding='utf-8')
    manifest['refactored'] = {'condition': 'refactored', 'path': str(path)}
    (artifacts / 'workspaces.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    print('Prepared unchanged control source in a third independent workspace.')
