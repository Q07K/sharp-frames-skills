from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import uuid

repo = Path.cwd()
artifacts = Path(__file__).resolve().parent
base = Path('<USER>/.codex/visualizations/2026/10/20/01a15a2f-284d-7a72-b0fa-05d66a2893bb') / ('short-prompt-' + uuid.uuid4().hex[:8])
base.mkdir()
runtime = '<USER>/AppData/Roaming/uv/python/cpython-3.13.8-windows-x86_64-none/python.exe'
requirements = (repo / 'evals/fastapi/requirements.txt').read_text(encoding='utf-8') + 'pwdlib[argon2]==0.3.0\nuvicorn==0.38.0\npytest==8.4.2\n'
environment = '''# Prepared environment
Python: .venv/Scripts/python.exe (use this interpreter; system python is a Windows stub).
The packages in requirements.txt are already installed. You may use installed packages and the standard library.
Only use project artifacts in this working folder; do not read parent/sibling projects, other experiments or evaluator materials.
Runtime/library files are available. Do not modify ENVIRONMENT.md, requirements.txt or .claude configuration/skills.
Make ordinary implementation choices yourself and finish the requested work in files here.
'''
items = []
for condition in ('without-skill', 'with-skill'):
    path = base / uuid.uuid4().hex[:8]
    path.mkdir()
    for name, content in {'ENVIRONMENT.md': environment, 'requirements.txt': requirements, '.gitignore': '.venv/\n__pycache__/\n.pytest_cache/\n*.pyc\n*.db*\n*.sqlite3*\n'}.items():
        (path / name).write_text(content, encoding='utf-8', newline='\n')
    settings = path / '.claude/settings.json'
    settings.parent.mkdir()
    settings.write_text(json.dumps({'enabledPlugins': {'superpowers@claude-plugins-official': False, 'humanize-korean@im-not-ai': False}}), encoding='utf-8')
    if condition == 'with-skill':
        shutil.copytree(repo / 'skills/sharp-frames-development', path / '.claude/skills/sharp-frames-development', ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    subprocess.run(['uv', 'venv', '--python', runtime, str(path / '.venv')], check=True)
    subprocess.run(['uv', 'pip', 'install', '--python', str(path / '.venv/Scripts/python.exe'), '-r', str(path / 'requirements.txt')], check=True)
    environment_result = subprocess.run(['uv', 'pip', 'freeze', '--python', str(path / '.venv/Scripts/python.exe')], check=True, capture_output=True, text=True)
    (artifacts / (condition + '-environment.txt')).write_text(environment_result.stdout, encoding='utf-8')
    items.append({'condition': condition, 'path': str(path), 'inputs': {name: hashlib.sha256((path / name).read_bytes()).hexdigest() for name in ('ENVIRONMENT.md', 'requirements.txt', '.gitignore', '.claude/settings.json')}})
manifest = {'base': str(base), 'workspaces': items}
(artifacts / 'workspaces.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
files = [repo / 'evals/short-prompt/protocol.json', *sorted((repo / 'skills/sharp-frames-development').rglob('*.md'))]
frozen = {str(path.relative_to(repo)).replace('\\', '/'): hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
(repo / 'evals/short-prompt/pre-generation-sha256.json').write_text(json.dumps(frozen, indent=2), encoding='utf-8')
print(json.dumps(manifest, indent=2))
